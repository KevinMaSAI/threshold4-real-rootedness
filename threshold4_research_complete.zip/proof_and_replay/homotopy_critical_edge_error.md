# Explicit finite-m error in the endpoint scaling

Notation and proof of the limiting real/simple zeros are in
homotopy_critical_edge.md. Suppose 0<δ≤|w|≤M, 0≤c≤C, m≥1, and
choose T>0 so that q=24/(δ T⁴)<1. Define

    L = C M T³/6 + M T⁵/120,
    E = T+T²/2+T³/6 + C T³/6 + M T⁶ exp(T)/720.

Then for n=4m+r, 0≤r≤3,

    |R_m(w;c)−R(w;c)|
       ≤ exp(L) T^(−r) / m × [E exp(E/m)/(1−q)+q²/(1−q)³].

Indeed, on |ζ|=T the separated exponent of D has modulus at most L.
The difference from the exact exponent of D_m is bounded by E/m:
bound S(ζ/m) termwise, the extra −cζ³/(6m⁵) term directly, and the
B(z) tail starting at degree 6 by exp(|z|)|z|⁶/6!, with z=ζ/m.
Thus |D_m−D|≤exp(L+E/m) E/m by integrating the exponential
along the straight segment between the exponents.

Extend a_(m,j)=m!/((m−j)! m^j) by zero for j>m.
Then 0≤a_(m,j)≤1 and 1−a_(m,j)≤j(j−1)/(2m) for all j≥0.
For j≤m use 1−∏_(i=0)^(j−1)(1−i/m)≤Σ i/m; for j>m
the right side is at least 1. Split the coefficient error as
a_(m,j)([ζ^(4j+r)](D_m−D))+(a_(m,j)−1)[ζ^(4j+r)]D.
Cauchy's estimate gives T^(−r)q^j per factor after (w/24)^(−j);
summing with Σ q^j=1/(1−q) and Σ j(j−1)q^j/2=q²/(1−q)³
gives the inequality. On a circle in the annulus, any independently
certified lower bound for |R| strictly above this error certifies its
zero count by Rouché. This bound alone does not certify all circles
or shrink the full all-n threshold.
