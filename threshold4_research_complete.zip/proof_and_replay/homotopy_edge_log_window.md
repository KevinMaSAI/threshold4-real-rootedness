# An effective logarithmically expanding homotopy edge

Use n=4m+r, ε=c/m², and t=m⁵w as in homotopy_critical_edge.md.
For w<0 put a=(−w/24)^(1/4), p0=4ca, q0=1/(5a), X=p0+q0,
U=X/√2, W=(p0−q0)/√2. Then R(w;c)/a^r is, respectively,

    cosh U cos W,
    (sinh U cos W − cosh U sin W)/√2,
    −sinh U sin W,
    −(sinh U cos W + cosh U sin W)/√2.

For m≥2^40 and X≤(log m)/8, the sign at the following phase points
is exactly as in this limit for R_m: W=jπ for r=0, and
W=π/2+jπ for r=1,2,3 (all j∈Z). Consequently every interval
between consecutive such markers contained in this window has at
least one simple-or-odd-multiplicity real zero, by the alternating
signs. This sign result does not by itself count all zeros of F_n.
It allows c growing logarithmically with m and extends the fixed
annulus result, at the cost of an ineffective zero count outside.

Proof of the bound. Use Cauchy in ζ on radius T=5/(4a), as in
homotopy_critical_edge_error.md. The geometric factor is q=(4/5)^4<1/2.
The exponent of D is bounded by max( (5/4)^3, (5/4)^5 ) X ≤4X. The
difference of exponents is at most E(X)/m, where

    E(X)=7X+30X²+41X³+51X⁵.

For this estimate, keep exp(T/m) in the remainder bound rather than
replacing it by exp(T). Here T=25q0/4≤25X/4 and T/m≤1 by the
hypothesis; exp(T/m)<3. One has T≤7X, T²/2≤20X²,
T³/6≤41X³, cT³/6≤51X⁵, and |w|T⁶exp(T/m)/720≤10X²,
by substitution of |w|=24a⁴, c=p0/(4a). These control the
same terms as in the previous note. Its Cauchy proof therefore gives

    |R_m−R|/a^r ≤ (4/5)^r exp(4X)/m
                    × [ E(X) exp(E(X)/m)/(1−q)+q²/(1−q)³ ].

Take b=log₂ m≥40. Then X≤b/10 by log(2)<4/5,
and exp(4X)≤sqrt(m) from the original X hypothesis. Each
b^j 2^(−b/2), 1≤j≤5, decreases for b≥40 because j/b≤1/8
and log(2)/2>1/4. The same holds with 2^(−b) in place of 2^(−b/2).
At b=40 one has E(4)=55356, yielding E(X)/m≤55356/2^40<1/2
for all b≥40. Consequently exp(E/m)<2 and the last bound is less
than [4E(X)+2]/sqrt(m) ≤ (4·55356+2)/2^20 < 1/4. 
At even r=0 markers the limiting magnitude is ≥1; at odd r markers
it is ≥1/√2; at r=2 markers U≥|W|≥π/2, so it is >1.
Thus the signs transfer strictly. Normalization is nonzero and
has constant sign for negative w. Also W strictly increases with a,
and the set of a with X≤(log m)/8 is an interval, since the
function 4ca+1/(5a) is convex. This completes the sign claim.
