"""Replays a finite prefix for the original problem; never treats it as a proof at all n."""
import argparse
from graeffe_certificate import stream, signs_certificate

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--limit',type=int,default=1024)
    a=p.parse_args()
    maxima=[0,0]
    for n,row in stream(a.limit):
        typ,k,prec=signs_certificate(row)
        if typ!='simple_real':
            raise ArithmeticError(f'inconclusive or nonreal at row {n}: {typ}')
        maxima=[max(maxima[0],k),max(maxima[1],prec)]
        if n%128==0:
            print('verified through',n,'maximum Graeffe iterations/precision so far',maxima,flush=True)
    print('CERTIFIED contiguous original-integer prefix 0 ..',a.limit,flush=True)
if __name__=='__main__':main()
