"""Directed margin checks for the continuum estimates at R>=1024."""
from fractions import Fraction as F
from angular_certificate import Q, ONE, add, sub, mul, sq, exp, trig, point, neg, scale
from phase_k_certificate import PI, rat, quo, root
def b(s):
    x=F(str(s)); return rat(x.numerator,x.denominator)
def m(*args):
    out=ONE
    for a in args:out=mul(out,a)
    return out
def upper(x,s):
    assert x[1]<b(s)[0],(x[1]/Q,s)
def lower(x,s):
    assert x[0]>b(s)[1],(x[0]/Q,s)
def inv(x):return quo(ONE,x)
def damp(x):return exp(neg(x))
def power(x,k):return m(*[x]*k)
R=b(1024); M=m(b('1.49'),R); sqrtM=root(M)
def qerror(t,S,U,p,v):
    return m(inv(v),root(quo(S,t)),add(quo(m(U,p),m(b(8),sq(t))),
                                 quo(m(b(5),sq(U)),m(b(24),power(t,3)))))
def tailG(a,S,v,h):
    return m(quo(m(b(2),root(quo(S,scale(PI,2)))),m(a,h,root(v))),
             damp(m(b('.5'),a,sq(h),v)))
def tailE(a,S,v,h):
    return m(quo(root(quo(S,scale(PI,2))),m(a,h,root(v))),
             damp(m(a,sq(h),v)))
lower(sub(m(b('.5'),trig(b('.5'))[0]),quo(b('7.5'),R)), '.431')
lower(sub(m(b('.5'),trig(b('.39'))[0]),quo(b('7.5'),R)), '.451')
assert m(b('.431'),M,power(b('.39'),3))[0]>scale(PI,12)[1]
upper(add(m(add(ONE,quo(b(15),R)),exp(add(b('.209'),quo(b('.406'),R)))),quo(b(42),power(R,3))),'1.26')
upper(m(b(10),sqrtM,damp(m(b('.0075'),M))),'.01')
upper(m(b(10),power(sqrtM,3),damp(quo(M,b(20)))),'.01')
upper(quo(b(2),m(sq(b('.067')),b('.451'),M,sq(b('.8')))),'1.1')

h=b('.35'); t,S,U=b('.37'),b('1.4'),b('1.74');v=b('83.4')
assert quo(m(PI,b('13.5')),b('.508'))[0]>v[1]
upper(qerror(t,S,U,b('.5'),v),'.310')
upper(tailG(t,S,v,h),'.122')
upper(tailE(b('.22'),S,v,h),'.072')
upper(m(b(2),add(inv(b('.059')),inv(b('.04'))),inv(sqrtM),damp(m(b('.0054'),M))),'.001')
upper(m(b('1.25'),add(b(F(13,12)),quo(b(30),R))),'1.4')
upper(m(b('1.5625'),add(exp(b('.0875')),quo(b(15),R))),'1.74')

S,U=b('1.5'),b('1.9')
upper(exp(m(b('.175'),b('.65'))),F(1)+F('.186')*F('.65'))
upper(m(b('1.25'),add(b('1.15'),quo(b(40),R))),'1.5')
upper(m(b('1.5625'),add(exp(b('.1575')),quo(b(20),R))),'1.9')
for lo,hi,t,cap in [('.5','.65','.33','.286'),('.65','.9','.23','.407')]:
    v=m(M,power(b(lo),3))
    bounds=add(qerror(b(t),S,U,b(hi),v),add(tailG(b(t),S,v,h),tailE(b('.15'),S,v,h)))
    upper(bounds,cap)
upper(m(b(5),sqrtM,damp(m(b('.02'),M))),'.001')

upper(add(exp(b('.12')),quo(add(m(b(14),exp(b('.12'))),b(7)),R)),'1.15')
p=b('.9'); v=m(M,power(p,3)); e=damp(m(b('.0028'),v,p))
upper(qerror(b('.26'),b('1.5'),b('1.55'),b('1.5'),v),'.073')
upper(tailG(b('.26'),b('1.5'),v,b('.2')),'.002')
upper(m(quo(m(b(2),root(quo(b('1.3'),scale(PI,2)))),m(b('.016'),sqrtM,sq(p),root(p))),e),'.116')
upper(m(b('.075'),root(v),e),'.153')
upper(m(b(8),sqrtM,add(damp(m(b('.01'),v,p)),damp(m(b('.021'),M)))),'.015')
q=1024
assert F('1.001')*(q+q*q+F(q**3,2))<539_000_000
print('VERIFIED rational R1024 Airy, Gaussian and infinite-tail constants')
