# Uniform theorem for every integer n≥5173

This theorem is about the original threshold-four polynomial, without
altering allowed block sizes. It closes the former gap between the
middle band and the infinite tail. Finite n<5173 are a separate
certificate, not an implication of this theorem.

## Definitions and path

Put S(z)=z+z²/2+z³/6, B(z)=exp(z)−1−S(z) and F_a=S−aB.
The exponential formula gives
 P_n(−a)=n![zⁿ] exp F_a(z).
For every n≥5173 choose the unique critical radius ρ≥20 with
 N(ρ)=n, N(R)=R⁴/[2(R+1−exp(−R)(1+2R+3R²/2))].
At the merging saddle θ=0, a_c=D²S(ρ)/D²B(ρ) and phase H=0.
See big_blocks4_effective_bulk.md §7 and outer_saddle_R20.md
for N(R) and its monotonicity; N(20)<4000 and N(R)→∞.
For lower radii use the positive stationary branch with
 DF_a(R exp(iθ))=n; H=Im F_a(R exp(iθ))−nθ.
All its values of a vary continuously and strictly grow
as R decreases until the left anchor. To see the local
strictness, set ℓ=log R and U(ℓ,θ)=Re F_a(exp(ℓ+iθ))
at fixed a. At the angular maximum U_θθ<0,
 U_ℓ=N_R(a), and ∂_ℓN_R=−U_θθ−U_ℓθ²/U_θθ>0 by harmonicity.
The respective radial monotonicity lemmas give ∂_aN_R>0.
Implicit differentiation with n fixed now gives ∂_ℓa<0.
At each join, the two radial descriptions agree on their
common range of admissible a because the true upper angular
maximum for the same a is unique. Here is why the solution
at the specified n is in the overlap, rather than merely
why coincidence would be unique. On each side its radial
function is strictly increasing on an upper half-line in a,
starts below n there, and goes to infinity. At a join take
the larger of the two starting a values; the two functions
are defined and agree there, and the function whose validated
range starts at that value is still below n. Therefore both
solutions lie in their common range. For R=10 one may take
the outer starting value where N_R(a)=3000: global isolation
is valid for that N and every larger one, and 3000<5173.
At R=1/4 the small bridge starts at μ=675 and the compact
side at λ=λ0; their strict radial upper bounds at those
starting values supply the same argument. Other outer joins
use the identical stationary equations directly.
At the cusp the branch is continuous from above in a:
the angular solution u tends to zero as n approaches
N(R) along these parameters.

## Sign certificates above radius 20

For 20≤R≤192, use only the angular part of
phase_mid_band_192_joint.md and phase_mid_band_160_joint.md.
Their angle signs and low-phase exclusions are for continuous
R and angular parameters, not restricted to their old overall
n ranges. Both formulas describe the same F_a and stationarity.
All relevant k=0 merging signs are already included.

For 192≤R≤512 the cusp k=0 is covered by
big_blocks4_explicit_tail_18.md §4. At exact markers k≥1:
- u≤.49 implies p=R arcsin(u/R)<.5, so use
  phase_R192_low.md, with the independent p≤1/8 lemma as there.
- .49≤u≤1.3: the factored contour certificate,
  phase_tilt_factored_proof.md and phase_tilt_factored_full_results.txt.
  All 1024 cells pass with lower half-integral at least
  7784261617311366/2⁵⁸. This is a genuine uniform proof including
  every covered continuous parameter pair.
- 1.3≤u≤2.5 and 192≤R≤256: the completed wide rectangle
  phase_wide_192_256_results.txt. For u>2.5 apply
  phase_high_angle_gaussian.md §4 (p≥u).
- 1.3≤u≤1.5 and 256≤R≤512: the completed wide rectangle
  phase_wide_256_512_results.txt. For u>1.5 one has p>1.5;
  apply phase_R256_midangle.md and the high-angle theorem above 2.5.

For R≥512, the angular analysis in full_tail_67_5m.md gives every
marker sign, without a restriction on n beyond existence of the
actual branch: its R≥512 angular statements apply regardless of
n, while the old tail cutoff for n was merely used to skip the
then-unproved angular strip below R=512. Therefore every marker
in the whole outer range R≥20 is now covered, including the
cusp at any radius ρ chosen above.

## Sign certificates below radius 20 and completion

phase_mid_band_192_lower10_joint.md proves all remaining signs
on [10,20], then on [1/4,10] using 333 continuous-radius
certified compact cells starting at n≥5173. Its former n upper
cutoff was used only to upper-bound the cusp radius, not in
any of these lower-radius estimates. For R≤1/4, use
small_radius_quarter.md up to the anchor of left_anchor_800.md.
Here n≥5173 implies m=floor(n/4)≥1293, and the left anchor
itself has nR≥75. The small-radius bridge therefore applies
all the way to it.

The continuous lifted phase starts at 0 and ends strictly
lower than −(m−1)π. Take successive first hits of −kπ for
k=0,1,...,m−1. They are ordered by continuity and distinct.
At the hits, the real integral and P_n(−a) have the strict
alternating signs (−1)^k. The intermediate value theorem
gives m−1 different negative roots in the intervening open
intervals. The strict left-anchor sign against the leading
coefficient gives an additional negative real root to the
left of −a_L, disjoint from those intervals. The degree is
m, since each marked block uses at least four labels and
m disjoint four-blocks plus left-over singletons realize
the maximum. Their count exhausts the degree, so the
roots are all real, negative and simple.

For reproducibility, the newly introduced bounds and exact
rectangle respectively replay with:
    python3 phase_tilt_factored_margin_check.py
    python3 phase_tilt_factored.py --radius 192 512 --angle 49/100 13/10 --grid 32 32 --boxes 80
No floating-point comparison contributes to the verified signs.
