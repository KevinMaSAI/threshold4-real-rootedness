# Finite-exception root certificate: integer and dyadic proof

Write a_(n,k)=[t^k]P_n(t) and use a_(0,0)=1 and out-of-range
indices equal to zero. Inserting the new label either gives a
singleton (unchanged k), joins one of k already-large blocks,
joins a 1- or 2-element block, or joins a 3-element block
which becomes large. Choosing a block of size r≤3 is equivalent
to choosing its r labels and a partition of the other labels.
Thus, for n≥0,
 a_(n+1,k)=(k+1)a_(n,k)+n a_(n−1,k)+binom(n,2)a_(n−2,k)
                 +binom(n,3)a_(n−3,k−1).
This supplies exact integers in both Python and GMP. The model
can be checked without this recurrence by the independent
minimum-label block recurrence or direct exponential generating
function convolution, implemented in check.py. For each 0≤k≤n/4,
k disjoint four-element blocks and the remaining singletons
show a_(n,k)>0.

For a real polynomial f(t)=Σ_(k=0)^d a_k t^k define its Graeffe
iterate g by g(−z²)=f(z)f(−z). Its roots with multiplicity
are the images −r² of roots r of f; the degree and nonzero
constant term are preserved. A nonreal conjugate pair always
remains a conjugate pair, so if it ever has real image roots,
the two roots coincide. A repeated root remains repeated.
Consequently if an iterate has d distinct real roots, so
did f, and for the original positive coefficients they
must be strictly negative.

Here is a sufficient exact final test, stated with proof.
For positive a_k put q_k=a_(k−1)a_(k+1)/a_k² (1≤k<d).
If every q_k<1/4, the ratios a_(i−1)/a_i are strictly
increasing. At x_k=sqrt(a_(k−1)/a_(k+1)), the adjacent terms
a_(k±1)x_k^(k±1) are equal and each is smaller than one half
of a_k x_k^k. The magnitudes of both tails decrease away
from that central term, by monotonicity of the ratios.
Thus each alternating tail in f(−x_k) has magnitude no
larger than its first term, and the sum of their magnitudes
is strictly less than the central term. The sign at x_k
is (−1)^k. The x_k are strictly increasing; the signs at
0 and at sufficiently large x are + and (−1)^d. The
d strict sign changes give d distinct negative roots.
Nonzero constants are allowed and linear positive polynomials
satisfy the conclusion directly.

Graeffe updates can be carried out without storing the huge
iterated coefficients. Its k-th coefficient is a_k² η_k with
 η_k=1+2 Σ_(s=1)^min(k,d−k) (−1)^s v_s,
 v_s=a_(k−s)a_(k+s)/a_k².
This follows by multiplying f(z)f(−z) and taking the even
coefficient. Let h_s=∏_(j=k−s+1)^(k+s−1) q_j. Then
v_s=∏_(i=1)^s h_i, by telescoping the exponent of each a_j.
The program updates h_s by two extra neighboring factors,
and v_s by multiplication by h_s. Because the program checks
0<q_j<1 from their mathematical definitions and upper intervals,
the v_s decrease. If the remaining alternating sum is truncated,
its error has the next term's sign and magnitude at most the
last enclosed v_s. The endpoints satisfy η₀=η_d=1.
Whenever every η_k has strictly positive verified lower bound,
the next q_k equals
 q_k² η_(k−1)η_(k+1) / η_k².
Therefore forward dyadic enclosure and positivity checks apply
inductively to actual coefficients, not floating approximations.

In Python graeffe_fast_adaptive.py and finite_exception_large.py,
or finite_exception_gmp.cpp, each closed interval is computed
with integer floor/ceiling at scale Q=2^b. For nonnegative
endpoints, multiplication scales by Q once and rounds down/up;
addition is exact. For the final form num/η² the scaled quotient
is an exact integer division of the enclosed numerator times
Q² by the appropriate enclosed squared endpoints. The
initialize step uses exact integer leading-bit intervals
[a_low,a_high]*2^e before comparable divisions. Positivity
and q<1/4 are decided by strict integer comparisons. If any
interval is too wide the code raises precision or exits without
claiming the row; an inconclusive run is not a nonreal witness.
There is no upper bound assumption on precision needed for
mathematical validity. The observed proof precisions are
recorded in the replay logs. Converting the code to compiled
GMP changes only the integer arithmetic backend, not the proof.
