# Sharp asymptotic degree bound for the reduced three-lag determinant

This builds on the reduced-determinant formulation and
big_blocks4_homotopy_endpoint.md; it gives no positivity theorem.
Let d=floor(n/3)≥1, q=floor(n/4), r=n−4q, and use primes for
n−3 (so its highest degree is d−1). Define b=d−q, b′=d−1−q′.
Let I=[r>0 and b>0], I′=[r′>0 and b′>0], f=b−I, f′=b′−I′,
and let s=4−r, s′=4−r′. Then f,f′ count the two blown-up
fast groups (t∼constant·a⁴, a=1+v); I,I′ count the single
possible slow roots (t∼constant·a^s or a^s′). If both slow
roots exist, automatically s>s′ since r′=(r+1) mod 4.

An important extra fact is that the two limiting fast groups
have no common nonzero root. Let T_n(z) be the fast limit
epsilon^n F_n(1−epsilon,epsilon^(−4)z), valid for epsilon→0+,
so T_n has coefficients
    c_(n,j)=n!/[6^(4j−n) 24^(n−3j) (4j−n)! (n−3j)!]
on ceil(n/4)≤j≤floor(n/3), and zero elsewhere.
Directly comparing coefficients gives the exact identity
\[
 T_{n-3}(z)=\frac{6}{n(n-1)(n-2)} z^{-1}
          (4z\partial_z-n)T_n(z).
\]
Indeed j′=j−1 gives the same n−3j, and 4j′−(n−3)=4j−n−1;
the term 4j−n=0 is killed. This also applies to an empty
fast-limit polynomial. If T_n has a nonzero root, it is simple by
the endpoint proof. The displayed identity forbids any such
root from being a root of T_(n−3) too. Thus equal scaling
exponents in the fast groups do not cause cross-root cancellation.

Define J_n(v,y)=F_n(v/(1+v),(1+v)y−v) (the reduced row,
equivalently K_n(v,(1+v)y−v)/(1+v)^d).
Its leading coefficient as a polynomial in y has asymptotic
degree h=min(d,n−3d) in a=1+v; h′=min(d−1,n−3d) for the lag.
This is the endpoint valuation 4d−n (or zero if negative)
in the leading coefficient of F_n; its leading constant is
nonzero from the explicit endpoint counting.
For cross root differences in the t-coordinate, total leading degree
is bounded by
\[
 E=4[d(d-1)-(d-f)(d-1-f')]
       + I s(q'+I')+I' s' q .
\]
Indeed any pair touching a fast root gives degree 4, including
two fast roots by the no-common-root argument. Of the remaining
pairs, a current-row slow root dominates both lag classes if
present (since s>s′ when both are present). A lag slow root
dominates each of the q finite current roots. Finite-finite
differences are bounded. Every leading term in these pairwise
differences is nonzero except precisely when two finite limit
roots coincide. Changing to the y-coordinate divides every
difference by a.

The Bézout determinant identity at degree pair (d,d−1)
adds the leading coefficients to power d each: in the
root-product resultant these have powers d−1 and d,
respectively, and the determinant has one further factor
of the leading coefficient of the first polynomial (up to
a fixed sign). Thus the degree of the polynomial
det B(J_n,J_(n−3)) is at most
\[
 d(h+h')+E-d(d-1),
\]
unless the polynomial is identically zero, in which case use
degree -∞. Equality holds exactly when P_n and P_(n−3)
have no common root. In the common-root case the ratio by
a to the displayed integer power tends to zero because a
finite-finite difference tends to zero; no other differences
grow faster. This argument uses complex roots with multiplicity,
so does not assume any unproved full real-rootedness.
For example n=42 gives d=14,q=10,r=2,b=4,f=f′=3,h=h′=0,
E=318, so degree ≤136. The exact parametric computation
reaching 136 is consistent with this sharp bound.
This does not show nonvanishing on v≥0 or strict lag
interlacing at v=0.
