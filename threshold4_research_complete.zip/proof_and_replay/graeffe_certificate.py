"""Dyadic-integer Graeffe real-root certificate avoiding huge unscaled coefficients.
Run python3 graeffe_certificate.py 20 80 200.
Usage is an optional exact finite-exception backend, not an all-n proof.
"""
from argparse import ArgumentParser
from math import comb

def signs_certificate(a, max_bits=8192, steps=25):
    d=len(a)-1
    if any(x<=0 for x in a):
        raise ValueError("the input must have strictly positive coefficients")
    if d<=1:
        return 'simple_real',0,0
    def run(bits):
        Q=1<<bits
        one=(Q,Q)
        def quot(a,b,c,e):
            # Enclose the nonnegative quotient [a,b]/[c,e].
            return a*Q//e,-((-b*Q)//c)
        def mul(U,V):
            if U[0]<0 or V[0]<0:
                raise ArithmeticError("expect nonnegative")
            return (U[0]*V[0]//Q,-((-U[1]*V[1])//Q))
        qs=[]
        for k in range(1,d):
            p=a[k-1]*a[k+1]
            v=a[k]**2
            qs.append((p*Q//v,-((-p*Q)//v)))
        for j in range(steps+1):
            if 4*max(p[1] for p in qs)<Q:
                return ('simple_real',j,bits)
            if j==steps:
                break
            if max(p[1] for p in qs)>=Q:
                return None
            eta=[one]
            for k in range(1,d):
                lo=hi=Q
                v=one; h=one
                lim=min(k,d-k)
                for ell in range(1,lim+1):
                    if ell==1:
                        h=qs[k-1]
                    else:
                        h=mul(mul(h,qs[k-ell]),qs[k+ell-2])
                    v=mul(v,h)
                    if ell%2:
                        lo-=2*v[1]; hi-=2*v[0]
                    else:
                        lo+=2*v[0]; hi+=2*v[1]
                    if v[1]<=1 and ell<lim:
                        # The unsummed terms form a monotonically decreasing
                        # nonnegative alternating series because q_i<=1.
                        if ell%2:
                            hi+=2*v[1]
                        else:
                            lo-=2*v[1]
                        break
                if hi<0:
                    return ('nonreal',j+1,bits)
                if lo<=0:
                    return None
                eta.append((lo,hi))
            eta.append(one)
            nxt=[]
            for k in range(1,d):
                num=mul(mul(qs[k-1],qs[k-1]),mul(eta[k-1],eta[k+1]))
                a0,a1=eta[k]
                # Divide num/Q by eta^2 without an extra interval rounding
                # at the denominator, which might otherwise underflow.
                nxt.append((num[0]*Q*Q//(a1*a1),-((-num[1]*Q*Q)//(a0*a0))))
            qs=nxt
        return None
    bits=32
    while bits<=max_bits:
        r=run(bits)
        if r is not None:
            return r
        bits*=2
    return 'inconclusive',steps,max_bits

def stream(N):
    rows=[[1]]
    yield 0,rows[-1]
    for n in range(N):
        row=[0]*((n+1)//4+1)
        for k,val in enumerate(rows[-1]):
            row[k]+=(k+1)*val
        for r in (1,2,3):
            if r<=n:
                w=comb(n,r)
                for k,val in enumerate(rows[-1-r]):
                    row[k+(r==3)]+=w*val
        rows=(rows+[row])[-4:]
        yield n+1,row

def main():
    p=ArgumentParser()
    p.add_argument('n',type=int,nargs='*',default=[12,40,100,200])
    p.add_argument('--max-bits',type=int,default=8192)
    A=p.parse_args()
    assert signs_certificate([1,4,1],max_bits=64)[0]=='simple_real'
    assert signs_certificate([1,2,1],max_bits=64)[0]=='inconclusive'
    assert signs_certificate([1,1,1],max_bits=64)[0]=='inconclusive'
    assert signs_certificate([4,5,4],max_bits=64)[0]=='nonreal'
    for n,row in stream(max(A.n)):
        if n in A.n:
            print(n, len(row)-1, *signs_certificate(row,A.max_bits),flush=True)
if __name__=='__main__':main()
