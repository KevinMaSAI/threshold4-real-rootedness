# Low phase indices at R≥2048: extract the quartic Airy correction

We use the same stationary curve and tilted contours as before. In
the original threshold-four problem let R≥2048, 1/8≤p≤1/2 and
H=−kπ with 1≤k≤6. Write c=−3H/(2p³), v=cp³=3πk/2,
M=a exp(R), Ω(w)=F_a(R exp(iw/R))−inw/R, and
q(w)=Re Ω(p)+ic(w³/3−p²w). We prove sign (−1)^k.
The result for p≤1/8 is already in airymarker_small_p.md.

## Input sizes and derivative bounds

The stationary estimates of low_angle_large_k.md remain valid at
R≥2048 on |w|≤.81, |Im w|≤.36: in their individual bounds,
|z/R−1|≤.82/R, |z−R−iw|≤.34/R, the exponential estimates are
1.435 and .49/R, and the normalized T3 and T4 deviations are
5.5/R and 9.4/R, all directly by the same polynomial formulas.
The S bounds 4.52/R and 14/R² give the same 15/R derivative
errors. Therefore the simplex relation for c/M gives
c/M≥cos(p)/2−7.5/R>.435. Since M≥1.49R,
v≤9π forces p<.28 (the lower estimate .435·1.49·2048·.28³
exceeds 9π). Now c/M>.476 by the cosine estimate at .28, so
the individual p bounds for k=1,...,6 are .149,.187,.214,
.236,.254,.27, as checked exactly in airy_quartic_error_check.py.

Use b=.55, x0=.72, and the reflected path of
airymarker_small_p.md defined by w=x+ib(x−p) for 0≤x≤x0,
then dropping vertically to the real axis. Its central convex
hull with ±p has |w|<.81 and Im w≥−.1485. We have
|Ω⁽⁴⁾(w)|<1.18M and |Ω⁽⁵⁾(w)|<1.17M there.
The first follows from the 15/R model error. For the second,
T5(z)=z⁵+10z⁴+25z³+15z²+z, so |T5(z)/R⁵|<1.006 using
|z/R|≤exp(.1485/R), and |exp(z−R)|≤exp(.1485+.34/R)<1.161.
The normalized S contribution is less than 42/R³
since (1+a)/M≤1/R, |z/R|≤exp(.1485/R), and
D⁵S=z+16z²+(81/2)z³. These verify the strict upper bound.
At w=0 the real Ω⁽⁴⁾(0) is negative since T4(R)/R⁴≥1
and the competing term is
[(1+a)/M](R+8R²+(27/2)R³)/R⁴ <14/R².
Its absolute value is ≤1.004M, by T4(R)/R⁴ at R=2048.

## Exact signed correction and certified absolute remainder

Subtract the reference cubic and write Δ=Ω−q. Values and first
derivatives match at ±p, including their real and imaginary
values. The Hermite divided difference therefore gives
Δ=(w²−p²)² times the average of Ω⁽⁴⁾ on the simplex of
volume 1/24 with nodes (−p,−p,p,p,w). Put
E=(Ω⁽⁴⁾(0)/24)(w²−p²)².
The first barycentric moments are all 1/5 after dividing by
the simplex volume. The derivative bound gives
|Δ−E|≤[1.17 M/120](|w|+4p)|w²−p²|².
Also |Δ|≤[1.18 M/24]|w²−p²|².

Divide integrals by exp(Re Ω(p)). On the indefinitely extended
straight reference path, use integration by parts with cubic
exponential f. Since f'=ic(w²−p²)f, all endpoint terms vanish and
`∫ (w²−p²)² f dw=(2i/c)∫ w f dw
=4πc^{−5/3} Ai'(−c^{2/3}p²)`.
The derivative identity follows by differentiating the Airy
function along an upward tilted Airy contour, where cubic
decay justifies differentiation. Both halves of our reference
path have exactly those rays asymptotically; a bounded
vertical translation within the decay sectors leaves it invariant.

At exactly v=3πk/2, the cited Prüfer estimate gives
sign Ai(−λ)=(−1)^k, λ=c^(2/3)p², and amplitude of the full
reference integral > (2π/3)/sqrt(cp).
The same estimate gives sign Ai'(−λ)=(−1)^(k+1):
with s=2λ^(3/2)/3 and U=λ^(1/4)Ai(−λ), write
U=L sin ψ, dU/ds=L cos ψ. Then
Ai'(−λ)=−λ^(1/4)(dU/ds)+(1/4)λ^(−5/4)U.
The estimate |ψ−(s+π/4)|≤5/(36π) at s=kπ, with L>0,
makes U and dU/ds have the same sign (−1)^k, and
|(dU/ds)/U|>1/2>1/(4λ^(3/2)).
Hence, because Ω⁽⁴⁾(0)<0, the exact contribution from E f is
the same sign as the cubic integral. It is not counted as error.

For the central path, |w²−p²|²≤(1+b²)²(x−p)²(x+p)².
The reference damping is at least βc(x−p)²(x+p), where
β=b(1−b²/3). True and reference exponents and all their convex
combinations have real decay at least .30c(x−p)²(x+p):
indeed the loss can be reduced by at most
[1.18(1+b²)²/(24·.476)](x+p) times that geometry,
and x+p≤.99. For u=x/p use Y=(u−1)²(u+1), Z=Y(u+1).
With |w|≤1.15x+.55p the upper bounds are
|Δ−E|≤.036vp²(1.15u+4.55)Z and |Δ|≤.176vpZ.
The entire identity for the exponential remainder gives
|exp(Δ)−1−E|≤|Δ−E|+(1/2)|Δ|² max(1,e^Re Δ).
Thus the error relative to the cubic lower amplitude is bounded by
    [2.3 sqrt(v)/(2π/3)] ∫_(0)^∞
       [.036 v p² (1.15u+4.55) Z + (.176 v p Z)²/2]
       × exp(−.30 v Y) du.

Here the factors 2.3 and sqrt(v) come respectively from both halves
with their exact line elements and p sqrt(cp). Upper bounding p
by its six rational caps is valid because this bound is monotone
in p at fixed v. Exact dyadic interval integration over u∈[0,6]
and a simple analytic tail bound give <1/4 in every case.
The script uses Machin bounds for π and outward-rounded exp;
it certifies continuum majorants, not sample points.

## Remaining integral tails and contour

At x=x0 and 0≤y≤b(x0−p) the real part of the exact integrand's
exponent does not exceed its value at y=0. For this, use the
simplex bounds Re L>.4 and |Im L|<.13 from
low_angle_R4096_complete.md with error 7.5/2048:
at x0=.72, y≤.32725 and p≤.27 these constants hold.
In Re[((x+iy)²−p²)L] the leading factor is ≥
(1−b²)(x²−p²), and 2xy≤2b(x²−p²), so its lower bound
has positive factor (1−b²)·.4−2b·.13. The vertical derivative of
Re Ω is the negative of that expression times M.

The real-circle loss at cutoff is >.006M, since
−w χ'>.30u up to u=.72 and
(.30·1.4/(8·1.6))((.99·.72)²−.27²)²>.006.
Loss is nondecreasing thereafter on the first expanded arc.
The remote arc has loss ≥R/10≥M/20 using M≤2R (small p).
The two parts of the actual contour, including its return,
have error <.01 each relative to the Airy lower amplitude:
that amplitude is >1/sqrt(M), as c≤M and p≤.27.
Their respective bounds are 10 sqrt(M) e^(−.006M) and
10 M^(3/2) e^(−M/20), with M≥1.49·2048.

For x≥.72 on the reference path, x−p≥.625x and hence the
cubic loss >.19 c x³. Also |E|≤.15 c x⁴.
The factor (c x^4 exp(−.095cx^3)) is <.3 there, since
e^t≥t²/2 and c>.476·1.49·2048. Thus the tail of
(1+E)f is bounded by both line element factors times
1.05 ∫_(.72)^∞ exp(−.095c x³) dx. Use x³≥(.72)²x
and the same lower amplitude to get <.01 relative error
(e.g. exponent loss at x0 exceeds 50).
The errors are altogether <.28, and the cubic integral and
the extracted exact correction have the same sign.
This proves every marker in the stated sector.
