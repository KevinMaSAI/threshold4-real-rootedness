# Strict negative roots for all n ≥ 7,500,000,000,000

This is a stronger uniform large-n theorem for the original
problem, not a resolution of all n. Its proof needs the exact
lifted phase and the same hypotheses on the saddle curves
as in the formerly stated 10^18 proof; we change the exterior
angle coverage, not the model.

For R≥24576, every exact phase marker has sign (−1)^k:
1/8≤p≤1.5 by phase_R24576_improvement.md,
p≤1/8 and k>0 by airymarker_small_p.md, p=0 and k=0
by big_blocks4_explicit_tail_18.md §4, 1.5≤p≤2.5
by phase_R256_midangle.md, and p≥2.5 by
phase_high_angle_gaussian.md.

For 32≤R≤24576, the assumption n≥7.5·10^12 forces p>2.5
at every actual saddle. To see this, if p≤2.5 then u_p≤2.5
gives sinc(u_p)≥sinc(2.5)>.23, so
f(u_p)≥sinc(u_p)−1/(.99R)>.19. In the exact angular relation,
w≤1.6R and e^(X−R)>.8 give M/(1+a)<11R, whence
a<.001 by 11R e^(−R)≤352 e^(−32), and M<12R.
The radial saddle equation then forces
\[
n \le (1+a)\Re DS(z)+M e^{X-R} |z|
 < 1.001(R+R^2+R^3/2)+12R^2
 \le 1.001(24576+24576^2+24576^3/2)+12\cdot24576^2
 < 7.5\cdot 10^{12}.
\]
This contradiction proves the claimed p-exclusion. Therefore
the earlier high-angle theorem alone covers these smaller
outer radii along the fixed n curve, including the overlap
at R=24576. The critical boundary N(R) is increasing for
R≥32 and N(R)→∞, so the cusp for the stated n exists uniquely;
this exclusion also shows it is above R=24576.

The rest of the original proof is unchanged. The compact
R∈[1/20,32] markers apply at n≥56230; the small radius
bridge and left_anchor_800.md give the strict terminal phase
H<−(m−1)π, along with one strictly farther-left real root.
From the cusp to this anchor, use the first successive hits
of H=−jπ, j=0,…,m−1. All signs alternate by the covering
lemmas. The intermediate value theorem gives m−1 distinct
negative real roots in the transition, disjoint from the
leftmost bracket. The degree m=floor(n/4) is exhausted.
All roots are therefore simple and negative for every n
in the asserted infinite range. No finite sequence of
individual n computations is used.
