"""Exact rational/directed checks for the R10 bridges."""
from fractions import Fraction as F
from angular_certificate import Q, ONE, add, sub, mul, exp, trig, neg, point
from phase_k_certificate import PI, rat, quo, root
def b(x):
    f=F(str(x)); return rat(f.numerator,f.denominator)
def m(*it):
    x=ONE
    for y in it:x=mul(x,y)
    return x
def lt(x,y):
    assert x[1]<y[0],(x[1]/Q,y[0]/Q)
pilo,pihi=F(PI[0],Q),F(PI[1],Q)
R=10; X=F('.945')*R; u=F('3.25')
assert X*X+u*u<R*R
z=u*u/(R+X)
assert 1-z+z*z/2-z**3/6+z**4/24-z**5/120>F('.58')
assert 1/X**3+1/X**2+3*(1+1/X)/(F('1.48')*R**2)<F('.035')
assert F('.1')/X+u/X**3+(u/X+3*u/(F('1.48')*R**2))*(F('.1')/pilo+1/X)<F('.072')
assert F('.58')*(F('.1')-F('.035'))/F('1.71')>F(1,47)
assert F('.58')*(F('.295')-F('.072'))/(F('1.71')*u)>F(1,47)
assert F('.1')/X+u/X**3+max((u/X)*(F('.1')/F('2.75')+1/X),
      (F('.4')/F('2.75')+1/X)*3*u/(F('1.48')*R**2))<F('.065')
assert F('.58')*(F('.269')-F('.065'))>F('.115')
assert F('.115')*F('1.48')*F('2.75')/(2*F('1.71'))*F('.945')**2>F('.12')
assert F('.115')*F('1.48')*F('2.75')/(2*F('1.71'))*F('.23')**2>F('.007')
assert F('.75')-1/(F('2.84')*R)>F('.71')
assert F('9.87')/(F('1.945')*R)+F('9.87')+F('.75')*F('9.87')*R<F('8.45')*R
lt(b('.60'),exp(b(-F('9.87')/(F('1.945')*R))))
lt(exp(b('-1.33')),b('.265'))
lt(b(22000),exp(b(10)))
lt(b('.73'),exp(b(-F('2.45')**2/(F('1.945')*R))))
assert F('.58')*pilo*F('.1')>F('.18')
assert F('.260')-F('.78')/X>F('.177')
assert F('1.007')*(12+12**2+F(12**3,2)+F('1.71')/F('.177')*12**2)<3000
assert F('.282')-F('.73')/12<F('.222')
assert F('1.48')/F('.222')>F('6.66')
assert (F('.335')-F('.18')/10)*F('6.66')-F('1.35')>F('.34')
assert F('2.8')-F('2.8')**3/(6*R*R)>F('2.763')
assert (pihi-F('2.763'))/F('2.763')<F('.138')
assert 1-(pihi-F('2.763'))**2/2>F('.92')
assert F('1.48')*12**2/(F('.138')*12-F('.92'))>289
assert F('3.31')-F('3.31')**3/(6*R*R)>pihi+F('.1')
assert F('.58')*(1-F('.766')**2/2)*F('.9')>F('.365')
assert F('.58')*(1-F('.762')**2/2)*F('.9')>F('.37')
M=b(289);S=root(M);tau=F('.37')
L=2/(8*tau**2)+20/(24*tau**3)
lt(quo(m(root(b(F(3)/tau)),b(L)),M),b('.181'))
def g(t):
    return quo(m(b(2),root(quo(b(3),m(b(2),PI))),exp(neg(m(b('.02'),t,M)))),m(b('.20'),t,S))
lt(g(b('.37')),b('.133'))
lt(g(b('.365')),b('.139'))
lt(m(b('1.7'),S,exp(neg(m(b('.0292'),M)))),b('.007'))
lt(m(b('2.8'),b(10),exp(b('-3.4')),S,exp(neg(m(b('.022'),M)))),b('.029'))
print('VERIFIED outward-rational R10 constants')
