# Direct mixed-curvature and joint-tail bound: compact n≥16376

Use the paired angular cells of bulk_cutoff_paired_proof.md. At a
stationary angle of U=Re(S−λBsharp) write N=Re D(S−λBsharp).
The angular implicit derivative obeys
|dθ/dλ|≤L1/(λ² c_b); its derivation is unchanged. To estimate
∂θN one need not bound |D²(S−λBsharp)| on the whole circle:
∂θN=−Im D²(S−λBsharp). Thus it is valid to take
λ times the tighter of the old L2 and the sum of the two
local upper imaginary bounds for D²Bsharp and D²S/512
throughout the full validated angular bracket. Similarly
L1 uses local upper |Im DS| as an extra bound. Once λ0 is
certified and the narrower bracket containing its actual
angle is fixed, use maxima of Re DS and −Re D Bsharp over
that narrower bracket to bound N_R(λ0). Each is enclosed on
an angular partition; the formulas in the script are explicit
real and imaginary parts of D^j of the same original functions.
For small radii the factorial power series is terminated with
the same geometric tail bounds as the old pure-B estimates.

Rather than requiring specific fractions of the Gaussian-error
budget for each contribution, check their summed exact upper:
- the local (Q) bound is
  sqrt(L2/c_b)[L4/(8c_b²)+5L3²/(24c_b³)]/λ;
- the missing Gaussian tail is bounded by
  sqrt(2L2/c_b) exp(−λ c_b w²/4);
- the true exterior tail is bounded by
  2 sqrt(λ L2) exp(−min[λ c_b w²/2, min_j(λ g_j−p_j)]).
All of these are monotone toward smaller error for λ≥λ0 if
the minimum loss is at least 1/2 at λ0 (as in the paired proof).
The script obtains upper dyadic square roots by integer sqrt
and a one-unit outward rounding; it obtains upper e^(−x) by
rounding x down before applying the existing rigorous exp enclosure.
Replacing x by min(x,80) is also a conservative upper bound.
The exact certified sum is <7/10<1/√2. The resulting saddle sign
holds at every marker for all λ≥λ0 and hence all n at or above
the certified radial threshold.

Replay:
    python3 bulk_cutoff_mixed_joint.py angular_certificate.json 20
Result: all 504 cells pass for compact 1/20≤R≤20 and n≥16376.
The only use of floating point in this script is printing diagnostics.
