# Strict negative roots for 7254≤n≤3520607

Use phase_mid_band_192_joint.md from the cusp down to R=20.
The n≥7254 cusp is still strictly above R=20. Replace the
rest of its proof with:
1. 12≤R≤20: outer_saddle_R12.md proves continuation,
   excludes every actual configuration with u≤2.45, and
   proves the analytic p≥2.8 signs. Exact certificate
   phase_wide_R12_final_results.txt covers 2.45≤u≤2.8
   over the whole range; 508 cells, exact lower bound
   26455831188363/2⁵⁸ on the normalized half-integral.
   If u>2.8 then p≥u and use the analytic sector.
2. 1/4≤R≤12: bulk_cutoff_mixed_interval.py with
   angular_certificate.json 12 1/4 gives n≥7254
   (367 cells, exact logs in bulk_mixed_quarter_12_results.txt).
3. R≤1/4: small_radius_quarter.md and the left anchor
   apply, since n≥2900, m≥800 and nR≥75 along the arc
   to the anchor (R decreases and the endpoint has nR>75).
At each join the saddle is the same: the upper global maximum
angle is unique for the same a, and the radial equation is
strictly monotone in that parameter on each branch. Thus the
continuous lifted phase and its first successive real sign
brackets still give m−1 simple disjoint roots plus the separated
far-left root. The stated interval is fully covered uniformly,
independent of the small finite prefix and the infinite tail.
