#!/usr/bin/env bash
# Reproduce the complete finite proof with the independent GMP implementation.
set -euo pipefail
cd -- "$(dirname -- "$0")"
exe=$(mktemp /tmp/bigblocks4-check.XXXXXXXX)
g++ -O3 -UNDEBUG -std=c++17 finite_exception_gmp.cpp -lgmpxx -lgmp -o "$exe"
for span in '0 1024 32' '1025 2048 256' '2049 3071 512' '3072 3200 1024' '3201 3583 1024' '3584 3712 1024' '3713 4095 1024' '4096 4224 1024' '4225 4639 1024' '4640 4736 1024' '4737 5172 1024'; do
    read -r a b p <<<"$span"
    "$exe" "$a" "$b" "$p"
done
