"""Asymmetric two-saddle resolved contour at lower angle.

All four covering pieces use exact rational widths in a coordinate
relative to the saddle. The positive half is tilted around the saddle,
returns vertically to the real axis, and finishes along the real circle.
"""
from fractions import Fraction as F
from phase_wide_cell import (Q, ONE, ZERO, F as _F, rat, add, sub, mul, exp, trig,
                             geometry, integrand, exponent_diff, tail_bound)

def lower(C,nboxes=96):
    R,z,p,a1,M,aE=C
    tail_x=F(81,25)
    xmax=rat(tail_x.numerator,tail_x.denominator)
    tilt=rat(9,20)
    stop=rat(3,5)
    drop=mul(stop,tilt)
    after=sub(sub(xmax,p),stop)
    assert after[0]>0
    S=ZERO
    for j in range(nboxes):
        t=(rat(j,nboxes)[0],rat(j+1,nboxes)[1])
        y0=mul(sub(t,ONE),p)
        y1=mul(t,stop)
        y2=mul(sub(ONE,t),drop)
        y3=add(stop,mul(t,after))
        v1=mul(p,integrand(C,y0,tilt))
        v2=mul(stop,integrand(C,y1,tilt))
        theta=exponent_diff(C,stop,y2)
        v3=mul(drop,mul(exp(theta[0]),trig(theta[1])[1]))
        v4=mul(after,integrand(C,y3,ZERO))
        S=add(S,mul(rat(1,nboxes),add(add(v1,v2),add(v3,v4))))
    return S[0]-tail_bound(C,tail_x)[1]
