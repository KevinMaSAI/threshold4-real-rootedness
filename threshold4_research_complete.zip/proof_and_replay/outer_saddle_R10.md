# Extra joining interval 10≤R≤12

Use the notation and sign/phase framework of outer_saddle_R12.md.
We extend the radial curve and certify its relevant marker signs
down to radius 10. Global isolation is needed only on the actual
saddle branch for n≥3000, where one proves u>2.45 first.

For u≤π+.1<3.25 one has X≥.945R,
exp(X−R)>.58 by the fifth-order lower Taylor series,
1.48R≤w≤1.71R and |w'|≤3u/R. The derivative corrections
in the R12 proof of −w exp(R−X)χ' are bounded
by .035u for u≤π, and .072 for π≤u≤π+.1.
Thus −χ'>u/(47R) from the leading sinc bounds there:
.58(.1−.035)/1.71>1/47 and
.58(.295−.072)/(1.71·3.25)>1/47.
Integration yields loss >M(u²−u_p²)²/260 relative to
the unique first-arc maximum. For u≥2.75 one has
−wχ'>.115, since −sinc'(u)>.269 and the adverse
terms <.065, using cos u<−.92, sin u≥−.1 and the
maximum of the negative-f and positive-f error rather
than adding both (as in R12). So the integrated
real loss on u≥u_p≥2.75 is at least
.115·1.48·2.75 M(u−u_p)²/(2·1.71).
When written in x≡R θ this also implies .12M(x−p)²
since du/dx≥.945. These inequalities suffice for the
adapted tail estimate in phase_wide_R10_cell.py.

Radial monotonicity on the first arc is established before
needing its global isolation. For d≤π/2, the sharper identity
    d−sin d cos d = 2∫_0^d sin² t dt ≥ (2/3)d sin² d
follows from monotonicity of sinc on [0,π/2], which gives
sin t≥(t/d) sin d. Thus −J'≥(2/3)X d>.63Ru; with
|Y'|≤4.95Ru, |w'J|≤3u this implies strict increase of Y−wJ.
For d≥π/2 use −J'>.90Ru/sin²d and |w'J|≤3πu/sin²d,
which again suffices. Positivity and unboundedness of N_R(a)
follow as before from the initial N(R) and the 1+a factor.
The proof N'(R)>0 applies at R≥10 since
(4+R)E bounds 4E+R|E'| and is decreasing, with (4+10)E(10)<1
by exp(10)>22000. Hence the local saddle at fixed n
continues from R=12 to R=10 uniquely; n≥3000 is much
larger than N(12).

If u≤2.45, then f>.260−.78/(.945·10)>.177 and
exp(X−R)>.73. Thus a/(1+a)<13.3R exp(−R), giving a<.007
from exp(10)>22000. In the exact real radial relation
M exp(X−R)=(1+a)w/f, use the absolute bound on the
rotated exponential term. The right-hand side is at most
1.007(12+12²+12³/2+(1.71/.177)12²)<3000.
Therefore every relevant configuration n≥3000 has u>2.45.

For those configurations the far arc is indeed lower.
For angles after the expanded first arc but up to π/6,
the real S loss relative to u=π is at least
.1π·1.48R>.46R, and the envelope loss >.18M/R, by
integrating the e^(X−R) difference to u=π+.1.
For θ≥π/6 the Re S deficit from θ=0 is ≥.71R², by
the R12 quadratic bound .75−1/(2.84R) in its
exceptional segment and the other unchanged sectors.
The Re S deficit at u=π is <8.45R by
.75·9.87R+9.87+9.87/(1.945R)<8.45R.
We may bound the Re S loss relative to u=π below by
−1.35R. But the envelope has improved separation
there: e^(X(π)−R)>.60, and e^(R(cos θ−1))<.265,
so the exponential drops by >.335M. The assumption
u>2.45 gives f<.282−.73/12<.222, hence M>6.66R.
Actually the S loss is multiplied by 1+a and the saddle
gives M>6.66R(1+a). Thus
−1.35R(1+a)+.335M>.34R+.18M/R.
Thus the whole remote actual loss relative to u=π
is at least .34R+.18M/R. The upper critical angle
is the sole global maximum; the usual radial a
derivative from circle harmonicity now applies.

For high angles p≥2.8 on this joining strip,
u_p≥2.8−2.8³/(6·10²)>2.763. This gives f<.138−.92/R,
and then M>1.48R²/(.138R−.92)>289 (its least value
on [10,12] is at 12). Also π−u_p>arg z_p>.23,
which gives loss >.007M already from the saddle
to u=π by the .115 derivative estimate above.
Thus remote loss from the saddle is >.34R+.022M.

For the local real Gaussian use h=.2. The end of the
expanded first arc has x<3.31 by the cubic sine bound,
and p+.2 is inside that arc by π−u_p>arg z_p>.23.
On all x≥2.4 through the end, the rotated exponential
angle is within .766 of π; on |x−p|≤.2 it is within .762.
Use u≥2.4−2.4³/(6·10²) at the lower endpoint and
π+.1+2·3.31/10 at the upper endpoint.
Since e^(X−R)>.58 and |z²+z|/R²≥.9, and since the
S contribution is nonnegative, real curvature is
greater than .365M or .37M respectively.
Uniform real derivative caps of orders 2,3,4 are
still 3M,2M,2M by the explicit polynomials at R≥10.

Use (Q) with τ=.37M and derivative caps just given,
and the directly integrated Gaussian tails. Relative
local error <.181; reference tail <.133; true near
arc tail <.139, from M≥289. For x<2.4 real loss
at the boundary is ≥.365(.4)²M/2=.0292M; its
relative error <.007 using length 2.4. The remote arc
error <.029 by 2.8·10·exp(−3.4) sqrt(289) exp(−.022·289).
All decrease beyond these endpoints. Their sum is below
1/sqrt(2). This leaves only a finite continuous rectangle
10≤R≤12, 2.45≤u≤2.8 for the directed proof.
That code uses 20 arcsin Taylor terms (tail <(1/3)^41/(1−1/9)),
u at x=3.24 at least .982x, and the present angular and
remote lower losses instead of the R12 bounds.
