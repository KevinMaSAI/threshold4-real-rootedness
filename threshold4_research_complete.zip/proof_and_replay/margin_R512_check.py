"""Directed margin checks for the continuum estimates at R>=512."""
from fractions import Fraction as F
from angular_certificate import Q, ONE, add, sub, mul, sq, exp, trig, point, neg, scale
from phase_k_certificate import PI, rat, quo, root
def b(s):
    x=F(str(s)); return rat(x.numerator,x.denominator)
def m(*args):
    out=ONE
    for a in args:out=mul(out,a)
    return out
def upper(x,s):
    assert x[1]<b(s)[0],(x[1]/Q,s)
def lower(x,s):
    assert x[0]>b(s)[1],(x[0]/Q,s)
def inv(x):return quo(ONE,x)
def damp(x):return exp(neg(x))
def power(x,k):return m(*[x]*k)
R=b(512); M=m(b('1.49'),R); sqrtM=root(M)
def qerror(t,S,U,p,v):
    return m(inv(v),root(quo(S,t)),add(quo(m(U,p),m(b(8),sq(t))),
                                 quo(m(b(5),sq(U)),m(b(24),power(t,3)))))
def tailG(a,S,v,h):
    return m(quo(m(b(2),root(quo(S,scale(PI,2)))),m(a,h,root(v))),
             damp(m(b('.5'),a,sq(h),v)))
def tailE(a,S,v,h):
    return m(quo(root(quo(S,scale(PI,2))),m(a,h,root(v))),
             damp(m(a,sq(h),v)))
lower(sub(m(b('.5'),trig(b('.5'))[0]),quo(b('7.5'),R)), '.423')
upper(add(m(add(ONE,quo(b(16),R)),exp(add(b('.275'),quo(b('.596'),R)))),quo(b(42),power(R,3))),'1.37')
upper(m(b(10),sqrtM,damp(m(b('.015'),M))),'.01')
upper(m(b(10),power(sqrtM,3),damp(quo(M,b(20)))),'.01')
upper(quo(b(2),m(sq(b('.059')),b('.423'),M,sq(b('.98')))),2)
assert F('.9125')*F('.925')*F('.65')-F('.75')*F('.1787')-F(45,512)>F('.32')
assert F('.295')*F('1.4')/(8*F('1.6'))*((F('.99')*F('.98'))**2-F('.5')**2)**2>F('.015')
h=b('.35'); t,S,U=b('.32'),b('1.44'),b('1.76');v=b('109.7')
assert quo(m(PI,b(18)),b('.515'))[0]>v[1]
upper(qerror(t,S,U,b('.5'),v),'.402')
upper(tailG(t,S,v,h),'.096')
upper(tailE(b('.21'),S,v,h),'.038')
upper(m(b(2),add(inv(b('.05')),inv(b('.08'))),inv(sqrtM),damp(m(b('.015'),M))),'.001')
upper(m(b('1.25'),add(b(F(13,12)),quo(b(30),R))),'1.44')
upper(m(b('1.5625'),add(exp(b('.0875')),quo(b(15),R))),'1.76')

# Trigonometric lower bounds and exponent slope caps in the chosen local intervals.
for x,lim in [('.832','.88'),('1.152','.79'),('1.375','.71'),('1.625','.61'),('1.875','.50')]:
    lower(quo(trig(b(x))[1],b(x)),lim)
for rate,right,a in [('.14','.65','.147'),('.14','.9','.15'),('.10','1.1','.106'),
                      ('.10','1.3','.108'),('.10','1.5','.11')]:
    upper(exp(m(b(rate),b(right))),1+F(a)*F(right))
for y,lim in [('.091','.909'),('.126','.874'),('.11','.89'),('.13','.87'),('.15','.85')]:
    # Strict positive exponential lower bound may exceed liberal elementary cap.
    if y in ('.091','.126','.11','.13','.15'):
        assert 1-F(y)>=F(lim)
upper(m(b('1.25'),add(add(ONE,quo(b('.65'),b(6))),quo(b(30),R))),'1.47')
upper(m(b('1.5625'),add(exp(b('.091')),quo(b(17),R))),'1.77')
upper(m(b('1.25'),add(b('1.15'),quo(b(40),R))),'1.54')
upper(m(b('1.5625'),add(exp(b('.126')),quo(b(20),R))),'1.84')
assert F('.909')*F('.88')*F('.72')-F('.75')*F('.103')-F('1.25')*15*F('2.29')/512>F('.41')
assert F('.874')*F('.79')*F('.72')-F('.75')*F('.094')-F('1.25')*20*F('2.29')/512>F('.31')
for lo,hi,t,S,U,alpha,cap in [
    ('.5','.65','.41','1.47','1.77','.20','.591'),('.65','.9','.31','1.54','1.84','.17','.382')]:
    v=m(M,power(b(lo),3)); h=b('.28'); t,S,U=b(t),b(S),b(U)
    bounds=add(qerror(t,S,U,b(hi),v),add(tailG(t,S,v,h),tailE(b(alpha),S,v,h)))
    upper(bounds,cap)
upper(m(b(5),sqrtM,damp(m(b('.02'),M))),'.001')

upper(m(b('1.3456'),add(exp(b('.15')),quo(b(F(14)*F('1.167')+F('2.08')+5),R))),'1.63')
assert F('1.16')*(1+F('1.5')/6+F(35)/(F('.9')*512))<F('1.54')
assert F('.62')-F(35,512)>F('.4')*F('1.30')
assert F('.8')*F('.89')*F('.71')*F('.75')-F('.84')*F('.013')-F('1.16')*15*F('2.26')/512>F('.29')
assert F('.8')*F('.87')*F('.61')*F('.75')-F('1.16')*20*F('2.26')/512>F('.21')
assert F('.8')*F('.85')*F('.5')*F('.75')+F('.84')*F('.009')-F('1.16')*35/(F('1.3')*512)>F('.2')
for c,L in [('.0215','.004'),('.033','.0062')]:
    assert F(c)*F('.999')**4*(F('.25')*F('1.75'))**2>F(L)
for f,L in [('.20','.018'),('.268','.028')]:
    assert F(f)*F('.999')**4*F('.4375')*F('1.5')/(4*F('1.51'))>F(L)
for lo,hi,t,A,B,C,cap in [
    ('.9','1.1','.29','.0062','.028','.018','.282'),
    ('1.1','1.3','.21','.004','.018','.011','.229'),
    ('1.3','1.5','.20','.004','.018','.011','.129')]:
    p=b(lo);v=m(M,power(p,3));e=damp(m(b(A),v,p))
    near=m(quo(b('.94'),m(b(B),sqrtM,sq(p),root(p))),e)
    vert=m(b('.095'),root(v),e)
    left=m(b('.235'),root(v),damp(m(b(C),v,p)))
    sum_all=add(add(near,vert),add(left,
         add(qerror(b(t),b('1.54'),b('1.63'),b(hi),v),tailG(b(t),b('1.54'),v,b('.25')))))
    upper(sum_all,cap)
upper(m(b(4),sqrtM,damp(m(b('.021'),M))),'.001')
q=512
assert F('1.001')*(q+q*q+F(q**3,2))<67_500_000
print('VERIFIED outward-rational R512 Airy, Gaussian, and tail constants')
