# 阈值 4 实根性：第三轮夜间研究

目前严格得到三段结论：
- 0≤n≤1024（精确有限验证）；
- 16376≤n≤3520607（对连续鞍点参数的一致符号证明）；
- n≥4,400,000,000（有效的无穷尾部证明）。

在这些范围内，所有非常数多项式的根均是互异负实根。
尚未解决原题，也未找到反例。两个未覆盖区间为
1025≤n≤16375、3520608≤n≤4399999999。
中段证明是统一控制积分符号，不是逐一验算数百万个多项式。

本轮的主要新点：在小相位编号的 Airy 比较中，把四次扰动显式积分，
发现该项和 Airy 主项同号。不再用绝对值把它误当成全部首阶误差。
剩余误差可用一维精确有理积分压到主项的四分之一以内。再结合缩紧的
倾斜高斯积分估计，外侧统一有效半径从 R≥4096 改进为 R≥2048，
原题有效无限尾界从 350 亿降为 44 亿。
读 phase_R2048_quartic.md、phase_R2048_gaussian.md、full_tail_4_4b.md。
用 phase_mid_band_192_joint.md 与旧的中段证明逐段拼接。

可独立重放本轮关键运行（Python 标准库，无浮点真伪判断）：
    python3 airy_quartic_error_check.py
    python3 margin_R2048_check.py
    python3 phase_small_thresholds.py
    python3 phase_wide_certificate.py --tilted --radius 160 192 --angle 31/100 13/10 --grid 48 100 --boxes 176
    python3 phase_wide_certificate.py --radius 160 192 --angle 13/10 5/2 --grid 32 60 --boxes 112

另有严格辅助反例：一个三元块插值的 Bézout 行列式在 n=10 时
有 4 个非实根。它不反驳原多项式，也不反驳该行列式在非负参数的
正性，只否定用该辅助行列式实根性证明其正性的策略。
见 auxiliary_lag_det_obstruction.md。
原问题、阈值 2、3 的来源与文献检索状态见 night_checkpoint_readme.md。
程序实测耗时：Airy 校验 0.506 秒，R2048 常数校验 0.041 秒；
R160–192 的低角与宽角证明分别 33m02.689s、3m29.071s。
多项工作并行，不能据此直接得到整轮墙钟耗时。工具未返回总 token 或计费量。
未联系作者、发帖、投稿或付费。
