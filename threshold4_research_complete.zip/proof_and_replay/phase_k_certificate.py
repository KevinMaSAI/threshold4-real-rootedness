"""Validated sign at H=-pi over a continuous radius strip; all enclosures dyadic."""
from math import isqrt, factorial, comb
from fractions import Fraction as F
from argparse import ArgumentParser
from angular_certificate import Q, ONE, ZERO, add, sub, mul, sq, neg, div, scale, point, exp, trig, widen

def rat(a,b=1):
    return a*Q//b,-((-a*Q)//b)
def pi_box():
    def arctan_reciprocal(n):
        v=sum(F((-1)**j,(2*j+1)*n**(2*j+1)) for j in range(20))
        return v,v+F(1,41*n**41)
    al,au=arctan_reciprocal(5); bl,bu=arctan_reciprocal(239)
    l=16*al-4*bu; u=16*au-4*bl  # Machin identity
    return rat(l.numerator,l.denominator)[0],rat(u.numerator,u.denominator)[1]
PI=pi_box()
def quo(a,b):  # b>0
    assert b[0]>0
    l=[x*Q//y for x in a for y in b]
    u=[-((-x*Q)//y) for x in a for y in b]
    return min(l),max(u)
def root(a):
    assert a[0]>=0
    return isqrt(a[0]*Q),isqrt(a[1]*Q)+1

def asn(x):
    assert 0<=x[0]<=x[1]<=Q//10
    x2=sq(x); p=x; S=ZERO
    for j in range(12):
        S=add(S,mul(p,rat(comb(2*j,j),4**j*(2*j+1))))
        p=mul(p,x2)
    return (S[0],S[1]+1)

def g(x):
    # sin x - x cos x
    assert 0<=x[0]<=x[1]<=3*Q//2
    x2=sq(x); p=mul(x2,x); S=ZERO
    for j in range(1,12):
        term=div(scale(p,2*j),factorial(2*j+1))
        S=add(S,term if j%2 else neg(term))
        p=mul(p,x2)
    return widen(S,1)

def phase(R,u):
    R2=sq(R);R3=mul(R2,R)
    X=root(sub(R2,sq(u))); gap=neg(quo(sq(u),add(R,X)))
    c,s=trig(u); th=asn(quo(u,R))
    w=add(rat(2),quo(add(ONE,sub(div(scale(R2,3),2),scale(sq(u),2))),X))
    f=add(quo(s,u),quo(c,X))
    mod=exp(gap); mu=quo(w,mul(mod,f))
    C=quo(ONE,sub(ONE,mul(mu,exp(neg(R)))))
    M=mul(mu,C)
    sp=add(mul(R,g(th)),add(div(mul(R2,g(scale(th,2))),2),div(mul(R3,g(scale(th,3))),6)))
    big=add(g(u),add(mul(mul(R,g(th)),c),mul(mul(th,u),s)))
    H=sub(mul(C,sp),mul(mul(M,mod),big))
    return H,(R,(X,u),mul(R,th),C,M,(mul(mul(M,mod),c),mul(mul(M,mod),s)))

def configuration(A,k):
    lo=rat(3,10)[0]; hi=rat(14,10)[1]
    def H(x):return add(phase(A,point(x))[0],scale(PI,k))
    assert H(lo)[0]>0 and H(hi)[1]<0
    L,Hh=lo,hi
    for _ in range(24):
        mid=(L+Hh)//2
        if H(mid)[0]>0: L=mid
        else: Hh=mid
    lower=L
    L,Hh=lo,hi
    for _ in range(24):
        mid=(L+Hh)//2
        if H(mid)[1]<0:Hh=mid
        else:L=mid
    upper=Hh
    assert lower<upper and H(lower)[0]>0 and H(upper)[1]<0
    return phase(A,(lower,upper))[1]

def cadd(a,b):return add(a[0],b[0]),add(a[1],b[1])
def csub(a,b):return sub(a[0],b[0]),sub(a[1],b[1])
def cmul(a,b):
    return (sub(mul(a[0],b[0]),mul(a[1],b[1])),
            add(mul(a[0],b[1]),mul(a[1],b[0])))
def cscale(a,b):return mul(a[0],b),mul(a[1],b)
def cdiv(a,k):return div(a[0],k),div(a[1],k)
COEF=[rat(1,factorial(j)) for j in range(2,25)]
E2TAIL=rat(2*4**25,factorial(25))[1]
def E2(a,small=False):
    # exp(a)-1-a, stable as a^2 times an analytic series.
    assert sum(max(abs(k) for k in p) for p in a)<=4*Q
    count=11 if small else 24
    r=(ZERO,ZERO)
    for j in range(count,1,-1):
        r=cadd(cmul(a,r),(COEF[j-2],ZERO))
    r=cmul(cmul(a,a),r)
    # For small q in this proof |q|<=1/4 (otherwise use the long form).
    if small:
        assert sum(max(abs(k) for k in p) for p in a)<=Q//4
        tol=rat(2,4**12*factorial(12))[1]
    else:
        tol=E2TAIL
    return widen(r[0],tol),widen(r[1],tol)

def ordinates(C,X,segment):
    R,z,p,a1,M,aE=C
    u=sub(X,p)
    b=rat(2,5); end=rat(140,100); cap=rat(10,100)
    if segment==0:
        v=mul(b,u); dydx=b
    elif segment==1:
        v=mul(b,mul(u,quo(sub(end,X),cap)))
        dydx=mul(b,quo(sub(sub(end,X),u),cap))
    else:
        v=ZERO; dydx=ZERO
    q=(neg(quo(v,R)),quo(u,R))
    q2,q3=cscale(q,rat(2)),cscale(q,rat(3))
    E=E2(q,True)
    dz=cmul(z,cadd(q,E))
    z2=cmul(z,z);z3=cmul(z,z2)
    phase=cscale(cadd(cmul(z,E),cadd(cmul(cdiv(z2,2),E2(q2,True)),
                                   cmul(cdiv(z3,6),E2(q3,True)))),a1)
    phase=csub(phase,cmul(aE,cadd(E2(dz),cmul(z,E))))
    cs,sn=trig(phase[1])
    return mul(exp(phase[0]),sub(cs,mul(dydx,sn)))

def verify_cell(A,k,nboxes=192):
    C=configuration(A,k)
    # Use dyadic breakpoints defining the same contour, with rational cutoffs
    # appearing as interval bands at endpoints. Integrate over each exact
    # rational-width subdivision with an outward-rounded endpoint enclosure.
    total=ZERO
    for segment,(start,end) in enumerate([(0,130),(130,140),(140,300)]):
        h=rat(end-start,100*nboxes)
        for j in range(nboxes):
            a=rat(start*nboxes+(end-start)*j,100*nboxes)[0]
            b=rat(start*nboxes+(end-start)*(j+1),100*nboxes)[1]
            total=add(total,mul(h,ordinates(C,(a,b),segment)))
    # At x=3 the angular real gap at u>=.99*3 is at least M/3.
    # The rest of first arc is decreasing after the maximum, and after u=pi
    # compare to the value there. pi R < 4 R bounds the remaining length.
    R,z,p,a1,M,aE=C
    assert rat(297,100)[0]>z[1][1]  # positive difference, then square
    diff=FRACTION_GAP(z[1][1])
    tail=mul(scale(R,4), pow_three_eighths(int(diff*F(M[0],Q))))
    low=total[0]-tail[1]
    return low, total[1]+tail[1]

def FRACTION_GAP(u):
    return (F(297,100)**2-F(u,Q)**2)**2/200

def pow_three_eighths(k):
    if k>128:return (0,1)
    return rat(3**k,8**k)

def main():
    parser=ArgumentParser()
    parser.add_argument('--phase',type=int,default=2)
    parser.add_argument('--lo',type=int,default=48)
    parser.add_argument('--hi',type=int,default=49)
    parser.add_argument('--pieces',type=int,default=32)
    parser.add_argument('--boxes',type=int,default=192)
    opts=parser.parse_args()
    a=opts.lo*Q;b=opts.hi*Q;num=opts.pieces
    margins=[]
    todo=[((a+(b-a)*j//num,a+(b-a)*(j+1)//num),0) for j in range(num-1,-1,-1)]
    while todo:
        A,dep=todo.pop()
        low,high=verify_cell(A,opts.phase,opts.boxes)
        if low<=0:
            if dep>=4:raise ArithmeticError('inconclusive box', A[0]/Q,A[1]/Q,low/Q,high/Q)
            mid=(A[0]+A[1])//2
            todo.extend((((mid,A[1]),dep+1),((A[0],mid),dep+1)))
        else:
            margins.append(low)
    print('VERIFIED H=-k*pi k=',opts.phase,'strip',opts.lo,opts.hi,'with',len(margins),'radius boxes;',
          'integer lower bound on positive normalized half integral:',min(margins),'/',Q)

if __name__=='__main__':main()
