# Lowering the complete outer angular threshold to R=24576

This improves phase_R65536_lowtilt.md (for 1/8≤p≤.5) and
phase_R32768_tilt.md (for .5≤p≤1.5). All model/setup
estimates in the original two documents are valid with the
following explicit adjustments.

For R≥24576, w≥1.5R and f≤1+1/(.99R) give M≥1.49R.
Then for .5≤p≤1.5, M≥32768 and 30/R<.0015, exactly the
conditions used in the proof and error bounds of
phase_R32768_tilt.md. Its derivative estimates were derived
using the same uniform model; lowering R to 24576 leaves all
their claimed constants valid. Its far arc estimates likewise
hold on R≥24576. Thus its sign proof transfers verbatim.

For 1/8≤p≤.5, keep the slope .5 and the same local half-width
h=.35p of phase_R65536_lowtilt.md. Use sin x≥.925x on
0≤x≤.675 (alternating Taylor bound in x² for sinc .675),
and strengthen the first bracket bound there:
\[
\text{sinc}(p)-e^{-y}\cos x
 \ge (.21125-1/6)p^2-.00744p^4-.184p
 \ge -.1787p .
\]
The last inequality follows from p²≤.25 and p≥.125.
Then the local tilted curvature is still >.4 M p, because
.9125·.925·.65 − .75·.1787 − 37.5/(24576·.125) > .4.
The derivatives after tilting are still ≤1.72 M, since
1.5625(e^.0875+30/24576)<1.72. The stationary tilted
Hessian is still <1.4 Mp. Consequently all local (Q) estimates
remain unchanged.

On the full slope line and its endpoint vertical constrictions,
the simplex error is now ≤25/24576. Keep the same lower
Re L bounds .26 and .43, replacing the upper absolute
Im L bounds .121 and .108 by .122 and .109 respectively.
The resulting attenuation coefficients on the right and
left still exceed .085 and .18, so the exterior tilted
integral remains bounded in relative value by
8 exp(−.020825Mp³)/sqrt(Mp³). The ending vertical and the
remote real arcs retain the same bounds as before.

For the missing reference Gaussian tail use the directly integrated
inequality 2 e^(−τh²/2)/(τ h) for absolute tail area, which is
stronger here than the previous exponential-splitting bound.
Multiplying by the original tilted Gaussian normalization
sqrt(1.4Mp/(2π)) gives at most
\[
 6.8\,\exp(-.0245Mp^3)/\sqrt{Mp^3}.
\]
For R≥24576, p≥1/8 we have M≥36618 and Mp³≥71.52;
each of the following ratios is below the indicated bound:
\[
\begin{array}{c|c}
\text{local Q error}&.287\\
\text{reference Gaussian tail}&.14\\
\text{tilted-line exterior}&.215\\
\text{vertical return and first arc}&.02\\
\text{remote arc}&.01
\end{array}
\]
For the first use 20.5/(Mp³), for the next two substitute
the minimum Mp³, for the fourth use 5√M exp(−.0003M),
and for the last use the original optimized bound in R.
These are monotone at the lower endpoints and can be checked
using positive Taylor polynomials for the denominators e^x.
The total is <.672<1/√2. This proves the exact signs throughout
R≥24576 and 1/8≤p≤.5. Combining with the other sector theorems
shows **all exact markers on R≥24576 have the required sign**,
including the cusp k=0 by its separate estimate.
