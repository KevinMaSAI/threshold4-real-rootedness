# Rigorous high-angle bound at M ≥ 4096

This partially replaces the M≥10^6 demand in the original saddle proof:
for its stationary configuration R≥32, p≥2.9, M=a e^R≥4096, at every
exact phase H=−kπ the sign of the integral is (−1)^k. Here p=R arg z_p,
not u_p=Im z_p. All notation and the required geometric tail estimates
are from big_blocks4_explicit_tail_18.md §1. The small and middle angle
cases are not covered by this argument.

## 1. Local bound

Write z=R exp(ix/R), Ω(x)=F_a(z)−inx/R, and choose the real segment
|x−p|≤.1. It is on the extended first arc where u=Im z≤π+.1, since
u(p)=u_p<π and |du/dx|≤1. Down to its lower endpoint, u≥.99x≥2.772.
The geometric derivative formulas in the cited section give
|Ω''|≤3M and |Ω'''|≤2M on real arguments. In addition,
we have the stronger lower bound −Re Ω''(x)>.7M throughout the segment.

Indeed −Ω''=[(1+a) D²S(z)−M e^(z−R)(z²+z)]/R², where D=z∂z.
The D²S term has nonnegative real part, because each term has positive
coefficient and 3arg z≤3·3.25/32<π/2. Since 0≤arg(z+1)≤arg z,
the argument of e^(z−R)(z²+z) equals u+arg z+arg(z+1) modulo 2π.
Here 2.772≤u≤π+.1, arg z≤3.25/R. The angle is within .37 of π
(using 3.14159<π<3.14160), so its cosine is at most
−(1−.37²/2)<−.93. Further |z²+z|≥R²−R and e^(Re z−R)>.8.
This proves the curvature because .8·.93·(1−1/32)>.7.
For the angle upper bound one can directly use arg z=arcsin(u/R)
and R arg z≤3.25 for R≥32, u≤π+.1; sin(3.25/R)≥
3.25/R−(3.25/R)^3/6 verifies this.

## 2. Gaussian reference and errors

Let σ=−Ω''(p), τ=.7M, h=.1. Normalize by exp Ω(p) in the positive
half-integral. With y=x−p, Taylor and stationarity give
Re(Ω(p+y)−Ω(p))≤−τ y²/2 and remainder magnitude
|Ω(p+y)−Ω(p)+σ y²/2|≤(M/3)|y|³ for |y|≤h.
The identity integrating the exponential along the straight segment
between the two exponents gives
difference in the local integrands ≤(M/3)|y|³ e^(−τ y²/2).
Thus the absolute local error is at most 4M/(3τ²).
Relative to the complex Gaussian module |G|=sqrt(2π/|σ|),
this is <3/sqrt(M), since |σ|≤3M. The real part of G is
≥|G|/sqrt(2) because Re σ>0 and the Gaussian uses the principal square
root. The two missing Gaussian tails, relative to |G|, are less
than (30/sqrt(M)) exp(−.0035M), by the bound
2 exp(−τ h²/2)/(τ h) and |σ|≤3M.

The first expanded real arc outside the segment stays below
Re Ω(p)−τ h²/2: the real part increases up to p and decreases after p,
and both endpoints were bounded by curvature. The length of this
positive-side arc is <4, so its relative tail is ≤
4 sqrt(M) exp(−.0035 M), using sqrt(3/(2π))<1.
The remote arc has real loss ≥sqrt(M)/4 by §1 of the old proof,
so its relative contribution is ≤4 M^(3/2) exp(−sqrt(M)/4),
using its length ≤4R and R≤M.

For M≥4096 these four relative bounds are, respectively,
<.047, <.01, <.01, and <.20. For the last, the function is decreasing
in sqrt(M)≥64, and 4·64³ (3/8)^16 < 1/5. The other estimates follow
by monotonicity at M=4096 using e>8/3 as well. Their sum is below
1/sqrt(2), so the normalized real half integral is strictly positive.
At H=−kπ the factor exp Ω(p) has real sign (−1)^k. Reflection gives
the other half and the positive remaining prefactor cannot change
the claimed polynomial sign.

This closes the large-angle, moderate-to-large M region. It does
not automatically lower the overall n cutoff: the estimates near
p=0 and intermediate p are separate, and one still needs to attach
the large-radius saddle estimates to the compact radius and distant
root regimes.

## 3. Sharpening: all high-angle stationary configurations

In fact this sign theorem holds for R≥32 and p≥2.9 without
any extra M hypothesis. We give details because this is precisely
the region in which finite interval quadrature becomes expensive.

First u_p≥.99p≥2.871. The function f(u_p) is positive at the
stationary point. Since cos(u_p)<0, sin(u_p)≤π−u_p and π<22/7,
we have f(u_p)≤(22/7−2.871)/2.871. Thus
M≥M/(1+a)=w/(e^(X−R)f)>470 using w≥1.4R and R≥32.

We extend the real curvature bound to all 2.5≤x≤x_end,
where x_end is the end of the expanded first arc (Im z=π+.1).
The angle of e^(z−R)(z²+z) now lies within .67 of π:
u≥.99·2.5=2.475 and u+2arg z≤π+.1+2·3.25/32.
Thus its cosine is at most −(1−.67²/2); the same calculation
as in §1 above gives −Re Ω''(x)>.58M on this whole interval.
Since p≥2.9, x=p is in the interval, and Taylor's formula with
an integral remainder gives real loss ≥.29M(x−p)² for every
x in the interval. Below x=2.5 the first arc is still increasing
toward p, so its real loss is at least .29M(.4)²=.0464M.

We also strengthen the remote loss in the prior geometry from
R/10+M/(5R) to (2/5)R+M/(5R), relative to the value at u=π.
Here is the verification. As u increases from π to π+.1, the loss
in Re S is the integral of u w(u); from π>3 and w≥1.4R it exceeds
.42R. Moving farther in angular coordinate up to π/6 only decreases
Re S because the derivative is the negative sum of the three
positive sine terms. For θ≥π/6 within π/12 of 2π/3, the loss in
Re S relative to θ=0 is at least R²/2 (cos 2θ≤0); elsewhere in
θ≥π/6 it is at least R³/24 (cos 3θ≤√2/2). The loss at u=π
is less than 13R, by applying 1−cos y≤y²/2 to the three
terms, using θ≤3.25/R. Both R²/2−13R and R³/24−13R exceed
.4R for R≥32. Finally the exponential term loses at least M/(5R)
beyond the expanded arc, as in the previous proof by comparing
the exponentials of the real coordinates; explicitly Xπ−X_(π+.1)
≥π/(10R), exp(X_(π+.1)−R)>.8. Adding the S loss gives the
strengthened estimate. Since the saddle maximizes the real part on
the first arc, these loss bounds relative to u=π also bound loss
relative to p.

Now use the same Gaussian G, local h=.1 and τ=.7M.
With sqrt(3/(2π))<.7, local error / |G| ≤2/sqrt(M).
The missing reference tails / |G| are at most
20 exp(−.0035M)/sqrt(M). The actual first-arc tails with x≥2.5
are bounded relatively by 25 exp(−.0029M)/sqrt(M), using the
integrable quadratic decay .29M(x−p)² on each side starting
at |x−p|=.1, rather than charging the whole interval.
The tail x<2.5 is no more than 2 sqrt(M) exp(−.0464M) relatively.
For the remote piece use the length bound 4R and optimize over M:
sqrt(M) exp(−M/(5R)) ≤ sqrt(5R/2), so its relative bound is
at most (14/5) sqrt(5/2) R^(3/2) exp(−.4R).
Each of the first four error bounds decreases for M≥470, the
last decreases for R≥32. In that order they are strictly less
than .10, .19, .31, .001, and .01. For example sqrt(470)>21,
exp(1.645)>101/20 and exp(1.363)>39/10 by the first seven
Taylor terms. For the remote bound use exp(.4·32)> (8/3)^12,
sqrt(5/2)<8/5 and sqrt(32)<6. The sum is less than .62<1/√2.
The Gaussian comparison therefore proves the exact sign (−1)^k
for every real saddle configuration with R≥32 and p≥2.9.

This removes this high-angle region from the list of open
subproblems, not the smaller-angle or lower-radius regions.

## 4. Adding 2.5 ≤ p ≤ 2.9 without extra M conditions

The preceding theorem extends to p≥2.5. It suffices to treat
2.5≤p≤2.9. First u_p≥2.475 and
M≥1.4·32/f(u_p)>177. For the latter use
f(u_p)≤sin(u_p)/u_p, monotonicity of sin on [2.475,π],
and sin(π−2.475)≤d−d³/6+d⁵/120 at d=22/7−2.475,
where the polynomial is increasing below .67. Dividing this upper
bound by 2.475 gives M>177 by exact rational arithmetic.

The real Gaussian segment is now |x−p|≤.25, so 2.25≤x≤3.15,
strictly inside the original expanded first arc. On the entire
first arc, e^(Re z−R)>.83 by e^(-v)≥1−v and
v=u²/(R+√(R²−u²)), with u≤3.25 and R≥32. On the local segment,
u≥2.2275 and the phase of e^(z−R)(z²+z) is within .916 of π.
Hence −Re Ω''>.46M there, as
.83(1−.916²/2)(31/32)>.46. The same argument on
2.15≤x≤x_end gives −Re Ω''>.38M: use u≥2.1285 and
distance from π at most 1.015. On 1.8≤x≤2.15 the distance from
π is <1.36 (u≥1.782, u+2arg z≤2.15+2·2.15/32<π),
so Re Ω''<0 there as well. In these ranges the real part of
D²S stays positive as before.

Taylor at the saddle on x≥2.15 gives real loss ≥.19M(x−p)².
For 1.8≤x<2.15, from the loss and slope at 2.15 and concavity
on [1.8,2.15], the loss is at least
(.19·.35²)M+(.38·.35)M(2.15−x).
For 0≤x<1.8 the same lower bound evaluated at x=1.8 is valid
by monotonicity up to the saddle.

Apply the comparison of §2 with h=.25 and τ=.46 M. The local
relative integrand error is <4.5/sqrt(M); the Gaussian's missing
tails have relative bound 12.2 exp(−.014375M)/sqrt(M).
The actual tails on x≥2.15 (inside the first arc) have bound
15 exp(−.011875M)/sqrt(M), by the .19M decay and Gaussian tail
integral. On 1.8≤x<2.15, the linear loss gives at most
5.3 exp(−.023275M)/sqrt(M); below 1.8 the relative bound is
1.3 sqrt(M) exp(−.069825M). These five terms decrease for
M≥177 and are below .347, .076, .145, .008, and .001
respectively. To see the estimates directly, use sqrt(177)>13,
sqrt(177)<14 for the appropriate numerators, the Taylor partial
sums of exp at 2.54, 2.1 and 4.11, and e>8/3 at exponent >12
for the last term. The remote tail is still less than .01,
using the geometric strengthening of §3, which did not depend
on p. Summed together the errors are <.587<1/√2, proving
the required sign.

Thus the original large-R saddle theorem now needs smaller-angle
estimates only, 0≤p<2.5. This is a region theorem for exact phase
markers; it is not an all-root count for new values of n.
