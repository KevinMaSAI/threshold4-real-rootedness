"""Exact sign certificates for the four largest-magnitude root intervals.
Uses a polynomial in x=1/m after truncation in k, with exact tail bound.
"""
from fractions import Fraction as F
from math import factorial

M=2304
K=24
SAMPLES=[
    [275,589,903,1217],
    [353,668,982,1296],
    [432,746,1060,1374],
    [511,825,1139,1453],
]
Q=F(11,32)
TAIL=2*3**67*Q**100

def prod_linear(poly,c):
    out=[0]*(len(poly)+1)
    for j,v in enumerate(poly):out[j]+=v;out[j+1]-=c*v
    return out

def multiply(P,Q,d):
    R=[F(0)]*(d+1)
    for j,x in enumerate(P):
        if x:
            for k,y in enumerate(Q[:d-j+1]):
                if y: R[j+k]+=x*y
    return R

def major_polys():
    Lmax=4*K+3
    A=[F(1)]
    for n in range(1,Lmax+1):
        A.append(sum(A[n-j]/factorial(j-1) for j in range(1,min(n,3)+1))/n)
    delta=[F(0)]+[F(24,factorial(j+4)) for j in range(1,Lmax+1)]
    powers=[A]
    for _ in range(Lmax):
        powers.append(multiply(powers[-1],delta,Lmax))
    row=[]
    for r in range(4):
        X=[]
        for k in range(K+1):
            L=4*k+r
            h=[F(0)]*(L+1)
            p=[1]
            for j in range(L+1):
                a=5**L*powers[j][L]/factorial(j)
                if a:
                    for i,x in enumerate(p):
                        h[L-j+i]+=a*x
                p=prod_linear(p,k+j)
            for i in range(k):
                h=prod_linear(h,i)
            X.append(h)
        row.append(X)
    return row

def certify():
    rows=major_polys()
    for r in range(4):
        assert 0<SAMPLES[r][0]<SAMPLES[r][1]<SAMPLES[r][2]<SAMPLES[r][3]<1500
        for j,p in enumerate(SAMPLES[r],1):
            v=F(p,100)
            coeff=[F(0)]*(max(map(len, rows[r])))
            for k,h in enumerate(rows[r]):
                w=(-4)**k*v**(4*k+r)
                for i,a in enumerate(h):
                    coeff[i]+=a*w
            a0=(-1)**j*coeff[0]
            err=sum(abs(a)/M**i for i,a in enumerate(coeff) if i)+TAIL
            assert a0>err
            print('r',r,'v',str(v),'sign',(-1)**j,
                  'rigorous relative error upper decimal (for display only)',float(err/a0))
    print('CERTIFIED all 16 signs for every integer m >=',M)

if __name__=='__main__':certify()
