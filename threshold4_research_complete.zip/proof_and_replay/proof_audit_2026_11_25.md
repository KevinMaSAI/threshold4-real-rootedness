# Reverse audit of the threshold-four proof

This is a check of the proof for the exact unordered, labelled problem.
It is not an external referee report and does not certify consecutive
interlacing, other thresholds, or any modified model.

## Model and root count

Independently derived both the exponential formula and the insertion
recurrence. Marking size at least four gives A(z) exp(tB(z)) with
A=exp(z+z²/2+z³/6). Insertion into a size-r block removes exactly r
old labels; r=1,2 preserve the exponent, r=3 adds one, and
already-marked blocks give k choices in coefficient a_(n,k).
The minimum-label distinguished-block enumeration and the integer
exponential generating function convolution agree with the recurrence,
and reproduce P_4=14+t and P_8=2780+1325t+35t².
There is no omission of partitions with 1-, 2- or 3-element blocks.
The leading coefficient of degree floor(n/4) and the constant
coefficient are positive by explicit partitions.

The sign brackets in the large-n argument lie strictly at negative
t, do not intersect each other, and do not overlap the last root
strictly to the left of the anchor. There is no premise that a
fraction of real roots suffices to force the rest. The count is
exactly the polynomial's whole degree, counting different brackets
and using continuity, and therefore forces simple roots with no
further nonreal or repeated root. Consecutive interlacing is not
inferred from this one-polynomial argument.

## Saddle equations, phase, and joins

For z=X+iu in the first arc, the independent derivative calculation
uses X'=-u/X and gives
 `∂_u Re S=-u[2+(1+3R²/2−2u²)/X]`.
Also ∂_u Re exp(z−R)=−u exp(X−R)[sin u/u+cos u/X].
This yields the exact angular maximum identity. The real radial
numerator is Y=(X+R²−2u²+X(R²−4u²)/2) and the exponential term
uses X cos u−u sin u. Division by f turns it into X u cot(d)
with d=u+arcsin(u/R). Thus the real and imaginary stationary
equations are for the same F_a.

At the real merging point, a_c=D²S/D²B, and independently
 (R+1)DS−D²S=R⁴/2,
giving N(R)=R⁴/[2(R+1−exp(−R)(1+2R+3R²/2))].
The large-n branch starts at the continuous cusp with H=0.
At each inner radius the certified upper maximum is unique and
its radial value is strictly increasing in the available parameter.
The λ and μ rescalings have positive scale factors at fixed R.
The physical parameter a changes in the required strict direction
on the same curve by harmonicity of the actual real part
of F_a; it is not inferred from sorting the phase values.
The phase H=Im F_a−nθ is an actual continuous real quantity
with the angle always in the same 0≤θ≤π arc. It is not
computed modulo 2π. First successive level hits exist by
continuity even without monotonicity of H along the fixed-n curve.

The finite-band upper limits in the earlier writeups were used
only to bound the cusp radius, not in the rectangle or lower-radius
sign inequalities. Checked the new coverage table:
R=20..192 uses earlier continuous certificates;
R=192..512 uses the new factored rectangle and separate
low/high/wide sectors whose u endpoints join;
R≥512 uses unified analytic signs; R<20 uses the true compact
and small-radius joins with n lower cutoff 5173.
No gap at a change between p=Rθ and u=R sin θ:
u≤.49 implies p<.5 for R≥192, and p≥u elsewhere.
At the lattice endpoints n=5173 and m=1293, the left anchor
hypothesis m≥800, the small-radius bound n≥2900, and the
radial condition nR≥75 are all satisfied.

For the left sign, independently reversed the coefficient expression:
a=24 m^5/(5^4*4v^4) makes
24/(-a)=-4*5^4 v^4/m^5. Factoring the exact top degree and
multiplying by the positive (5v/m)^r gives exactly (L1),
including all factorial powers. The leading term at v↓0 has
positive normalized sign. At the chosen v_L it is negative
by the exact left_first_cutoff_800.py certificate, so the extra
root is strictly beyond -a_L. Separately verified the phase
normalization a B(5(1+i)v_L p/m)=−m p⁴H(z),
with principal log p in its tiny disk about 1. Its absolute phase
is the actual saddle phase, not a second unaligned count.

## Sign and exact-arithmetic proof obligations

At an exact marker H=−kπ the upper half integral is normalized
by exp Ω(p); reflection makes the lower half its conjugate
before normalization. Therefore a strict positive real normalized
upper value produces sign (−1)^k in P_n(−a).
The complex angular integrand is entire, so the deformed halves
meet and preserve the original endpoints. The nonlocal pieces
are bounded in absolute value; their signs are never assumed.
The Gaussian sign argument requires positive real Hessian at
the noncusp saddle; the maximum/geometry supplies it and the
tilted Gaussian is identified on the principal square-root branch.
The cusp is treated separately. Airy sign references use the
ODE and its standard asymptotic initial phase; the quartic
correction has the sign of the reference from Ai' via integration
by parts, not an assumption of real-rootedness of any auxiliary
multivariate expression.

In the new rectangle independently expanded ∆z and exp(z+∆z)
after removing the linear term via stationarity. This gives the
factored K expression with the exact factor cos u/(R Re V),
and the R factors in all terms have the correct degree.
Directed numerical enclosures for the old and factored exponents
intersected at 100 exact test points after correcting the reciprocal,
a software cross-check only; the proof is the identity plus interval
coverage. The 32×32 rectangle is fully covered by dyadic endpoint
chains. Each normalized integral estimate is obtained by its
rigorous lower range over each exact-width t subinterval.
All omitted pieces are accounted for, including the vertical return.
For the geometric tail the monotone sign of U'_u applies beyond
the cutoff, and the exponential loss beyond the first expanded
arc is derived relative to u=π, which cannot exceed the saddle.
The trigonometric enclosures use scaling, series remainders and
Lipschitz widening; exponentials use scaling, series remainders
and squaring. Floats in diagnostic output cannot affect assertions.

The original-model integer replay, proof of Graeffe separation,
and test that collapsed pairs contradict final simplicity are
in finite_certificate_proof.md. The proof uses no inverse
stability implication beyond that explicit multiplicity argument.
The new GMP backend was checked around n=4064 and on the
known small rows. It does not rely on approximate root guesses.

The two auxiliary obstructions in homotopy_shortcut_obstructions.py
were reproduced by exact integer operations. Neither has any
logical role as a counterexample to the main problem.

Join check strengthened: a shared angular maximum at the same
a is not by itself enough to prove the two implicitly selected
parameters agree. At radius 10 the global outer branch is valid
for all a beyond its N=3000 point; the compact branch has N<n
at its own initial λ. Taking the larger starting a gives the
same N<n by angular uniqueness, so the required radial solution
is in the overlap. The same reasoning at R=1/4 uses μ=675 and
the compact initial λ. This explicit overlap argument was added
to saddle_all_n_ge_5173.md in the reverse audit.

After the proof was complete, the independent GMP backend was also
run successfully for 0..1024, 1025..2048, and 2049..3071 (8.021s,
45.936s, 1m44.414s), overlapping and confirming the previously
completed Python coverage. The full GMP replay is now available
along with complete logs. The original four-piece tilt was also
replayed with the factored exponent on both 20..128 and 128..192,
independently covering the older low-angle numerical ranges. These
are cross-checks, not a claim of external adjudication.
