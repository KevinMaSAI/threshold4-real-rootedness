# Strict negative roots for all n ≥ 4,400,000,000

Take the same proof and setup as full_tail_35b.md. The full
outer marker signs now hold for R≥2048:
- k=0 and 0<p≤1/8: previous analytic proofs unchanged.
- 1/8≤p≤1/2: phase_R2048_quartic.md for k=1..6 and
  phase_R2048_gaussian.md for all k≥7.
- 1/2≤p≤1.5: phase_R2048_gaussian.md.
- p≥1.5: old mid/high-angle theorems already apply here.

If 32≤R≤2048 and p≤2.5, the same radial formula as in
full_tail_35b.md gives
n<1.001(R+R²+R³/2)+12R²<4,400,000,000. Thus for
n≥4,400,000,000 every actual saddle on that radial strip has
p>2.5 and is handled by the old analytic high angle theorem;
in particular the real cusp occurs at ρ>2048. The compact
and small-radius proofs and the left anchor are unchanged.
The first successive exact marker sign brackets plus the
separately isolated far-left root exhaust degree floor(n/4).
All roots are simple negative in the entire stated infinite tail.
This is an effective sufficient bound, not an all-n answer.
