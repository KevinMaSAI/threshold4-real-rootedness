# Low phase angles at R≥1024, 1≤k≤8

This is the quartic extraction proof of phase_R2048_quartic.md,
with new constants for R≥1024, 1/8≤p≤1/2, H=−kπ and k≤8.
That proof's exact integration-by-parts correction has the
same sign as the cubic Airy amplitude without any change.

On the real interval through the two saddles the 15/R
derivative error estimate of low_angle_large_k.md remains valid,
indeed on its same entire original small hull. One may use
|z/R−1|<.82/R, |z−R−iw|<.34/R and the same T3,T4 bounds at
R=1024. Therefore c/M>cos(p)/2−7.5/R>.431.
Since M≥1.49R, v=cp³≤12π forces p<.39 (use
.431·1.49·1024·.39³>12π). This gives c/M>.451.
For the individual eight k, p is bounded by
.190,.240,.274,.302,.325,.346,.364,.380, as checked
by the exact inequalities in airy_quartic_R1024_check.py.

Take the same b=.55 and move the cutoff to x0=.80.
The central convex hull with ±p has |w|<.90,
−.209≤Im w≤.372. There |z/R−1|<.901/R,
|z−R−iw|<.406/R. The normalized deviations of T3,T4
from 1 are <5.8/R, <9.7/R, and of T5 <15/R,
by direct substitution in their explicit polynomials.
The exponential difference from exp(iw) is <.51/R
on this hull, since Im w≥−.209; its modulus is
at most exp(.209+.406/R). The S terms in normalized
orders 3,4,5 are <4.52/R,14/R²,42/R³.
In particular |Ω''''|,|Ω'''''|<1.26M, by
T4,T5 bounds and exp(.209+.406/1024).
The third/fourth model derivative error is <24/R,
giving a 12/R simplex error in L. Also
−1.006M<Ω''''(0)<0 by its exact real formula.

With Δ, E and v from the proof at R2048,
and u=x/p, Y=(u−1)²(u+1), Z=Y(u+1), the same Hermite
simplex bounds now give
|Δ−E|≤.04 v p²(1.15u+4.55)Z and |Δ|≤.198 v p Z.
Indeed 1.26(1+.55²)²/(120·.451)<.04 and with 24 in
place of 120 the constant is <.198.
The real damping can use .26 c(x−p)²(x+p), since
b(1−b²/3)−.198(x0+.38)>.26.
The exact one-dimensional directed check with these
constants bounds the central absolute remainder by
<3/4 of the lower signed cubic amplitude for all eight k.
There is no parameter sampling in that majorant.

At the vertical cutoff, the moment bounds as before
give Re L>.39, |Im L|<.146 (use x=.8, y≤.372,
p≤.38 and 12/1024). Hence the direction of the
vertical decay is correct: (1−b²)·.39−2b·.146>0.
The real-circle loss is >.0075M at x0:
(.30·1.4/(8·1.6))[(.99·.8)²−.38²]²>.0075.
Here −wχ'>.30u as before on u≤.8 at R≥1024
(the whole adverse correction is <.001u).
The actual vertical and first-arc tails are
<10 sqrt(M) exp(−.0075M)<.01 relative, and the
remote bound <.01 is unchanged since M≤2R here.

For the corrected Airy contour beyond x0,
x−p≥.525x, giving cubic loss >.134 c x³.
There |E|≤.16 c x⁴. As c>.451·1.49·1024,
using exp(t)≥t²/2 gives
c x⁴ exp(−.067c x³)≤2/(.067² c x²)<1.1.
Thus (1+E)f has at most 1.176 exp(−.067c x³)
in modulus there. Both tails together, divided
by the reference amplitude, contribute less than .01,
by integrating x³≥.8²x. Total error <.78,
while the exact correction has the sign of the cubic.
This proves the required signs on the stated region.
