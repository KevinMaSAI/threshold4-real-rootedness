# 文献和公开状态核查（2026-11-25，约 18:42–18:46 UTC）

- [MathOverflow 原题](https://mathoverflow.net/questions/462360/set-partitions-with-big-blocks-real-rooted-polynomials)：Per Alexandersson 定义了计数所有无序集合划分、只标记规模至少 j 的块的多项式，并把实根性与更强的交错性分开提问。本证明只解决 j=4 的实根性。
- [作者维护的专题目录](https://www.symmetricfunctions.com/realRootedOpenProblems.htm#set-partitions-and-trees)：给出相同的生成函数和 j=4 的 n=4,8 样例，标为第一个仍开放的阈值。只允许大块、只允许单元块和大块、以及改成有序划分的项目不是原题。
- [作者研究记录 #1773](https://github.com/PerAlexandersson/RealRooted/issues/1773)：检索到的 11 月 25 日评论报告了有限阶的 pencil/Wronskian 证书和若干失败的辅助条件。n=7000 的失败针对 Touchard 乘子路线的完整符号，不是 P_n 的反例；此前评论仍写明全阶命题开放。辅助分量的失效不能推出原题不成立。
- [Davis 的记录 #158](https://github.com/1337isnot1337/solved-conjectures/issues/158)：记录了 j=4,…,30、n≤180 的探索性筛查，以及继续研究的交接；未给出全阶证书。没有把无反例筛查或其他题的有序模型当作原题证明。
- **阈值 2。** [Alexandersson 与 Nabawanda, Peaks are preserved under run-sorting, arXiv:2104.04220](https://arxiv.org/abs/2104.04220)，见组合对应及实根/交错定理（包括 Thm. 16）。其生成函数给出精确识别 P_{n,2}=A_{n+1}=R_{n+1}/t，其中 A 计下降数、R 多乘一个 t。Lemma 14 的两项递推与 Rolle 定理和 Wagner 交错引理给出 Thm. 16；去掉共同零点 0 得阈值 2 的结论。这不是对阈值 4 的直接保根操作。
- **阈值 3。** [作者问题 #601 的 2026-10-11 状态更新](https://github.com/PerAlexandersson/RealRooted/issues/601)报告 A355144_splits 的全阶 Lean 定理。作者描述有限阶用精确 Kronecker-packed 证书，其余用已有效化的左右端、拼接、中段和尾部，以及递推轨道上的符号捕获。它不从更强的通用 Weyl 算子保根性推出。所链接 PR 此次获取返回 404，所以这里归属的是公开状态报告，不声称独立重跑或审计了阈值 3 的 Lean 源。
- 本证明所用标准解析参考：[NIST DLMF §9.5 Airy 积分表示](https://dlmf.nist.gov/9.5) 与 [§9.7 负轴渐近](https://dlmf.nist.gov/9.7)；参考函数的符号与下界由 ODE 的 Prüfer 估计推导。这些不是关于集合划分实根性的新结论。

在以上已检索范围内未找到阈值 4 的已有完整证明或原题反例。
这不是绝对首创保证。本次原题的计算辅助证明独立于这些目录的
“开放”标签，不以其为数学前提。
