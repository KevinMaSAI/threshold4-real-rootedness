# Small-radius analytic bridge through R=1/4

Under n≥2900 and nR≥75, for every 0<R≤1/4 the original
saddle and sign statement of left_anchor_800.md holds.
This extends its upper joining radius from 1/20 to 1/4.
No assumption is added to the left anchor itself.

Normalize a=24μ/R⁴, Bhat=24 B/R⁴ at the given radius.
For j=0,1,2,3,4, the complex D^j tail after the main term
(z/R)^4 is bounded on the circle by
∑_(l≥1) (l+4)^j (R/5)^l. At R=1/4 this gives the strict
bounds .05264,.267,1.35,6.84,34.82. For example the first
40 terms plus twice the 41st term give an upper bound,
since every succeeding term's ratio is <1/2. Here all
D^j S have modulus <1 for j≤4.

Use both resonant neighborhoods of half-width 1/8
centered at π/4 and 3π/4. There, for μ≥675,
the real exponent curvature is <−12.6 μ by
16 cos(.5)−1.35−1/675>12.6, and the first derivative
at either center has magnitude ≤.267 μ+1.
Strict concavity implies inward endpoint derivatives and
a unique local maximum in each neighborhood, within .022
of its center. Everywhere outside, loss relative to the first
center is >.014 μ by 1−cos(.5)−2(.05264+1/675)>.014.

Reflect the second maximum into the first neighborhood using
θ→π−θ. At the reflected point cos(5θ)<−.59, from
−sqrt(2)/2+5·.022<−.59. The S term increases by
2[R cos θ+(R³/6)cos(3θ)]>0. The odd Bhat difference
selects the first neighborhood with gap at least
μ [2(R/5)·.59−2(R/5)³/(1−R/5)]>.23 μR.
It follows that the first maximum is the unique maximum
on the upper half circle and that the entire second
neighborhood is below it by at least that gap.

At the first critical angle, 3.7<Re D(−Bhat)<4.27,
using the main term and the .022 angular error.
Implicit differentiation in μ gives |dθ/dμ|≤1/(12.6μ²),
as in the old bridge. With |∂_θ Re DF_a|≤18μ, the radial
quantity N_R(μ) is strictly increasing. It is unbounded
because N_R(μ)>3.7μ−1, and at μ=675 it is <2900.
Thus there is a unique saddle with the given n≥2900,
having μ≥675 and μR≥(nR−R)/4.27>17.5.
The true saddle again depends continuously on radius.

For the symmetric first-maximum comparison take h=.1
(which fits in 1/8−.022), τ=12.6 μ, |σ|≤18 μ,
and derivative bounds 72 μ and 292 μ in orders 3,4.
The (Q) error relative to the complex Gaussian is <1.1/μ.
The missing Gaussian and remaining first-neighborhood
integrals together give <4 exp(−.0315 μ), from strict
curvature. Second-neighborhood contribution is at most
sqrt(18/12.6) exp(−.23 μR), by its own curvature and
maximum. The rest has bound 2 sqrt(18 μ) exp(−.014 μ).
At μ≥675 and μR>17.5 their sum is <.05 (all these
ratios decrease in the corresponding argument there).
The real part of the complex Gaussian is ≥|G|/sqrt(2).
At each exact H=−kπ the sign follows. The original root
anchor uses R<1/20<1/4 and meets the same n and nR bounds,
so remains inside this enlarged bridge.
