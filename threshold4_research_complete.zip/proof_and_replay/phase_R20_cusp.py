"""Direct exact quadrature for the merged saddle at R in [20,32]."""
from phase_rect_certificate import outer, grid, Q, rat
from phase_wide_cell import add, quo, exp, mul, neg, sub, ONE, ZERO
from phase_low_tilted_cell import lower
from phase_k_certificate import PI, phase

def cusp(R):
    # u=0, w=2+1/R+3R/2, f=1+1/R, E=1, theta=p=0.
    inv=quo(ONE,R)
    w=add(add(rat(2),inv),mul(rat(3,2),R))
    mu=quo(w,add(ONE,inv))
    C=quo(ONE,sub(ONE,mul(mu,exp(neg(R)))))
    M=mul(mu,C)
    return R,(R,ZERO),ZERO,C,M,(M,ZERO)

def main():
    rows=grid(outer(20,32),192)
    marker_min=min(add(phase(R,rat(7,20))[0],PI)[0] for R in rows)
    assert marker_min>0
    print('VERIFIED H at u=.35 exceeds -pi throughout [20,32], margin',
          marker_min,'/',Q,flush=True)
    lo=min(lower(cusp(R),128) for R in rows)
    assert lo>0
    print('VERIFIED cusp normalized real sign on [20,32], margin',lo,'/',Q)
if __name__=='__main__':
    main()
