# All exact marker signs for R≥256, 1.5≤p≤2.5

Notation and geometry from the original large-radius proof.
This removes an unbounded-radius region using real Gaussian comparison
with the *actual* S contribution to curvature. It does not cover
1/8<p<1.5 or fill the full conjecture.

Along the expanded first arc write z=R exp(ix/R), θ=x/R,
u=Im z, X=Re z. Then
    −Re Ω''/M
       = χ(u_p) Re D²S(z)/R²
         − e^(X−R) Re[e^(iu)(z²+z)]/R² .
For R≥256, 0≤x≤x_end<3.25 one has
e^(X−R)>.98, X>.99R, 1.5R≤w≤1.51R at u_p,
and Re D²S(z)/R²≥1.49R. The first two bounds follow from
u≤π+.1 and R−X=u²/(R+X); the bound on w follows from its
explicit formula and w decreasing in u; the S bound uses
the positive cosine terms and cos(3θ)≥1−(3θ)²/2.
Since u_p≤p≤2.5 and sinc decreases there,
f(u_p)≥sinc(p)−.004, and the S contribution is at least
.96 sinc(p)−.004. This uses .98·1.49/1.51>.96.

The other term has amplitude in [.976,1.004]. Its angle
α=u+θ+arg(z+1) obeys u≤α≤u+2θ, and u≥x−.001 by
sin θ≥θ−θ³/6. For α≤π, its cosine is ≤cos x+.001
if x≤π; if x>π it is at most cos(x−.001)≤cos x+.001.
For α>π, α≤π+.126 so cos α≤−1+.126²/2≤cos x+.008.
Thus the exponential curvature term is ≤cos x+.033
everywhere on the expanded first arc, and ≤cos x+.03 on
x≤p+.25≤2.75, where α<π.
For x∈[p-.25,p+.25] this gives −Re Ω''>.28M;
for x∈[p-.4,x_end] it gives −Re Ω''>.14M.
Indeed .96 sinc(p)−cos(p−h) is increasing on the interval
for both h=.25 and h=.4: |sinc'(p)|≤1/2 from integrating
sin(pv)v, and sin(p−h)>.7. The minima at p=1.5 meet the
respective claimed bounds using sin 1.5>.997,
cos 1.25<.316 and cos 1.1<.454. In the full-arc
claim, cos x≤cos(p−.4): use cosine monotonicity to π
and then cos x≤cos(3.25)<cos(2.1) to the endpoint.
All displayed trig estimates follow from Taylor inequalities.

Also u_p≥.999p≥1.4985, giving f(u_p)≤1/u_p+1/X<.675
and M≥w/(e^(X−R)f)>560. The global real bounds
|Ω''|≤3M, |Ω'''|,|Ω''''|≤1.1M follow respectively from
the explicit T_2,T_3,T_4 and S derivatives, R≥256,
and (1+a)/M≤1/R.

Use the symmetric local Gaussian comparison (Q) from
big_blocks4_effective_bulk.md with h=.25 and τ=.28M.
Its normalized amplitude is at least 1/√2 of its modulus
for the real part. The relative local error is ≤45/M:
    √3[1.1/(8·.28^(5/2))+5·1.1²/(24·.28^(7/2))] <45.
Reference Gaussian omitted tails are ≤20 exp(−.00875M)/√M.
For the true arc on x≥p−.4 but outside the local interval,
integrating the real curvature gives real loss ≥.07M(x−p)²;
the direct Gaussian tail bound gives relative error ≤
40 exp(−.004375M)/√M. For x<p−.4, monotonicity before the
saddle and the curvature up to it already guarantee real
loss ≥.0112M, and length <2.5. Its relative contribution is
≤1.75 √M exp(−.0112M). The Gaussian comparisons used
√(3/(2π))<.7. The remote arc bound from
phase_high_angle_gaussian.md §3 is uniform over p, and is
less than .01 by R≥256. Evaluating the other terms at
M=560 by monotonicity gives respectively <.081, .007,
.16, .085; hence the cumulative error is <.35<1/√2.
The normalized positive-half real integral is therefore
strictly positive and for H=−kπ the sign is (−1)^k.
