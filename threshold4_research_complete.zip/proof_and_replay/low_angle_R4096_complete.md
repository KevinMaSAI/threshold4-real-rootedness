# Complete low-angle marker signs at R≥4096

For R≥4096, 1/8≤p≤1/2, the exact signs at H=−kπ are
established for every k≥1. Use the proof and setup of
low_angle_large_k.md, including the sharpened 15/R bounds and
mean-zero Hessian comparison, with the following improvements.
This closes the small-angle obstacle at this smaller R, but
larger angles at intermediate R still have a separate gap.

## Improved tilted exterior, all p≤1/2

For the full tilted line of the previous proof, the simplex
formula gives more than a pointwise minimum of Re L.
Writing y=Im w, θ=s x+(t−v)p, the elementary moment
identities on the simplex s+t+v=1 are
∫s=1/6, ∫s²=∫(t−v)²=1/12, ∫s(t−v)=0.
Hence for y≥0,
\[
 \Re L\ge 1/2-y/6-(x^2+p^2)/24-7.5/R,
\]
because \(e^{-sy}\cos\theta\ge 1-sy-\theta^2/2\)
here (the two elementary lower factors are positive).
For y≤0 omit y/6 altogether, because cos θ>0 there.
On the right x≤.72 and y≤.36 this gives Re L>.405.
With |Im L|<.122, the right attenuation coefficient
in the preceding proof improves to
.5[.405(11/12)−.122/2]>.15.
On the left x≤p≤.5, Re L>.475 and |Im L|<.109,
and specifically x/(x+p)≤1/2 in the cross term.
So the left coefficient is
.5(.475−.109/4)>.22.
Thus outside the local interval, the tilted real loss
is at least .22 M p (x−p)² everywhere. It gives a
relative tail ≤6.2 exp(−.02695v)/sqrt(v), where v=Mp³.
Other tails and local bounds are unchanged.
For k≥7, v≥(3π/2) k/.502>65.7 and the relative error
sums to less than .65 using this improved exterior.
This replaces the earlier k≥8.

## k=5 or 6

From the real-Hessian factor relation, c/M≥.5 cos(.5)−7.5/R>.436.
Since M≥1.49R>6100, cp³=(3π/2)k and k≤6 give p<.225.
In the tilted local interval, x∈[.65p,1.35p], |y|≤.175p.
Use sin x≥.984x, e^(−y)≥.960625, e^(−y)≤1+.179p.
The first bracket as in the previous proof is ≥−.1735p:
the positive quadratic-minus-quartic difference is at least
.0442p²≥.005525p. Therefore the actual real tilted curvature
is more than .47Mp, since
.960625·.984·.65−.75·.1735−45/4096>.47.
The derivative modulus and Hessian upper bounds remain
1.72 M and 1.4 M p as before.

On the left tilted line with p<.225, the improved moment bound
gives Re L>.493, and |Im L|<.044 from e^(.1125)·.225/6+7.5/R.
The left attenuation coefficient is now
.5(.493−.044/4)≥.24. For the right the earlier .15 remains.
Consequently the exterior-Gaussian relative bound is
5.6 exp(−.0294v)/sqrt(v).
With τ=.47Mp the symmetric local Q error is bounded by
(1.8p+10.4)/v, from the explicit Q constants.
The direct missing Gaussian tail has relative bound
6 exp(−.0287875v)/sqrt(v), by integrating
2 e^(−τh²/2)/(τh) at h=.35p.
The two far tails still sum to less than .02.
Using v≥(3π/2)k/.502>46.93 and p≤.225,
the total is below .69<1/√2.
This proves the signs for k=5 and 6.

## k=1 through 4

First c/M>.436 gives p<.193 when k≤4. Hence by the sharper
cosine lower bound in the simplex,
c/M≥.5 cos(.193)−7.5/R>.488.
The inequalities c>.488·6100, π<22/7 give separate bounds
p<.117,.148,.169,.186 for k=1,2,3,4 respectively.

Use the cubic comparison from airymarker_small_p.md at b=.55,
now with x0=.55 and p≤.186. The complex hull stays in the
domain of the 15/R derivative bounds, so sup |Ω''''| ≤1.12M
(on it Im w≥−.55·.186). For the vertical return attested
by the previous argument, Re L>.25 and |Im L|<.1 suffice
and hold by the improved moment bounds (or the old lower
bound .5 exp(−.55·.55) cos(.55)−7.5/R). The cubic damping
coefficient of the convex combination is at least d=.375,
since b(1−b²/3)−1.12(1+b²)²·.736/(24·.488)>.375.
The prefactor in both-half error is <.372c, by
2√(1+b²)(1+b²)²·1.12/(24·.488)<.372.
Thus, with the same Airy amplitude lower bound \((2π/3)/\sqrt{cp}\),
the previous three moments give relative contribution at most
\[
 2.75p+5.1/\sqrt{cp}+.83\sqrt p\,c^{-1/6}.
\]
Use cp³=(3π/2)k: with the respective p bounds the expression
is <.84 for all four k. For the reference tail beyond x=.55,
use x−p>.66x, giving damping >.21 c x³, with c>.488·6100;
the omitted contribution is <.01. The true arc beyond
x=.55 and its vertical have loss >.0022M by the sharpened
sinc bound as before: u(.55)>.99·.55 and u_p≤.186 in the
integrated bound (0.30·1.4/(8·1.6))M(u²−u_p²)².
Its relative contribution is <5√M exp(−.0022M)<.01;
the remote arc contributes <.01. The total relative error
is <.87 of the signed Airy amplitude, so the required sign
also holds in these first four cases.

All k are now covered at R≥4096 for p∈[1/8,1/2]; with
airymarker_small_p.md, this includes all positive-index
markers with 0<p≤1/2 at those R.
