# Validating continuous saddle rectangles (work in progress)

This gives the normalized sign at exact phase markers when they lie
inside any certified (R,u) rectangle. It is not a scan of integer n,
but it does not, yet, cover the entire saddle curve for any new n
range. See big_blocks4_explicit_tail_18.md §§1,5,6 for the sphere
geometry, normalized exponent identity, and fourth-order real tail.

Given R and u=Im z_p, use X=√(R²−u²), θ=arcsin(u/R), p=Rθ, and
M/(1+a)=w(u)/(e^(X−R)f(u)) as in §§1,5 of the above file. Thus
the exact arithmetic computes the true same-angle stationary
configuration whenever the denominators are strictly positive.
The old verifier isolates u by specifying k; the new
phase_rect_certificate.py supplies u directly as an interval.
In both, the exactly stationary linear term is canceled algebraically,
and all remainder series and integrals are enclosed by dyadic arithmetic.

phase_wide_cell.py extends this to larger u by a different contour.
The right half in the angular plane starts at −ip/5,
uses x+i(x−p)/5 for 0≤x≤p, then follows the real line to x=81/25.
The other half is its reflection in the imaginary axis with reversed
orientation. The complete contour connects the original endpoints
and integrates the same entire integrand. Since the exterior real
segments are unchanged, this does not require a descent estimate on
the tilted segment. For real n, f at the reflected point is the
complex conjugate of f at the first, even if the two pieces do
not actually start at 0. Thus at H=−kπ the sign is (−1)^k times
the sign of the real half integral after normalization by exp Ω(p).
Both contour halves have the same real integral. On the right half,
the integration coordinates y=x−p=t p−p and y=t(81/25−p),
respectively (0≤t≤1), leave the exact factor of p or (81/25−p)
in the line measure and avoid a large dependency on x and p
separately. The factor Re[(1+i y') exp(phase)] is calculated with the
derivative relative to x.

For the remaining real arc, its angular imaginary coordinate at the
cutoff is at least .99(81/25) and at most 81/25 < π+1/10, uniformly
for R≥32 by sin x≥x−x³/6. Up until u=π+.1, estimate (2) of the tail
proof bounds the loss below by M[.99²(81/25)²−u_p²]²/200.
Past the expanded angular interval the stated comparison with u=π,
alongside (2) at π, adds R/10 + M/(5R), so the lower loss is
M[π²−u_p²]²/200+R/10+M/(5R). This requires u_p<π, verified by the
program with the lower π enclosure. The smaller loss times sign −,
exponentiated, bounds the whole real tail, of length <4R. Use
e^(−loss)≤(3/8)^floor(loss) with e>8/3, and outward rounding.
All losses positive on the certified rectangles. Narrower parameter
boxes do not change the underlying exact path or point; the directed
bounds are only for certifying the integrals.

For each radius-angle cell the integrand lower bound on each exact
subinterval, times the enclosing subinterval length, yields a
validated lower bound. To cover closed rectangles, each pair of child
intervals has the parent's endpoints and a shared interior endpoint.
The code accepts a cell only when the lower bound on the real part
after subtracting the full exterior tail is strictly positive.
Inconclusive means refine bounds; it does NOT imply a negative sign.
This code currently assumes R≥32; small R use the separate compact
saddle estimates, not a direct substitution into these claims.

## Sharper tail starting at u_p≥2.8

For 2.8≤u≤π+0.1, one has |u−π|<0.35, cos u<−0.93,
sin u≥−0.11, |sin u|≤0.35, X≥.99R. Consequently
−f'(u)≥.93/3.25−.11/2.8²−.11/(.99·32)>.268.
Here the derivative contribution from the derivative of X in
cos(u)/X, after reversing the sign, is nonnegative.
Also |f|≤.35/2.8+1/(.99·32)<.157,
|X'f|≤(3.25/(.99·32))·.157<.017,
and |fw'/w|≤.157·6·3.25/(1.4·32²)<.003.
Thus −wχ'≥.8(.268−.017−.003)>.19. Since
w(u)/w(v)≥1.4/1.6 and u≥2.8, integrate the formula for U'
twice to get
    U(u_p)−U(u) ≥ (M/5) (u−u_p)²
for u_p≤u in this range. For the right-hand real tail from
x=81/25 up to u=π+.1, du/dx≥.99 implies real loss
≥d(x−p)² for d=.19M. Its integral is at most
e^(−d(x_0−p)²)/(2d(x_0−p)), by bounding 1 by (x−p)/(x_0−p)
and integrating to infinity. Combine separately with loss
at u=π plus R/10+M/(5R) for the genuinely remote arc.
The implementation uses the larger of the old and new lower
bounds for the far-arc loss; all operations are outward.

## Smaller-angle tilted contour

phase_low_tilted_cell.py tilts both sides of the local saddle on
the positive half using slope b=9/20. From the saddle it goes to
p+3/5+i(9/20)(3/5), then straight down to p+3/5, and then to
81/25 on the real circle. Before the saddle it starts at −ibp,
as the other half is the reflected path. The vertical path is
parametrized by t in [0,1] with dz/dt=−i(3/5)(9/20), so it has
normalized real integrand +(3/5)(9/20) exp(Re phase) sin(Im phase).
This sign is important. The sum of these four integrals equals the
real half integral after reflection, by the same entire contour
deformation as above. Every piece is integrated by outward-rounded
rectangles after exact saddle linear cancellation.

The exact cutoff phase_small_threshold.py certifies
H_R(u=.35)+π>0 throughout 32≤R≤128, by 768 closed interval boxes.
By the previously proven strict decrease in u and H_R(0)=0, no
positive-index marker occurs at 0<u≤.35 in this radius range.
The k=0 sign is the analytic merged-saddle result.

Scope clarification: the half-integral that is positive on these
rectangles is the normalized integral on the stated (possibly
deformed) half-contour including the real tail. Only at an exact
phase marker does this imply the original full real-integral sign.
At other phases the factor exp(Ω(p)) is complex; the stated signs
must not be applied to the real part of the original partial
integral or polynomial there.
