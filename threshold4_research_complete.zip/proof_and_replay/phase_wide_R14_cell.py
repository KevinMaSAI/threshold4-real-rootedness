"""Validated normalized half-integral on wider angular rectangles.

See accompanying derivation. Uses exact dyadic enclosing arithmetic and
a contour adapted to each saddle. No floating-point sign test.
"""
from fractions import Fraction as F
from math import comb
from phase_k_certificate import (
    Q, ONE, ZERO, PI, rat, root, quo, asn, E2, cadd, csub, cscale,
    cmul, cdiv, pow_three_eighths, div, add, mul, sq, neg, sub, scale, exp, trig,
)

def asn_wide(x):
    assert 0<=x[0]<=x[1] and 4*x[1]<=Q
    x2=sq(x); p=x; S=ZERO
    for j in range(16):
        S=add(S,mul(p,rat(comb(2*j,j),4**j*(2*j+1))))
        p=mul(p,x2)
    assert F(1,4)**33/(1-F(1,16)) < F(1,Q)
    return (S[0],S[1]+1)

def geometry(R,u):
    R2=sq(R)
    X=root(sub(R2,sq(u)))
    gap=neg(quo(sq(u),add(R,X)))
    co,si=trig(u)
    theta=asn_wide(quo(u,R))
    w=add(rat(2),quo(add(ONE,sub(div(scale(R2,3),2),scale(sq(u),2))),X))
    f=add(quo(si,u),quo(co,X))
    mod=exp(gap)
    mu=quo(w,mul(mod,f))
    C=quo(ONE,sub(ONE,mul(mu,exp(neg(R)))))
    M=mul(mu,C)
    ae=mul(M,mod)
    return (R,(X,u),mul(R,theta),C,M,(mul(ae,co),mul(ae,si)))

def exponent_diff(C, x, y):
    R,z,p,a1,M,aE=C
    q=quo(neg(y),R),quo(x,R)
    q2,q3=cscale(q,rat(2)),cscale(q,rat(3))
    def e2(w):
        return E2(w,sum(max(abs(k) for k in x) for x in w)<=Q//4)
    E=e2(q)
    dz=cmul(z,cadd(q,E))
    z2=cmul(z,z);z3=cmul(z,z2)
    phase=cscale(cadd(cmul(z,E),cadd(cmul(cdiv(z2,2),e2(q2)),
                                   cmul(cdiv(z3,6),e2(q3)))),a1)
    phase=csub(phase,cmul(aE,cadd(e2(dz),cmul(z,E))))
    return phase

def integrand(C, y, slope):
    value=exponent_diff(C,y,mul(y,slope))
    co,si=trig(value[1])
    return mul(exp(value[0]),sub(co,mul(slope,si)))

def lower(C, nboxes=96):
    R,z,p,a1,M,aE=C
    tail_x=F(81,25)
    xmax=rat(tail_x.numerator,tail_x.denominator)
    dist=sub(xmax,p)
    assert dist[0]>0
    total=ZERO
    for j in range(nboxes):
        lo=rat(j,nboxes)[0]
        hi=rat(j+1,nboxes)[1]
        t=(lo,hi)
        left=mul(sub(t,ONE),p)
        right=mul(t,dist)
        value=add(mul(p,integrand(C,left,rat(1,5))),
                  mul(dist,integrand(C,right,ZERO)))
        total=add(total,mul(rat(1,nboxes),value))
    return total[0]-tail_bound(C,tail_x)[1]

def tail_bound(C,tail_x):
    R,z,p,a1,M,aE=C
    dist=sub(rat(tail_x.numerator,tail_x.denominator),p)
    p_u=F(z[1][1],Q)
    assert p_u < F(PI[0],Q)
    ucut=F(99,100)*tail_x
    assert ucut > p_u
    loM=F(M[0],Q)
    pi=F(PI[0],Q)
    l1=loM*(ucut**2-p_u**2)**2/200
    l2=loM*(pi**2-p_u**2)**2/200+F(R[0],10*Q)+loM*Q/(5*R[1])
    if F(z[1][0],Q)>=F(14,5):
        # Near segment uses the angular Gaussian loss, with an integral
        # bound rather than charging the whole circumference at cutoff.
        sep=F(dist[0],Q)
        d=F(16,100)*loM
        fac=1/(2*d*sep)
        near=mul(rat(fac.numerator,fac.denominator),
                 pow_three_eighths(int(d*sep*sep)))
        l2=max(l2,F(16,100)*loM*(pi-p_u)**2+F(R[0],10*Q)+loM*Q/(5*R[1]))
        far=mul(scale(R,4),pow_three_eighths(int(l2)))
        v=add(near,far)
    else:
        v=mul(scale(R,4),pow_three_eighths(int(min(l1,l2))))
    return v

if __name__=='__main__':
    from phase_rect_certificate import outer
    for l in range(13,31):
        A=outer('32','321/10')
        U=outer(F(l,10),F(l,10)+F(1,1000))
        try:
            print(l,lower(geometry(A,U))/Q,flush=True)
        except AssertionError:
            print(l,'inconclusive bounds assertion',flush=True)
