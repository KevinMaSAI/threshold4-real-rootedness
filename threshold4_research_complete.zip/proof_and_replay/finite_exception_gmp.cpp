// Exact, directed finite-exception verifier. No floating point.
#include <gmpxx.h>
#include <cassert>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using Z=mpz_class;
static_assert(sizeof(unsigned long)>=8,"Use a 64-bit Unix/WSL compiler with GMP.");
struct Pair { Z l,h; };
struct Top { Z l,h; long e; };
static Top top(const Z& x, unsigned B) {
  assert(x>0);
  long e=std::max(0L,long(mpz_sizeinbase(x.get_mpz_t(),2))-long(B));
  Z l; mpz_fdiv_q_2exp(l.get_mpz_t(),x.get_mpz_t(),e);
  return {l,l+(e!=0),e};
}
static void init(std::vector<Pair>& q,const std::vector<Z>& a,unsigned B) {
  std::vector<Top> t; t.reserve(a.size());
  for(auto &z:a)t.push_back(top(z,B+12));
  for(unsigned k=1;k+1<a.size();++k) {
    auto &l=t[k-1];auto &m=t[k];auto &r=t[k+1];
    Z a0=l.l*r.l,a1=l.h*r.h,d0=m.l*m.l,d1=m.h*m.h;
    long e=l.e+r.e-2*m.e+B;
    if(e>=0){a0<<=e;a1<<=e;}else{d0<<=-e;d1<<=-e;}
    mpz_fdiv_q(q[k].l.get_mpz_t(),a0.get_mpz_t(),d1.get_mpz_t());
    mpz_cdiv_q(q[k].h.get_mpz_t(),a1.get_mpz_t(),d0.get_mpz_t());
  }
}
struct Scratch {
  Z t0,t1;
  void mul(Pair& out,const Pair& a,const Pair& b,unsigned B) {
    mpz_mul(t0.get_mpz_t(),a.l.get_mpz_t(),b.l.get_mpz_t());
    mpz_mul(t1.get_mpz_t(),a.h.get_mpz_t(),b.h.get_mpz_t());
    mpz_fdiv_q_2exp(out.l.get_mpz_t(),t0.get_mpz_t(),B);
    mpz_cdiv_q_2exp(out.h.get_mpz_t(),t1.get_mpz_t(),B);
  }
};
static int separated(const std::vector<Z>& a,unsigned B) {
  const unsigned d=a.size()-1;
  if(d<=1)return 0;
  const Z Q=Z(1)<<B;
  const Z Q4=Q>>2;
  const Pair one{Q,Q};
  Scratch sc;
  std::vector<Pair> q(d+1),eta(d+1);
  eta.front()=eta.back()=one;
  init(q,a,B);
  Pair H,V,T,W;
  for(int j=0;j<=25;++j) {
    Z mx=0;
    for(unsigned k=1;k<d;++k) if(q[k].h>mx) mx=q[k].h;
    if(mx<Q4)return j;
    if(mx>=Q || j==25)return -1;
    for(unsigned k=1;k<d;++k) {
      auto& e=eta[k];e=one;V=one;H=one;
      const unsigned limit=std::min(k,d-k);
      for(unsigned s=1;s<=limit;++s) {
        if(s==1)H=q[k];
        else {sc.mul(T,H,q[k-s+1],B);sc.mul(H,T,q[k+s-1],B);}
        sc.mul(V,V,H,B);
        if(s&1U) {
          mpz_submul_ui(e.l.get_mpz_t(),V.h.get_mpz_t(),2);
          mpz_submul_ui(e.h.get_mpz_t(),V.l.get_mpz_t(),2);
        } else {
          mpz_addmul_ui(e.l.get_mpz_t(),V.l.get_mpz_t(),2);
          mpz_addmul_ui(e.h.get_mpz_t(),V.h.get_mpz_t(),2);
        }
        if(V.h<=1 && s<limit) {
          // q_k<=1, so later alternating summands decrease.
          if(s&1U)mpz_addmul_ui(e.h.get_mpz_t(),V.h.get_mpz_t(),2);
          else mpz_submul_ui(e.l.get_mpz_t(),V.h.get_mpz_t(),2);
          break;
        }
      }
      if(e.l<=0)return -1;
    }
    for(unsigned k=1;k<d;++k) {
      sc.mul(T,q[k],q[k],B);
      sc.mul(W,eta[k-1],eta[k+1],B);
      sc.mul(V,T,W,B);
      V.l<<=2*B; V.h<<=2*B;
      H.l=eta[k].l*eta[k].l;
      H.h=eta[k].h*eta[k].h;
      mpz_fdiv_q(q[k].l.get_mpz_t(),V.l.get_mpz_t(),H.h.get_mpz_t());
      mpz_cdiv_q(q[k].h.get_mpz_t(),V.h.get_mpz_t(),H.l.get_mpz_t());
    }
  }
  return -1;
}
static void addmul(Z& dst,const Z& src,unsigned long w) {
  mpz_addmul_ui(dst.get_mpz_t(),src.get_mpz_t(),w);
}
int main(int argc,char**argv) {
  if(argc<3 || argc>4) return 4;
  const long first=std::atol(argv[1]),end=std::atol(argv[2]);
  const unsigned minB=argc==4?std::atoi(argv[3]):1024;
  if(first<0 || end<first || end>20000 || minB<8 || minB>8192)return 4;
  std::vector<Z> rows[4]; rows[0]={Z(1)};
  unsigned maxB=0,mJ=0;
  for(long n=0;n<=end;++n) {
    if(n>=first) {
      int j=-1;unsigned B=minB;
      for(;B<=8192;B*=2) {
        j=separated(rows[n%4],B);
        if(j>=0)break;
      }
      if(j<0) { std::cerr<<"INCONCLUSIVE at "<<n<<'\n';return 2; }
      maxB=std::max(maxB,B); mJ=std::max(mJ,unsigned(j));
      if(n==first || n%32==0)
        std::cout<<"verified through "<<n<<" max steps "<<mJ<<" bits "<<maxB<<std::endl;
    }
    if(n==end)break;
    const unsigned long nn=n;
    const unsigned long weights[4]={0,nn,nn*(nn-1)/2,nn*(nn-1)*(nn-2)/6};
    std::vector<Z> output((n+1)/4+1);
    for(unsigned k=0;k<rows[n%4].size();++k)addmul(output[k],rows[n%4][k],k+1);
    for(int r=1;r<=3&&r<=n;++r) {
      const auto &past=rows[(n-r)%4];
      for(unsigned k=0;k<past.size();++k)addmul(output[k+(r==3)],past[k],weights[r]);
    }
    rows[(n+1)%4]=std::move(output);
  }
  std::cout<<"CERTIFIED exact original n in "<<first<<' '<<end<<
    " max steps "<<mJ<<" bits "<<maxB<<std::endl;
  return 0;
}
