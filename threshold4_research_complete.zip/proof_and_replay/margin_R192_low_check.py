"""Directed margin checks for the continuum estimates at R>=192."""
from fractions import Fraction as F
from angular_certificate import Q, ONE, add, sub, mul, sq, exp, trig, point, neg, scale
from phase_k_certificate import PI, rat, quo, root
def b(s):
    x=F(str(s)); return rat(x.numerator,x.denominator)
def m(*args):
    out=ONE
    for a in args:out=mul(out,a)
    return out
def upper(x,s):
    assert x[1]<b(s)[0],(x[1]/Q,s)
def lower(x,s):
    assert x[0]>b(s)[1],(x[0]/Q,s)
def inv(x):return quo(ONE,x)
def damp(x):return exp(neg(x))
def power(x,k):return m(*[x]*k)
R=b(192); M=m(b('1.49'),R); sqrtM=root(M)
def qerror(t,S,U,p,v):
    return m(inv(v),root(quo(S,t)),add(quo(m(U,p),m(b(8),sq(t))),
                                 quo(m(b(5),sq(U)),m(b(24),power(t,3)))))
def tailG(a,S,v,h):
    return m(quo(m(b(2),root(quo(S,scale(PI,2)))),m(a,h,root(v))),
             damp(m(b('.5'),a,sq(h),v)))
def tailE(a,S,v,h):
    return m(quo(root(quo(S,scale(PI,2))),m(a,h,root(v))),
             damp(m(a,sq(h),v)))
assert F('.5')-F('.5')**2/20-F('7.5')/192>F('.448')
assert F('.5')+F('7.5')/192<F('.54')
upper(add(m(add(ONE,quo(b('16.6'),R)),exp(add(b('.275'),quo(b('.69'),R)))),quo(b(42),power(R,3))),'1.45')
assert F('1.45')*F('1.3025')**2/(24*F('.448'))<F('.229')
assert F('1.45')*F('1.3025')**2/(120*F('.448'))<F('.046')
assert F('.29')*F('1.4')/(8*F('1.6'))*((F('.99')*F('1.05'))**2-F('.5')**2)**2>F('.021')
upper(m(b(2),add(inv(b('.11')),inv(b('.10'))),inv(sqrtM),damp(m(b('.021'),M))),'.006')
c=m(b('.448'),M); x=b('1.05')
upper(quo(b(2),m(sq(b('.066')),c,sq(x))),'3.3')
upper(m(b('2.3'),b('1.561'),sqrtM,quo(damp(m(b('.066'),c,power(x,3))),m(b('.066'),c,sq(x)))),'.002')
assert F('.9375')*F('.935')*F('.75')-F('.75')*F('.116')-F('1.25')*15*F('2.26')/192>F('.345')
upper(exp(b('.0625')),'1.065')
lower(quo(trig(b('.625'))[1],b('.625')),'.935')
upper(m(b('1.25'),add(b(F(13,12)),quo(b(30),R))),'1.55')
upper(m(b('1.5625'),add(exp(b('.0625')),quo(b(15),R))),'1.79')
t,S,U,h,alpha,v=b('.345'),b('1.55'),b('1.79'),b('.25'),b('.165'),b('174.5')
assert quo(m(PI,b(30)),b('.54'))[0]>v[1]
components=add(qerror(t,S,U,b('.5'),v),add(tailG(t,S,v,h),tailE(alpha,S,v,h)))
upper(components,'.58')
print('VERIFIED outward-rational margins for complete low-angle signs at R192')
