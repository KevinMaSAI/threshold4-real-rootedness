"""Exact rational rechecks for latest angular and n endpoint constants."""
from fractions import Fraction as F
from math import factorial
def e_lower(x,n=30):
    assert x>=0
    return sum(x**j/factorial(j) for j in range(n))
def sinc_lower(x):
    return 1-x*x/6+x**4/120-x**6/5040
def main():
    R=24576; q=F(675,1000)
    assert sinc_lower(q)>F(925,1000)
    assert F(9125,10000)*F(925,1000)*F(65,100)-F(3,4)*F(1787,10000)-F(375,10)/R*8>F(2,5)
    v=F(7152,100); M=36618
    assert F(41,2)/v<F(287,1000)
    assert F(68,10)**2 < F(14,100)**2*v*e_lower(F(245,10000)*v)**2
    assert 64 < F(215,1000)**2*v*e_lower(F(20825,1000000)*v)**2
    assert 25*M < F(2,100)**2*e_lower(F(3,10000)*M)**2
    assert F(1001,1000)*(R+R**2+R**3//2)+12*R**2<7500000000000
    assert 160**4//322==2035279
    print('latest angular margins and n endpoint pass exact rational checks')

if __name__=='__main__': main()
