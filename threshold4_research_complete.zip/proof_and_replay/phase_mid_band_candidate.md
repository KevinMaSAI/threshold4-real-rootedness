# Candidate band from angle-by-angle closure (do not claim until low logs pass)

If the low tilted angle rectangles pass for
[32,48], [48,64], [64,96], and [96,128] with 0.35≤u≤1.3,
the following strict original interval follows:

    56230 ≤ n ≤ 1040447.

1. The separated proof of N(R) in big_blocks4_effective_bulk.md §7
   gives N(32)<16384 and
   N(128)=128^4/[2(129−E(128))]>128^4/258>1040447.
   Its strict monotonicity makes the cusp radius ρ satisfy 32<ρ<128
   for the entire n interval. Along the large-radius stationary
   family (same §7), the continuation from the cusp spans just
   32≤R≤ρ before entering the compact-radius band.
2. The cusp k=0 sign is proved in big_blocks4_explicit_tail_18.md §4.
   For k≥1, phase_small_threshold.py plus strict phase monotonicity
   at fixed R exclude u≤.35. Lower-angle rectangles mentioned above
   would cover .35≤u≤1.3. Wide-angle rectangles already cover
   1.3≤u≤2.9, for all 32≤R≤128. For u>2.9, p≥u>2.9, so
   the analytic high-angle Gaussian estimate applies. That theorem
   actually starts at p=2.5, creating an overlap. Thus all individual
   exact phase marker signs on the large-radius part would hold.
3. The previously replayed compact-radius signs apply to n≥56230.
   The small-radius bridge's endpoint satisfies nR≥263, since
   n≥56230 and the effective left anchor in §4 has m≥8192.
   The four largest-modulus different negative roots and the strict
   endpoint H(a_L)<−(m−4)π are likewise from §4 of the effective proof.
4. Continuous phase from zero at the cusp to below −(m−4)π at
   the left anchor, and the now-established alternating signs at
   first hits of −jπ, would give m−4 distinct negative roots between
   the cusp and anchor. Along with the four beyond the anchor,
   that would exhaust degree m=floor(n/4). The original polynomial,
   not the homotopy, is being counted.

The exhaustion proof is not dependent on monotonicity of the
entire continuous phase in a; first hits suffice. The only required
outstanding certificate for this specific numerical band is the
listed low-angled rectangles (or an alternative covering those
marker points). Even this band would leave n=1025..56229 and
n>1040447 below 10^18 unproved. Do not present a conditional band
as verified until all four low tilted logs and their rational
bounds have been checked.
