"""Exact ranged Graeffe certificate for the small unresolved finite exceptions."""
from argparse import ArgumentParser
from graeffe_fast_adaptive import signs_certificate,stream
def main():
    p=ArgumentParser()
    p.add_argument('start',type=int);p.add_argument('end',type=int)
    a=p.parse_args()
    assert 0<=a.start<=a.end
    worst=[0,0]
    for n,row in stream(a.end):
        if n<a.start:continue
        kind,steps,bits=signs_certificate(row,min_bits=512)
        if kind!='simple_real':
            raise ArithmeticError(f'uncertified n={n}, {kind}, steps={steps}, bits={bits}')
        worst=[max(worst[0],steps),max(worst[1],bits)]
        if n%128==0:
            print('verified through',n,'max steps/bits',worst,flush=True)
    print('CERTIFIED original distinct negative roots on n in',a.start,a.end,'max steps/bits',worst,flush=True)
if __name__=='__main__':main()
