"""No positive-index phase marker with u<=.35 and 32<=R<=128."""
from phase_rect_certificate import outer, grid, Q
from phase_k_certificate import PI, add, phase, rat

def main():
    U=rat(7,20)
    A=outer(32,128)
    bounds=[add(phase(R,U)[0],PI)[0] for R in grid(A,768)]
    assert min(bounds)>0
    print('VERIFIED H_R(u=.35)+pi>0 for 32<=R<=128; exact minimum',
          min(bounds),'/',Q)
    print('Guaranteed upper integer n by N(128) >= 128^4/(2*129):',
          128**4//258)

if __name__=='__main__':
    main()
