# Strict negative roots for every 16376 ≤ n ≤ 3520607

Keep the continuous saddle geometry, compact-radius signs,
low-radius bridge, and left anchor in phase_mid_band_160_joint.md.
For the enlarged interval the critical radius satisfies 20<ρ<192:
N(20)<4000 and N(192)>192⁴/[2(192+1)]>3520607.
All signs for 20≤R≤160 are the same as in the previous proof.
On 160≤R≤192 the exact monotone phase formula and the directed
certificate phase_small_thresholds.py exclude every positive-index
marker with u≤31/100. Specifically H_R(31/100)+π is bounded
below by 73700606642590975/2⁵⁸ for all R∈[32,192].
The exact interval integrals now additionally certify the signs on
this entire radial rectangle:
- 31/100≤u≤13/10: phase_tilt_160_192_results.txt
  (6150 cells, strict lower bound 40973071835222/2⁵⁸).
- 13/10≤u≤5/2: phase_wide_160_192_results.txt
  (1920 cells, strict lower bound 10811006160513124/2⁵⁸).
- u>5/2: the analytic high-angle theorem, since p≥u.
At k=0 the R≥32 cusp estimate is unchanged.
For either completed certificate, the positive real part is that
of the integral normalized by the saddle value. It implies the sign
(−1)^k only at H=−kπ, which is exactly what the root count needs.
The same phase-lift sign brackets and disjoint anchor exhaust the
degree m for every integer n in the enlarged interval.
