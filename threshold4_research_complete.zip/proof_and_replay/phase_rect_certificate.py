"""Exact 2-parameter half-integral sign certificate.

The angle parameter is u=Im z at the stationary point, not the
index k. On any rectangle certified here the normalized half-integral
is positive for all continuous parameters. At any exact H=-k*pi
marker this implies the required sign (-1)^k. It neither asserts
the polynomial sign at arbitrary H nor covers unproved rectangles.
"""
from argparse import ArgumentParser
from fractions import Fraction as F
from phase_k_certificate import (Q, ZERO, add, mul, rat, scale, phase,
                                  ordinates, FRACTION_GAP, pow_three_eighths)

def integrate(A, U, nboxes):
    C = phase(A,U)[1]
    total = ZERO
    for segment,(start,end) in enumerate([(0,130),(130,140),(140,300)]):
        h = rat(end-start,100*nboxes)
        for j in range(nboxes):
            a = rat(start*nboxes+(end-start)*j,100*nboxes)[0]
            b = rat(start*nboxes+(end-start)*(j+1),100*nboxes)[1]
            total = add(total,mul(h,ordinates(C,(a,b),segment)))
    R,z,p,a1,M,aE = C
    assert rat(297,100)[0]>z[1][1]
    tail = mul(scale(R,4),pow_three_eighths(int(FRACTION_GAP(z[1][1])*F(M[0],Q))))
    return total[0]-tail[1],total[1]+tail[1]

def split(A):
    mid = (A[0]+A[1])//2
    assert A[0]<mid<A[1]
    return (A[0],mid),(mid,A[1])

def grid(A,k):
    assert k>=1
    return [(A[0]+(A[1]-A[0])*j//k,A[0]+(A[1]-A[0])*(j+1)//k) for j in range(k)]

def outer(a,b):
    a,b=F(a),F(b)
    lo=rat(a.numerator,a.denominator)[0]
    hi=rat(b.numerator,b.denominator)[1]
    assert lo<hi
    return lo,hi

def main():
    p=ArgumentParser()
    p.add_argument('--radius',nargs=2,default=['32','36'])
    p.add_argument('--angle',nargs=2,default=['1/2','13/10'])
    p.add_argument('--grid',nargs=2,type=int,default=[16,32])
    p.add_argument('--boxes',type=int,default=96)
    p.add_argument('--max-depth',type=int,default=5)
    a=p.parse_args()
    A,U=outer(*a.radius),outer(*a.angle)
    assert A[0]>=32*Q and rat(1,4)[0]<=U[0]<U[1]<=rat(7,5)[1]
    todo=[(R,V,0) for R in grid(A,a.grid[0]) for V in grid(U,a.grid[1])]
    least=None
    n=0
    while todo:
        R,V,d=todo.pop()
        try:
            lo,hi=integrate(R,V,a.boxes)
        except AssertionError:
            lo,hi=0,0
        if lo>0:
            n+=1
            least=lo if least is None else min(least,lo)
            continue
        if d==a.max_depth:
            print("INCONCLUSIVE at dyadic",R,V,"bounds",lo,hi,"denom",Q,flush=True)
            raise ArithmeticError("refine computational bounds; there is no counterexample here")
        if F(R[1]-R[0],R[0]) >= F(V[1]-V[0],4*Q):
            todo.extend((RR,V,d+1) for RR in split(R))
        else:
            todo.extend((R,VV,d+1) for VV in split(V))
    print("VERIFIED rectangle",a.radius,a.angle,"accepted",n,
          "lower half-integral bound",least,"/",Q,flush=True)

if __name__=='__main__':
    main()
