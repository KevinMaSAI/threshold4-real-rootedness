"""Cross-check the original four-piece tilt, using the factored exponent."""
from phase_tilt_factored import (Q, ONE, ZERO, rat, quo, add, sub, mul, exp,
    trig, geometry, normalized, exponent, outer, grid, split)
from phase_wide_cell import tail_bound
from fractions import Fraction as F
from argparse import ArgumentParser

def lower(C,n):
    R,z,p,a1,M,aE=C
    N=normalized(C)
    tilt=rat(9,20);stop=rat(3,5);drop=mul(stop,tilt)
    after=sub(sub(rat(81,25),p),stop)
    assert after[0]>0
    def val(x,y,slope,vert=False):
        phase=exponent(C,x,N,y=y)
        c,s=trig(phase[1])
        return mul(exp(phase[0]),s if vert else sub(c,mul(slope,s)))
    S=ZERO
    weight=rat(1,n)
    for j in range(n):
        t=(rat(j,n)[0],rat(j+1,n)[1])
        y0=mul(sub(t,ONE),p)
        y1=mul(t,stop)
        y2=mul(sub(ONE,t),drop)
        y3=add(stop,mul(t,after))
        v1=mul(p,val(y0,mul(y0,tilt),tilt))
        v2=mul(stop,val(y1,mul(y1,tilt),tilt))
        v3=mul(drop,val(stop,y2,ZERO,True))
        v4=mul(after,val(y3,ZERO,ZERO))
        S=add(S,mul(weight,add(add(v1,v2),add(v3,v4))))
    return S[0]-tail_bound(C,F(81,25))[1]

def main():
    p=ArgumentParser()
    p.add_argument('--radius',nargs=2,required=True)
    p.add_argument('--angle',nargs=2,required=True)
    p.add_argument('--grid',nargs=2,type=int,default=[22,32])
    p.add_argument('--boxes',type=int,default=80)
    p.add_argument('--max-depth',type=int,default=10)
    a=p.parse_args()
    A,U=outer(*a.radius),outer(*a.angle)
    assert 20*Q<=A[0]<A[1]<=192*Q and rat(31,100)[0]<=U[0]<U[1]<=rat(13,10)[1]
    todo=[(R,V,0) for R in grid(A,a.grid[0]) for V in grid(U,a.grid[1])]
    total=0;least=None
    while todo:
        R,V,d=todo.pop()
        try:lo=lower(geometry(R,V),a.boxes)
        except AssertionError:lo=0
        if lo>0:
            total+=1;least=lo if least is None else min(least,lo)
            if total%512==0:print('accepted',total,'pending',len(todo),flush=True)
        elif d<a.max_depth:
            if F(R[1]-R[0],R[0])>=F(V[1]-V[0],2*Q):
                todo.extend((r,V,d+1) for r in split(R))
            else:todo.extend((R,u,d+1) for u in split(V))
        else:
            print('INCONCLUSIVE',R,V,d,lo,flush=True)
            raise ArithmeticError('refine remaining cell')
    print('VERIFIED factored replay of original tilt',a.radius,a.angle,'accepted',total,'least lower',least,'/',Q,flush=True)
if __name__=='__main__':main()
