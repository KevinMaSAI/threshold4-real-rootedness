# The positive-index marker sign for all 0 < p ≤ 1/8

This is a uniform additional region of the original two-saddle
proof, not the full conjecture. Use its notation R≥32, p=R arg z_p,
M=a e^R, Ω, and exact H=Im Ω(p)=−kπ, k≥1. There is no separate
lower bound on M or n in this marker theorem: if p≤1/8, stationarity
and the phase index already force the estimates below.
The cusp k=0 still uses the proof in big_blocks4_explicit_tail_18.md.

Put c=−3H/(2p³)>0. Since Ω'(±p)=0, its second divided difference is
exactly Ω'(w)=iM(w²−p²)L(w), where L is the average of
Ω'''/(iM) over the corresponding simplex of volume 1/2. Hence
c/M=(3/2)∫_0^1(1−t²) Re L(pt) dt. The old global real derivative
bound |Ω'''|≤2M shows c≤M without using any further threshold;
the small-saddle geometry also gives M≤2R for p≤.75. Thus
c≥(3π/2)·8³>2400, M>2400, and R>1200.

On |w|≤1.05 the two approximations (4) from that proof in fact
have error <50/R<1/24 here. To check the uniform constant on this
domain, write z/R=e^(iw/R). Then |z/R−1|≤1.1/R,
|z−R−iw|≤1/R, and |exp(z−R)−exp(iw)|<3/R.
The normalized Touchard polynomials T_3(z)/R³ and T_4(z)/R⁴
differ from 1 by <9/R and <14/R respectively, using their
explicit formulas and |z/R|≤1+1.1/R. The S terms in the
normalized derivatives are bounded by 6/R and 1/R, since
(1+a)/M≤1/R. Finally |exp(z−R)|<3. These give the claimed 50/R.
Averaging the approximation in L gives an error <1/48
from the average of exp(iw) over the simplex; on the real
p-interval Re L≥(cos(1/8))/2−1/48>.47, so c≥.47M.

## True and reference contour

Match the value and derivative at ±p with
Q(w)=Re Ω(p)+ic(w³/3−p²w). Take b=11/20, x_0=13/20. The
positive-half contour rises along w=x+ib(x−p) for 0≤x≤x_0,
drops vertically at x=x_0, and continues on the real arc.
Reflect to obtain the whole contour. Endpoints are unchanged,
and the integrand is entire.

For x≥p, on the vertical segment between real x and that line,
Re L>.25 and |Im L|<.325, from
Re L≥e^(−b x_0) cos(x_0)/2−1/48 and
|Im L|≤sin(x_0)/2+1/48. When integrating
Re[((x+iy)²−p²)L(x+iy)] with 0≤y≤b(x−p), the coefficient
of b(x−p)(x²−p²) is bounded below by
.25(1−b²/3)−.325b>0 after integration
(use xy≤b[x/(x+p)](x²−p²) at the upper endpoint).
This means that the top endpoint has real part no larger
than the real-circle point, and every intermediate point
on the vertical segment likewise. Negative y on x<p is
allowed; no vertical estimate there is needed since the
true and reference contour are compared directly. The
estimate at x=x_0 supplies the bound on the vertical tail.

On the straight part and its convex hull with ±p, the fourth
derivative modulus is <1.12 M by the bound above and
Im w≥−b/8. The fourfold divided difference therefore gives
|Ω(w)−Q(w)|≤1.12M |w²−p²|²/24. The cubic real part directly
drops by at least β c (x−p)²(x+p), β=b(1−b²/3).
By |w²−p²|²≤(1+b²)²(x−p)²(x+p)² and x+p≤.775,
both exponents and their convex combinations are at least
.36 c(x−p)²(x+p) below Re Ω(p):
β−1.12(1+b²)²·.775/(24·.47)>.36.
Taking the difference of exponentials and integrating
both straight halves, the absolute comparison error after
normalization is at most
.39 c ∫_0^∞ (x−p)²(x+p)² exp[−.36 c(x−p)²(x+p)] dx,
since 2√(1+b²)(1+b²)²·1.12/(24·.47)<.39.

The reference contour continued to infinity gives the Airy integral;
with the exact phase index k its amplitude exceeds
(2π/3)/√(cp) and its sign is (−1)^k, by the explicit Prüfer
bound already derived in big_blocks4_explicit_tail_18.md §2.3.
Bound the comparison using y=x−p and
(x+p)²≤4p²+4p|y|+y², x+p≥max(p,|y|).
The three relative contributions are, respectively,
at most 3.1p, 5.8/√(cp), and √p c^(−1/6).
These follow from the Gaussian third/fourth absolute moments
and the cubic Gamma moment, with d=.36:
.39·3 d^(−3/2)/√π <3.1,
.39·6 d^(−2)/π <5.8,
and .39 d^(−5/3) Γ(5/3)/π <1 (use Γ(5/3)<1.35).
Since cp³≥3π/2, their sum is <.84 for p≤1/8.

## Tails

For the reference x≥.65, x−p>.8x, so the real loss there
is ≥.31 c x³; the relative contribution is <.01
(even using the elementary integral bound obtained from
x³≥(.65)²x and c>2400).

For the true arc sharpen the real gap near x_0 as follows.
On 0≤u≤x_0, the sinc derivative satisfies
−(sinc u)'≥(1/3−u²/30)u. The other adverse terms in
−w exp(R−X)χ' have sum <.001u for R>1200 by the explicit
bounds of the outer geometry, and exp(X−R)>.99.
Thus −wχ'>.30u. Using w between 1.4R and 1.6R and integrating
the derivative identity from u_p to u_0=R sin(x_0/R)>.64
shows loss >.005M at cutoff:
(.30·1.4/(8·1.6))(.64²−.125²)²>.005.
After cutoff up to the expanded first arc endpoint,
χ(u_p)−χ(u)≥χ(u_p)−χ(u_0)>
(.30/(3.2R))(.64²−.125²)>.036/R,
so the real loss increases at slope >.03 M with x
(u≥.64, w≥1.4R, du/dx≥.99). The vertical segment at
cutoff is bounded by the real-circle value there. Counting both
halves, the true arc and vertical relative contribution is
less than (2b x_0+2/(.03M)) √M exp(−.005M)<.01
for M>2400, since the reference amplitude exceeds 1/√M.
Farther along the real arc the loss relative to the saddle
is at least R/10≥M/20 by the outer geometry. The remaining
relative error is at most 10 M^(3/2) exp(−M/20)<.01.
All estimates are monotonically stronger above the lower
thresholds. Thus total relative error is <.87, proving the
required alternating sign for all markers with 0<p≤1/8.
There remains a substantial gap for larger p and unbounded R.
