# Strict negative roots for all n ≥ 67,500,000

Replace the uniform angular threshold 1024 in full_tail_539m.md
by 512. The cusp and smaller angle 0<p≤1/8 are still covered
by their original estimates. The new signed Airy comparison
and large-index Gaussian theorem phase_R512_low.md cover
1/8≤p≤1/2. The proof phase_R512_medium.md covers 1/2≤p≤1.5
with new local windows and true exterior slopes. Larger
p by the old R≥256 mid/high-angle bounds.
The two exact rational checkers airy_quartic_R512_check.py and
margin_R512_check.py substantiate their numerical constants.

For 256≤R≤512 and p≤1.5, the exclusion from full_tail_539m.md
gives n≤1.001 DS(R)≤1.001(512+512²+512³/2)<67,500,000.
Thus only the previous mid/high sector applies there for larger n,
and the cusp occurs above 512. The lower radius exclusions,
compact radius proof, small-radius bridge and exact left anchor
are unchanged. Exact phase sign brackets again exhaust all
degree floor(n/4) negative roots, strictly simple.
This improves the uniform infinite tail but is not an all-n answer.

If the remaining continuous marker signs at 192≤R≤512 are
independently proved, they will join directly with all the older
smaller-radius proofs to yield all n≥7254: one need not leave
a separate numerical margin around N(512).
