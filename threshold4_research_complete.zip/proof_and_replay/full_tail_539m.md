# Strict negative roots for all n ≥ 539,000,000

Same saddle and phase-lift proof as full_tail_4_4b.md,
with a smaller uniform angular threshold R≥1024.
The sectors are:
- k=0: cusp sign from big_blocks4_explicit_tail_18.md §4.
- 0<p≤1/8: the independent small-marker proof
  airymarker_small_p.md (H forces M sufficiently large).
- 1/8≤p≤1/2 and k=1..8: the quartic-extracted Airy comparison
  phase_R1024_quartic.md plus airy_quartic_R1024_check.py.
- 1/8≤p≤1/2 and k≥9, or 1/2≤p≤1.5:
  phase_R1024_gaussian.md.
- p≥1.5: the previously proved analytic mid- and high-angle
  inequalities on R≥256.
Thus all angular markers and the cusp work at R≥1024.

For 256≤R≤1024, p≤1.5 implies u≤p and
u+arg z≤1.5+1.5/256<π/2, making Re[z exp(z−R)] positive.
The positive saddle equation gives a<.001, since
f≥sin(1.5)/1.5>.66, exp(X−R)>.99 and w≤1.61R
give a/(1+a)<2.5R exp(−R). Consequently
n≤1.001 DS(R)≤1.001(1024+1024²+1024³/2)<539,000,000.
So at larger n the real cusp occurs beyond R=1024; every
actual saddle in this radial strip has p>1.5 and is covered
by the analytic mid- and high-angle inequalities.

At 32≤R≤256, the earlier exclusion in full_tail_35b.md
gives n<1.001(R+R²+R³/2)+12R² when p≤2.5, which is
also far below the new tail threshold. Hence only p>2.5
occurs there, and the high-angle theorem applies.
For the remaining compact and small radii, use the former
compact [1/20,32] certificate (effective from 56230),
small-R bridge and exact left anchor without change.
The continuous phase path starts at H=0 and ends
strictly lower than −(m−1)π. The first successive exact
marker signs provide m−1 strict disjoint roots, plus a
separate last far-left root. Their count equals degree m.
This is a proof of an infinite tail, not an all-n theorem.
