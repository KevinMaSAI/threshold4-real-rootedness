"""Exact dyadic interval checker of compact angular minimum for B(z).
Float math chooses candidate centers only; proof premises are fixed-point integers.
"""
import argparse
from functools import lru_cache
import math

BITS=58
Q=1<<BITS
ZERO=(0,0); ONE=(Q,Q)
PIHI=22*Q//7+1

def point(x):return (x,x)
def const(n):return (n*Q,n*Q)
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[1],-a[0])
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    t=a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]
    return (min(t)//Q,-((-max(t))//Q))
def scale(a,k):
    if k<0:return scale(neg(a),-k)
    return a[0]*k,a[1]*k
def div(a,k):return a[0]//k,-((-a[1])//k)
def widen(a,k):return (a[0]-k,a[1]+k)
def clip(a):return max(a[0],-Q), min(a[1],Q)
def sq(a):
    if a[0]<=0<=a[1]:return (0,-((-max(a[0]*a[0],a[1]*a[1]))//Q))
    return mul(a,a)

@lru_cache(maxsize=300000)
def exp0(x):
    # Scale into [-1/2,1/2] and exponentiate by repeated squaring.
    split=1
    while 2*abs(x)>Q*split:split*=2
    y=div(point(x),split)
    a=ONE; s=ONE
    for j in range(1,20):
        a=div(mul(a,y),j)
        s=add(s,a)
    # Tail <= 2/(2^20 20!) + 1 dyadic unit to cover rounded y.
    s=widen(s,2)
    while split>1:
        s=sq(s);split//=2
    return s

def exp(a):return (exp0(a[0])[0],exp0(a[1])[1])

@lru_cache(maxsize=300000)
def trig0(x):
    split=1
    while 2*abs(x)>Q*split:split*=2
    y=div(point(x),split); ny2=neg(sq(y))
    c=ONE; s=y; tc=ONE; ts=y
    for j in range(1,11):
        tc=div(mul(tc,ny2),(2*j-1)*(2*j))
        ts=div(mul(ts,ny2),(2*j)*(2*j+1))
        c=add(c,tc);s=add(s,ts)
    # Absolute tails each < 1/Q on the reduced interval.
    c=widen(c,1);s=widen(s,1)
    while split>1:
        c,s=clip(sub(scale(sq(c),2),ONE)),clip(scale(mul(c,s),2))
        split//=2
    return clip(c),clip(s)

def trig(a):
    x=(a[0]+a[1])//2
    w=max(x-a[0],a[1]-x)
    c,s=trig0(x)
    return clip(widen(c,w)),clip(widen(s,w))

def Rconstants(R):
    if R[1]<=2*Q:
        weights=[ONE]
        for k in range(5,23):
            weights.append(div(mul(weights[-1],R),k))
        return (True,R,weights)
    return (False,R,sq(R),mul(sq(R),R),exp(neg(R)))

def calc(C,T,j):
    if C[0]:
        ans=ZERO
        for k,a in enumerate(C[2],4):
            c,s=trig(scale(T,k))
            b=(c,scale(s,-k),scale(c,-k*k))[j]
            ans=add(ans,mul(a,b))
        # For R<=2 and k>=23, |tail| <= weight(23)*23^j*2.
        a=div(mul(C[2][-1],C[1]),23)[1]
        return widen(ans,2*a*23**j)
    _,R,R2,R3,E=C
    c,s=trig(T); x,y=mul(R,c),mul(R,s)
    cos_y,sin_y=trig(y); EE=exp(sub(x,R))
    c2,s2=trig(scale(T,2));c3,s3=trig(scale(T,3))
    if j==0:
        small=add(add(ONE,x),add(div(mul(R2,c2),2),div(mul(R3,c3),6)))
        e=cos_y
    elif j==1:
        small=neg(add(add(y,mul(R2,s2)),div(mul(R3,s3),2)))
        e=neg(add(mul(y,cos_y),mul(x,sin_y)))
    else:
        small=neg(add(add(x,scale(mul(R2,c2),2)),div(scale(mul(R3,c3),3),2)))
        e=sub(mul(add(y,scale(mul(x,y),2)),sin_y),mul(sub(add(x,sq(x)),sq(y)),cos_y))
    return sub(mul(EE,e),mul(E,small))

def guess(R):
    r=(R[0]+R[1])/(2*Q)
    def f(t):
        x=r*math.cos(t); y=r*math.sin(t)
        return math.exp(x-r)*math.cos(y)-math.exp(-r)*(1+x+r*r/2*math.cos(2*t)+r**3/6*math.cos(3*t))
    step=math.pi/160
    j=min(range(161),key=lambda k:f(k*step))
    l=max(0,(j-1)*step); h=min(math.pi,(j+1)*step)
    for _ in range(30):
        u=(2*l+h)/3;v=(l+2*h)/3
        if f(u)<f(v):h=v
        else:l=u
    return round((l+h)/2*Q)

def exclusion(C,theta0,L,H):
    target=calc(C,point(theta0),0)[1]
    todo=[(0,L,0),(H,PIHI,0)]
    num=0
    while todo:
        a,b,depth=todo.pop()
        num+=1
        if calc(C,(a,b),0)[0]>target:continue
        if depth>=15:return False,num
        if depth>=5:
            d=calc(C,(a,b),1)
            if d[0]>=0 and calc(C,point(a),0)[0]>target:continue
            if d[1]<=0 and calc(C,point(b),0)[0]>target:continue
        m=(a+b)//2
        todo.append((a,m,depth+1));todo.append((m,b,depth+1))
        if num>420:return False,num
    return True,num

def try_R(R):
    C=Rconstants(R)
    theta0=guess(R);r=(R[0]+R[1])/(2*Q)
    W=round(min(0.095,0.68/r)*Q)
    for den in (1,2,3):
        a=theta0-W//den;b=theta0+W//den
        if a<=0 or b>=PIHI:continue
        if calc(C,point(a),1)[1]>=0 or calc(C,point(b),1)[0]<=0:continue
        # Verify strict convexity with several boxes, not a single wide interval.
        k=12
        if any(calc(C,(a+j*(b-a)//k,a+(j+1)*(b-a)//k),2)[0]<=0 for j in range(k)):continue
        ok,count=exclusion(C,theta0,a,b)
        if ok:return (R[0],R[1],theta0,a,b),count
    return None,0

def replay(box):
    r,s,c,a,b=box
    assert 0<a<c<b and 100*b<314*Q
    C=Rconstants((r,s))
    assert calc(C,point(a),1)[1]<0 and calc(C,point(b),1)[0]>0
    assert all(calc(C,(a+j*(b-a)//12,a+(j+1)*(b-a)//12),2)[0]>0 for j in range(12))
    ok,count=exclusion(C,c,a,b)
    assert ok
    return count

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--read',default=None)
    p.add_argument('--write',default=None)
    args=p.parse_args()
    LB=Q//20
    UB=32*Q
    if args.read:
        import json
        rows=json.load(open(args.read))
        assert rows[0][0]==LB and rows[-1][1]==UB
        assert all(a[0]<a[1] and a[1]==b[0] for a,b in zip(rows,rows[1:]))
        assert rows[-1][0]<rows[-1][1]
        total=sum(map(replay,rows))
        print('VERIFIED',len(rows),total)
        return
    todo=[(2*Q,UB,0),(LB,2*Q,0)]
    rows=[];boxes=0
    while todo:
        a,b,d=todo.pop()
        res,n=try_R((a,b))
        if res:
            rows.append(res);boxes+=n
            if len(rows)%50==0:print('radial patches',len(rows),'up to',b/Q,flush=True)
            continue
        if d>=20:
            raise ArithmeticError((a/Q,b/Q,d))
        c=(a+b)//2
        todo.append((c,b,d+1));todo.append((a,c,d+1))
    print('CERTIFIED',len(rows),boxes)
    if args.write:
        import json
        with open(args.write,'w') as f:json.dump(rows,f,indent=1)
if __name__=='__main__':main()
