"""Exact verification; Python 3 standard library, no float roots.
Run: python3 check.py --limit 40
"""
import argparse
from fractions import Fraction
from math import comb, factorial, gcd, lcm


def insertion(N):
    # Add n+1 as singleton, to a large block, to a size-1/2 block,
    # or to a size-3 block (which becomes large).
    rows=[[1]]
    for n in range(N):
        row=[0]*((n+1)//4+1)
        for k,val in enumerate(rows[n]):
            row[k]+=(k+1)*val
        for r in (1,2,3):
            if r<=n:
                for k,val in enumerate(rows[n-r]):
                    row[k+(r==3)]+=comb(n,r)*val
        rows.append(row)
    return rows


def designated_block(N, weight3=1):
    # Delete the block containing label n. No derivative/lag relation used.
    rows=[[1]]
    for n in range(1,N+1):
        row=[0]*(n//4+1)
        for s in range(1,n+1):
            for k,v in enumerate(rows[n-s]):
                row[k+(s>=4)]+=comb(n-1,s-1)*v*(weight3 if s==3 else 1)
        rows.append(row)
    return rows


def egf_rows(N):
    # n![z^n] exp(A) B^k/k!, via integer binomial convolution.
    a=[1]
    for n in range(1,N+1):
        a.append(sum(comb(n-1,s-1)*a[n-s] for s in range(1,min(n,3)+1)))
    rows=[[x] for x in a]
    q=a
    for k in range(1,N//4+1):
        q=[sum(comb(n,s)*q[n-s] for s in range(4,n-4*(k-1)+1))
           for n in range(N+1)]
        for n in range(4*k,N+1):
            value,rest=divmod(q[n],factorial(k))
            assert rest==0
            rows[n].append(value)
    return rows


def primitive(p):
    den=lcm(*(v.denominator for v in p))
    z=[int(v*den) for v in p]
    common=gcd(*z)
    return [v//common for v in z] if common else []


def trim(p):
    while p and p[-1]==0:
        p.pop()
    return p


def quotient_remainder(p,q):
    p=list(map(Fraction,p)); out=[Fraction(0)]*max(0,len(p)-len(q)+1)
    while len(p)>=len(q):
        k=len(p)-len(q)
        a=p[-1]/q[-1]
        out[k]=a
        for i,b in enumerate(q):
            p[k+i]-=a*b
        trim(p)
    return trim(out),p


def derivative(p):
    return [i*v for i,v in enumerate(p) if i]


def sturm(p):
    S=[p]
    d=derivative(p)
    if not d:
        return S
    S.append(d)
    while True:
        _,r=quotient_remainder(*S[-2:])
        if not r: return S
        S.append(primitive([-v for v in r]))


def signs_infty(S,direction):
    return [((p[-1]>0)-(p[-1]<0))*direction**(len(p)-1) for p in S]


def changes(s):
    a=[v for v in s if v]
    return sum(x!=y for x,y in zip(a,a[1:]))


def certificate(p):
    # Peel off gcd and recompute on the square-free part.
    S=sturm(p)
    if len(S[-1])>1 and len(p)>1:
        q,r=quotient_remainder(p,S[-1])
        assert not r
        S=sturm(primitive(q))
    neg,pos=[signs_infty(S,d) for d in (-1,1)]
    return dict(sf_degree=len(S[0])-1,real=changes(neg)-changes(pos),
                degrees=[len(q)-1 for q in S], negative_infty=neg,positive_infty=pos)


def bezout(f,g):
    # Numerator f(x)g(y)-f(y)g(x) divided by x-y.
    d=max(len(f),len(g))-1
    M=[[0]*d for _ in range(d)]
    for i in range(d+1):
        for j in range(i):
            c=(f[i] if i<len(f) else 0)*(g[j] if j<len(g) else 0)
            c-=(g[i] if i<len(g) else 0)*(f[j] if j<len(f) else 0)
            for k in range(i-j):
                M[i-1-k][j+k]+=c
    return M


def first_nonpositive_pivot(M):
    M=[list(map(Fraction,row)) for row in M]
    for i in range(len(M)):
        p=M[i][i]
        if p<=0: return i,p
        for j in range(i+1,len(M)):
            for k in range(i+1,len(M)):
                M[j][k]-=M[j][i]*M[i][k]/p
    return None


def evaluate(p,x):
    v=0
    for a in reversed(p):
        v=v*x+a
    return v


def fixed_boxes(n,m):
    # Q_{n,m}: n labels, m named boxes, empty boxes allowed.
    d=n//4
    rows=[[1]+[0]*d]+[[0]*(d+1) for _ in range(n)]
    for _ in range(m):
        rows=[[sum(comb(i,s)*rows[i-s][k-(s>=4)] for s in range(i+1)
                   if k>=(s>=4)) for k in range(d+1)] for i in range(n+1)]
    return rows[n]


def auxiliary_failures(rows):
    ordered=[factorial(k)*c for k,c in enumerate(rows[11])]
    a,b,c=ordered
    assert b*b-4*a*c==-16572783743
    print('Only large blocks ordered, n=11:',ordered,certificate(ordered))
    weighted=designated_block(12,weight3=8)[12]
    assert weighted==[238929912,31258075,1115895,5775]
    assert certificate(weighted)['real']==1
    print('Weight 8 on triples, n=12:',weighted,sturm(weighted),certificate(weighted))
    q,r=fixed_boxes(8,3),fixed_boxes(8,15)
    mix=[42000*a+b for a,b in zip(q,r)]
    assert certificate(q)['real']==certificate(r)['real']==2
    assert certificate(mix)['real']==0
    print('Positive mixture of named-box rows, n=8:',q,r,mix,certificate(mix))


def edge_identity(rows):
    # Check the exact reversed Taylor coefficient formula separately.
    def multiply(p,q,L):
        return [sum(p[i]*q[j-i] for i in range(j+1))
                for j in range(L+1)]
    for n in range(min(25,len(rows))):
        m,r=divmod(n,4)
        for k in range(m+1):
            L=4*k+r
            U=[Fraction(a,factorial(i)) for i,a in enumerate(
                row[0] for row in rows[:L+1])]
            H=[Fraction(24,factorial(i+4)) for i in range(L+1)]
            for _ in range(m-k):
                U=multiply(U,H,L)
            value=Fraction(factorial(n),factorial(m-k)*24**(m-k))*U[L]
            assert value==rows[n][m-k]
    print('Reversed-edge coefficient identity agrees through', min(24,len(rows)-1))

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--limit',type=int,default=40)
    args=ap.parse_args()
    N=max(args.limit,14)
    rows=insertion(N)
    assert rows==designated_block(N)==egf_rows(N)
    assert rows[4]==[14,1] and rows[8]==[2780,1325,35]
    assert certificate([1,0,1])['real']==0
    assert certificate([1,2,1])['sf_degree']==certificate([1,2,1])['real']==1
    assert certificate([2,3,1])['real']==2
    for n,p in enumerate(rows[:args.limit+1]):
        assert len(p)-1==n//4 and all(v>0 for v in p)
        c=certificate(p)
        if c['real']!=c['sf_degree']:
            print('Counterexample',n,p,c, sturm(p)); return
    print('Three independent coefficient generators agree through',N)
    print('Exact Sturm check:',args.limit+1,'rows real-rooted through',args.limit)
    # Check F*P_n' at roots by Bezout(F,P_n), i.e. -F(r)P_n'(r).
    strict=[]
    for n in range(4,args.limit):
        # In the quotient g/f the polynomial part is constant or has
        # positive slope. Evaluate Bez(f,-rem(g,f)) on the root basis
        # to get the sign of -g(r)*f'(r) without approximating r.
        f,g=rows[n],rows[n+1]
        _,r=quotient_remainder(g,f)
        M=bezout(f,[-a for a in r])
        if first_nonpositive_pivot(M) is None:
            strict.append(n)
    print('Exact negative-residue consecutive transitions:',len(strict),'of',max(0,args.limit-4))
    print('n=8 Sturm certificate:',certificate(rows[8]))
    p=rows[14]
    q=[sum(comb(k,l)*p[k] for k in range(l,len(p))) for l in range(len(p))]
    print('Translated n=14 q1^2-4*q0*q2:',q[1]**2-4*q[0]*q[2])
    # The universal companion example satisfies degree caps and input order.
    # n=5: input rows indexed 2 through 5 are 1,1,x+2,x+1.
    print('Universal companion witness F(-1):',evaluate([21,17],-1))
    assert evaluate([21,17],-1)==4
    auxiliary_failures(rows)
    edge_identity(rows)

if __name__=='__main__':
    main()
