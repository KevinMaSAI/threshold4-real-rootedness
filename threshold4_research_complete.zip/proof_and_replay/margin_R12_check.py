"""Exact rational/directed checks for the R12 and quarter bridges."""
from fractions import Fraction as F
from angular_certificate import Q, ONE, add, sub, mul, exp, trig, neg, point
from phase_k_certificate import PI, rat, quo, root
def b(x):
    f=F(str(x)); return rat(f.numerator,f.denominator)
def m(*it):
    x=ONE
    for y in it:x=mul(x,y)
    return x
def lt(x,y):
    assert x[1]<y[0],(x[1]/Q,y[0]/Q)
pilo,pihi=F(PI[0],Q),F(PI[1],Q)
R=12; X=F('.962')*R; u=F('3.25')
assert X*X+u*u<R*R
z=u*u/(R+X)
assert 1-z+z*z/2-z**3/6>F('.63')
assert 1/X**3+1/X**2+3*(1+1/X)/(F('1.5')*R*R)<F('.024')
assert F('.1')/X+u/X**3+(u/X+3*u/(F('1.5')*R**2))*(F('.1')/pilo+1/X)<F('.05')
assert F('.63')*(F('.1')-F('.024'))/F('1.68')>F(1,36)
assert F('.63')*(F('.295')-F('.05'))/(F('1.68')*u)>F(1,36)
assert F('.1')/X+u/X**3+max(u/X*(F('.1')/F('2.8')+1/X),(F('.35')/F('2.8')+1/X)*3*u/(F('1.5')*R**2))<F('.052')
assert pihi*pihi<F('9.87')
assert F('.75')-1/(F('2.84')*R)>F('.72')
assert F('9.87')/(F('1.962')*R)+F('9.87')+F('.75')*F('9.87')*R<F('8.26')*R
assert F('.63')*pilo*F('.1')>F('.195')
lt(b('.260'),quo(trig(b('2.45'))[1],b('2.45')))
lt(b('-.78'),trig(b('2.45'))[0])
assert F('.260')-F('.78')/X>F('.192')
assert F('.260')-F('.78')/(F('.962')*18)>F('.214')
z=F('2.45')**2/(R+X)
assert 1-z+z*z/2-z**3/6>F('.77')
lt(b(150000),exp(b(12)))
assert F('1.001')*(18+18**2+F(18**3,2)+F('1.68')/F('.192')*18**2)<7254
assert F('1.001')*(20+20**2+F(20**3,2)+F('1.62')*F('.86')/F('.214')*20**2)<7254
lt(b('-.86'),trig(b('2.587'))[0])
assert F('2.9')-F('2.9')**3/(6*R*R)>F('2.871')
assert F('3.29')-F('3.29')**3/(6*R*R)>pihi+F('.1')
assert F('.14')*F('1.5')*F('2.8')*F('.962')**2/(2*F('1.68'))>F('.16')
assert F('.63')*(1-F('.766')**2/2)*F(11,12)>F('.4')
assert F('.63')*(1-F('.65')**2/2)*F(11,12)>F('.45')
M=b(630);S=root(M);tau=F('.45')
L=2/(8*tau**2)+20/(24*tau**3)
lt(quo(m(root(b(F(3)/tau)),b(L)),M),b('.043'))
lt(quo(m(b(16),exp(neg(m(b('.009'),M)))),S),b('.006'))
lt(quo(m(b(18),exp(neg(m(b('.008'),M)))),S),b('.006'))
lt(m(b('1.7'),S,exp(neg(m(b('.05'),M)))),b('.001'))
lt(m(b('2.8'),b(12),exp(b('-4.44')),S,exp(neg(m(b('.195'),M,b('.05'))))),b('.03'))
assert F('2.8')-F('2.8')**3/(6*R*R)>F('2.774')
assert (pihi-F('2.774'))/F('2.774')<F('.133')
assert 1-(pihi-F('2.774'))**2/2>F('.93')
assert 6*F('.93')/F('.133')**2>315
M=b(315);S=root(M)
lt(quo(m(root(b(F(3)/tau)),b(L)),M),b('.086'))
lt(quo(m(b(16),exp(neg(m(b('.009'),M)))),S),b('.054'))
lt(quo(m(b(18),exp(neg(m(b('.008'),M)))),S),b('.083'))
lt(m(b('1.7'),S,exp(neg(m(b('.032'),M)))),b('.002'))
lt(m(b('2.8'),b(12),exp(b('-4.44')),S,exp(neg(m(b('.195'),M,b('.05'))))),b('.327'))
t=F(1,20)
for j,lim in enumerate(['.05264','.267','1.35','6.84','34.82']):
    assert sum((i+4)**j*t**i for i in range(1,41))+2*45**j*t**41<F(lim)
co=trig(b('.5'))[0]
lt(b('12.6'),sub(m(b(16),co),b(F('1.35')+F(1,675))))
lt(b('.014'),sub(sub(ONE,co),b(2*(F('.05264')+F(1,675)))))
mu=b(675)
L=F(292)/(8*F('12.6')**2)+F(5*72**2)/(24*F('12.6')**3)
lt(m(b(L),root(b(F(18)/F('12.6')))),b('1.1'))
tail_total=add(quo(b('1.1'),mu),add(m(b(4),exp(neg(m(b('.0315'),mu)))),
                  add(m(root(b(F(18)/F('12.6'))),exp(b(F('-.23')*F('17.5')))),
                      m(b(2),root(m(b(18),mu)),exp(neg(m(b('.014'),mu)))))))
lt(tail_total,b('.05'))
print('VERIFIED outward-rational constants for R12 and quarter bridges')
