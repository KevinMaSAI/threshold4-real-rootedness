# An auxiliary determinant is not real-rooted (not the original problem)

With the homotopy of homotopy_lag_determinant_degree.md and its
convention J_n, the Dreamer independently computed
J_7=(232−190v)+(540+155v)y+(105+35v)y² and
J_10=(9496−25193v+4746v²)+(53033−7099v−9492v²)y
+(48546+30192v+4746v²)y²+(4900+2100v)y³.
The 3×3 Bézout determinant (using the same convention) equals
49000 times the polynomial with ascending coefficients:
[195299979758828, 915665570545925, 1616949093592699,
 1425918522224231, 673162308258329, 162952976440104, 15918721264404].
Independent integer Sturm division gives degrees (6,5,4,3,2,1,0)
and leading signs (+,+,+,+,−,+,+), hence endpoint variations 4 and 2.
Constant final remainder proves squarefreeness. The two real
roots are negative; the four others are nonreal. Therefore
requiring all real roots for the auxiliary determinant is too strong.
Its positive coefficients directly show its strict positivity on [0,∞)
at n=10; the obstruction says nothing against the original conjecture.
