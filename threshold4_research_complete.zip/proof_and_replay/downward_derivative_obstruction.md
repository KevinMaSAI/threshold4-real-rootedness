# Why differentiating the known large-n theorem does not descend directly

Let A(z)=exp S(z), B(z)=e^z−1−S(z), C(z)=24B(z)/z⁴. For m≥0,

    (24^m/(n+4m)!) P_(n+4m)^(m)(t)
       = [z^n] A(z) exp(tB(z)) C(z)^m.

This follows by differentiating the exact exponential generating
function m times and extracting the factor z^(4m). C(z) is the
moment-generating function of Beta(1,4):
C(z)=4∫_0^1 (1−x)^3 exp(xz) dx by Taylor's integral remainder.
Thus the family of m derivatives converges downward to P_n/n!
only at m=0, not as m→∞.

In fact for a fixed n, eventual real-rootedness in m of this
derivative-type family holds regardless of A, as long as A is real
analytic near 0 and A(0)=1. Substitute z=v/m, t=m⁴y. Then as m→∞,

    A(v/m) exp(m⁴y B(v/m)) C(v/m)^m
          → exp(y v⁴/24 + v/5)

uniformly on compact v,y sets. Hence after multiplying the coefficient
by m^(−n) the limit polynomial is
L_n(y)=Σ_(j≤n/4) y^j/[(24^j j!) 5^(n−4j)(n−4j)!].
It has degree q=floor(n/4), and all its zeros are simple and negative:
reverse the polynomial, set r=n−4q, and read its coefficients, up
to positive common factor and positive scaling of the variable, as
binomial(q,j) j!/(4j+r)!. The diagonal sequence j!/(4j+r)! is a
positive multiplier, up to that common factor and a positive scaling:
expand the factorial in the four step-4 factors; the factor
((r+i)/4)_j with i=4−r is (1)_j=j! and cancels. Each of the remaining
three reciprocal positive Pochhammer sequences is a multiplier by
the Laguerre Jensen polynomial argument in big_blocks4_homotopy_endpoint.md.
Applying the first to (1+y)^q gives distinct negative roots by Laguerre
orthogonality. The other two preserve simplicity on the interior of
the real-rooted cone: an invertible real diagonal map preserving the
whole cone maps interior into interior. Leading and constant terms
remain nonzero, so all roots remain negative. Reversal preserves
simplicity and negative sign. For q=0 the statement is vacuous.
Simple real roots are an open condition for degree-q real polynomials,
or equivalently use disjoint real-centered disks and Rouché.
Consequently the differentiated family is eventually real-rooted in m
even when the start m=0 is nonreal-rooted. This is an obstruction to
inferring the desired low n solely from eventual high n via these
derivatives; it is not a counterexample to the original question.
