# Endpoint scaling theorem for the threshold 3 → 4 homotopy

**Statement.** Write n = 4m+r, 0 ≤ r < 4. Let ε = 1−s denote the
remaining fraction of the t-weight on triples. For any fixed
0 < δ < L < ∞ and 0 ≤ C < ∞, for all sufficiently large m (depending
on δ,L,C), there are no multiple or nonreal zeros of F_n(s,t) in
δm⁵ ≤ |t| ≤ Lm⁵ whenever 0 ≤ ε ≤ C/m². This is not an all-n theorem.

## 1. Locally uniform limit

In the interpolation the weight of a triple is 1−ε+εt, the weight
of any block of size ≥4 is t, and pairs and singletons have weight 1.
Therefore the coefficient formula is

    F_n(1−ε,t) = n! [z^n] exp(S(z)+ε(t−1)z³/6+tB(z)),
    S(z)=z+z²/2+z³/6, B(z)=e^z−1−S(z).

Set z=ζ/m, t=m⁵w, ε=c/m², and h⁴=w/24. We can split the exponential
into exp(mwζ⁴/24) D_m(ζ,w;c). Here

    D_m = exp(S(ζ/m) + c(m⁵w−1)ζ³/(6m⁵)
                + m⁵w[B(ζ/m)−ζ⁴/(24m⁴)]).

On bounded ζ,w,c sets it converges uniformly to
D=exp(cwζ³/6+wζ⁵/120). Normalize the polynomial by

    R_m(w;c)= [m!/(m^(5m+r) (w/24)^m (4m+r)!)]
                 × F_(4m+r)(1−c/m²,m⁵w).

Expanding the separated exponential gives the exact coefficient sum

    R_m = Σ_(j=0)^m [m!/((m−j)!m^j)] (w/24)^(−j) [ζ^(4j+r)] D_m.

The falling-factorial factor is in [0,1] and tends to 1 for fixed j.
For |w|≥δ on a compact set, choose a fixed Cauchy radius in ζ greater
than (24/δ)^(1/4). Cauchy's estimate dominates the sum uniformly by a
geometric series, for bounded c as well. The coefficient convergence
and geometric bound show that R_m converges locally uniformly in the
punctured w-plane, uniformly in bounded c. Substituting ζ=u/h and
using the fourth-root-of-unity coefficient filter gives the limit

    R(w;c) = (h^r/4) Σ_(ω⁴=1) ω^(−r) exp(qω+p/ω),
    p=4ch, q=1/(5h).

It is independent of the choice of h, by reindexing the sum. The
normalizations have neither zeros nor poles in the punctured plane.

## 2. The limit zeros are real negative

Set U=(q+p+i(q−p))/2, iW=(q+p−i(q−p))/2. Then

    U²−W²=8c/5,
    λ=U²W²=−(q²+p²)²/4
          =−[(4c)^4 w/24 + 24/(625w) + 2(4c)²/25]/4.

Removing h^r, expand the four filters as follows:

    r=0: cosh U cos W
    r=1: [(1−i)/2](sinh U cos W − cosh U sin W)
    r=2: i sinh U sin W
    r=3: [(1+i)/2](sinh U cos W + cosh U sin W).

These follow by writing the filter as half of, respectively,
cosh(q+p)+cos(q−p), sinh(q+p)+sin(q−p), cosh(q+p)−cos(q−p),
and sinh(q+p)−sin(q−p). Use q+p=U+iW and i(q−p)=U−iW.

For r=0 or 2, a zero forces at least one of U,W onto a coordinate axis
of the complex plane; U²−W²=8c/5 then forces the other onto an axis too.
For r=1 or 3 suppose both variables are off the axes. Write
x=|Re W|, y=|Im W|, u=|Re U|, v=|Im U|. Here uv=xy and u≥x, v≤y:
otherwise u<x and v>y would contradict u²−v²=x²−y²+8c/5.
The root condition gives tan W = ±tanh U. The denominators of the real
and imaginary parts of either of these fractions coincide (within that
fraction). Thus comparing absolute values of the real and imaginary
parts, and eliminating the denominators, gives

    |sin(2x) sin(2v)| = sinh(2u) sinh(2y).

In detail, if the positive denominators of tan W and tanh U are A and
B respectively, the equations are B|sin(2x)|=A sinh(2u) and
B sinh(2y)=A|sin(2v)|. This equality is impossible: the left side is at
most 4xv and the right side is strictly greater than 4uy≥4xv.
Therefore U,W are on coordinate axes at every zero.

For a zero with λ≥0 and c>0, let A=(4c)^4/24, B=24/625 and
b=(4c)²/25=√(AB). The equation Aw²+(4λ+2b)w+B=0 implies w<0,
since the quadratic discriminant is 16λ(λ+b)≥0 and its sum and
product of roots have signs − and + respectively. For c=0 the relation
λ=−B/(4w) directly gives w<0 (λ=0 is impossible).
If λ<0, U must be real nonzero and W purely imaginary nonzero, since
the other orientation gives U²−W²<0. None of the filters vanishes in
this orientation: the even ones are nonzero products, and for odd r
the two terms are nonzero real and nonzero imaginary respectively.
Thus λ<0 cannot occur at a zero.

## 3. Simplicity and transfer to the polynomial

On w<0 choose h=a e^(iπ/4), a=(−w/24)^(1/4)>0. Then

    U=(1/(5a)+4ca)/√2 >0,   W=(4ca−1/(5a))/√2.

W is strictly increasing in a with positive derivative. For even r
the real factors cos W and sin W yield simple zeros, since the other
factor is nonzero. For odd r, cos W≠0 at a zero; the derivative in W
of tan W ∓ tanh(√(W²+8c/5)) is strictly positive: the first term has
derivative ≥1, and the absolute derivative of the latter term is
≤sech² U<1 (including c=0, since U>0 at finite w). W varies with w
with nonzero derivative, so all zeros are simple. In particular,
for r=2 the root W=0 when c>0 is simple in w although the quadratic
equation involving λ has a double root there.

To prove the uniform statement, if offending zeros exist along m→∞,
take a subsequence with fixed remainder r and limits w_j→w_* in the
compact annulus, c_j→c_* in [0,C]. Uniform convergence implies
R(w_*;c_*)=0. Enclose this simple negative root in a small conjugation-
invariant disk away from 0 with no other limit roots or zeros on the
boundary. Uniform convergence of R_(m_j)(·;c_j) to R(·;c_*) on the
disk, and Rouché's theorem, give exactly one zero counting multiplicity
in the disk. The normalized functions have real coefficients up to
the real monomial prefactor; conjugation forces that unique zero to
be real, and the multiplicity count gives simplicity. Contradiction.

This excludes collisions uniformly in the specified large-root
window even when c=0 or c varies. It does not cover w tending to 0
or infinity, unbounded c, or all intermediate n. The proof is
analytic; no approximate root computations are used.
