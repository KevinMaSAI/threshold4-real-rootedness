# Strict negative roots for every 27004 ≤ n ≤ 1040447

This is a uniform interval theorem for the original threshold-four
polynomial, not the full conjecture. It combines analytic sign counts
and exact directed-rational certificates over *continuous* ranges of
saddle parameters. No step checks all these n one by one.

For n in the stated band, monotonicity of the critical boundary
N(R)=R⁴/[2(R+1−E(R))], E(R)=e^(−R)(1+2R+3R²/2), gives
32<ρ<128. Indeed N(32)<16384 and
N(128)>128⁴/258>1040447. The two complex saddles continue from the
real cusp ρ down to R=20, by outer_saddle_R20.md and the
geometry in big_blocks4_effective_bulk.md. For 32≤R≤ρ the sign
at k=0 is from big_blocks4_explicit_tail_18.md §4. At every
exact phase H=−kπ with k≥1, u>.35: strict phase monotonicity and
phase_small_threshold.py certify this even up to R=128.
For .35≤u≤1.3 and 32≤R≤128, the four tilted continuous rectangle
certificates phase_tilt_32_48_results.txt, phase_tilt_48_64_results.txt,
phase_tilt_64_96_results.txt, and phase_tilt_96_128_results.txt give the exact sign (−1)^k.
For 1.3≤u≤2.9 and 32≤R≤128, use the finished wide-angle
rectangles. For u>2.9 the theorem phase_high_angle_gaussian.md
applies, since p≥u.

For R∈[20,32], actual n≥27004 forces u>1.3, as proved in
outer_saddle_R20.md. The finished phase_R20_*_results.txt
cover these entire radius ranges and angles 1.3≤u≤2.9.
If u>2.9, use the separate high-angle part of
outer_saddle_R20.md. At R=20, both descriptions give the
same upper maximum and the same saddle: its radial value n
determines a uniquely on the positive branch. The compact interval
saddle certificate covers 1/20≤R≤20 for n≥27004, via
bulk_cutoff_window.py angular_certificate.json 20. The prior compact
proof and its continuation connect it to the analytic small
radius bridge at R=1/20. Those signs apply all the way to the
left anchor a_L in left_anchor_800.md (n≥27004 ensures m≥800
and the anchor itself has nR>75).

The continuous lifted phase starts H=0 at the cusp and ends
strictly below −(m−1)π at the left anchor. At the first distinct
successive points where it takes values −jπ (j=0,…,m−1),
the full coefficient integrals and therefore the real values
P_n(−a) have nonzero alternating signs. The intermediate value
theorem puts at least m−1 distinct negative roots strictly
between cusp and anchor. A further negative real root lies
strictly to the left of the anchor, by left_anchor_800.md.
These disjoint brackets exhaust degree m=floor(n/4), so all
roots are negative and simple. The small-n and very-large-n
proofs are separate, and leave other n outside this band open.
