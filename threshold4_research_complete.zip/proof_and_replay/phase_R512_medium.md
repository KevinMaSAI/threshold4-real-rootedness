# Medium-angle marker signs for all R≥512

Use the same saddle quantities, Gaussian normalization and (Q)
as in phase_R1024_gaussian.md. The following refined local half
widths and true tail estimates work on the full medium band
1/2≤p≤1.5. Throughout M≥1.49R.

## .5≤p≤.9

Take slope .5 to x0=1.3, but with local comparison half-width
h=.28p. On the full tilted hull |w|<1.4, Im w≥−.45,
the third derivative model error is <20/R:
|z/R−1|<1.403/R, |z−R−iw|<.983/R,
T3/R³ deviates by <7.3/R, exp(z−R) modulus <1.572
and its difference from exp(iw) <1.547/R, and the normalized
S contribution is <4.55/R. These bounds give the stated
error by summation. So the full L simplex error is 10/R.

For .5≤p≤.65, on the local hull |w|≤1.29p and
|Im w|≤.14p, the third derivative model error is <15/R
and fourth <17/R, by the same elementary estimates
applied with |w|≤.839, lower Im w≥−.091:
|z/R−1|<.84/R, |z−R−iw|<.353/R, normalized deviations
T3<5.55/R, T4<9.42/R, exponential modulus <1.097,
difference <.39/R, and the usual S terms.
As x is in [.72p,1.28p], use sin x≥.88x and exp(−y)≥.909.
From exp(.14p)≤1+.147p and Taylor lower sinc and upper cos,
the first Hessian model bracket is bounded below by
(.2592−1/6)p²−.0112p⁴−.147p>−.103p.
Then the real tilted curvature is >.41Mp, since the mean
identity gives local model error ≤1.25·15·2.29 Mp/R and
.909·.88·.72−.75·.103−1.25·15·2.29/512>.41.
The saddle tilted modulus <1.47Mp and both tilted
higher derivatives <1.77M by
1.25(1+.65/6+30/512)<1.47 and
1.25²(exp(.091)+17/512)<1.77.

For .65≤p≤.9 the local model derivative errors are
both <20/R on |w|≤1.29p≤1.161, Im w≥−.126.
Check |z/R−1|<1.163/R, |z−R−iw|<.676/R, T3<6.52/R,
T4<10.7/R, exponential modulus <1.137, difference <.77/R
and the S terms as before. Now use sin x≥.79x
on x≤1.152, exp(−y)≥.874 and exp(.14p)≤1+.15p.
The model bracket lower bound
(.2592−1/6)p²−.0112p⁴−.15p is >−.094p.
The real tilted curvature is >.31Mp by
.874·.79·.72−.75·.094−1.25·20·2.29/512>.31.
The saddle tilted modulus <1.54Mp and the higher derivatives
<1.84M follow from 1.25(1+.9/6+40/512)<1.54 and
1.25²(exp(.126)+20/512)<1.84.

For the exterior of the full line, use the L moments of
low_angle_R4096_complete.md with the improved simplex error 10/R.
On the right, x≤1.3, y≤.4, these give Re L>.325 if p≤.65
and Re L>.309 for p≤.9, with |Im L|<.237 in both cases.
On the left, x≤p, y≥−.5p, they give Re L>.445 and |Im L|<.171
for p≤.65; Re L>.412 and |Im L|<.256 for p≤.9.
For the right exterior x+p≥2.28p, so the usual attenuation
factor .5(Re L·11/12−|Im L|/2) multiplied by 2.28 yields
at least .20 and .17 respectively. The left attenuation
factor .5(Re L−|Im L|/4) also gives these bounds.
Thus a common quadratic loss on either exterior piece
at least α Mp(x−p)² holds with α=.20 or .17.
The same positivity implies the return vertical never exceeds
the real endpoint. The actual real loss there is >.02M
as in phase_R1024_gaussian.md: up to u≤1.3, −wχ'>.27u
(the adverse terms are <.001u and e^(X−R)>.998).
The vertical and first-circle tails contribute <.001 relative
to |G|, and the remote arc <.01.

The exact-check script margin_R512_check.py substitutes
v≥1.49·512·.5³ or 1.49·512·.65³, respectively, and uses
h=.28p. It gives local Q plus missing Gaussian plus actual
tilted exterior <.591 in the first band and <.382 in the second.
With both far tails the sums remain below 1/sqrt(2).

## .9≤p≤1.5

Use the centered truncated slope .4 but hold it for h=.25p.
The model Hessian error on the needed rectangle
x∈[0,1.875], |y|≤.15 is <35/R.
Use the proof in phase_R32768_tilt.md with
|w|<1.882, |z/R−1|<1.886/R, |z−R−iw|<1.775/R,
exponential modulus <1.167 and error <2.08/R.
The normalized T2,T3,T4 deviations remain below
5/R,9/R,14/R there; the S comparison is still bounded
by 11 before multiplying by χ, and the saddle normalization
compared with sinc p still has error <4/R.
For the normalized higher derivatives use the S bound <5/R,
so
  |Ω'''|, |Ω''''| ≤ M [exp(.15)+(14·1.167+2.08+5)/R].
After tilt, an upper bound 1.63M follows at R≥512.
Also |σ|<1.33 Mp, |σ d²|<1.54 Mp using
1+1.5/6+35/(.9·512)<1.33 and multiplying by 1.16.
Thus 1/|G|<.47 sqrt(Mp). The actual two end verticals
have the proper sign: in the calculation of phase_R32768_tilt.md,
the sine between saddle and endpoints is >.62
(since x between .675 and 1.875); the upper real Hessian
bound is 1.30, since sinc p≤sinc(.9)<.871,
cos(1.875)>−.300, and the model error is ≤35/512.
Then .62−35/512>.4·1.30, which ensures no vertical point
has larger real exponent than the real-circle endpoint.

The local saddle comparison uses three subranges:
- .9≤p≤1.1: the 15/R third derivative error on the local
  hull |w|≤1.26p≤1.386, |Im w|≤.11 follows from
  normalized T3 deviation <7.2/R, exponential modulus
  <1.119 and error <1.08/R, and normalized S <4.55/R.
  The mean-zero Hessian estimate gives error ≤1.16·15·2.26Mp/R.
  On x∈[.75p,1.25p], sin x≥.71x and exp(−y)≥.89.
  Since exp(.10p)≤1+.106p, the model bracket is bounded below
  by (.28125−1/6)p²−.01319p⁴−.106p>−.013p.
  Thus the tilted curvature is >.29Mp, using
  .8·.89·.71·.75−.84·.013−1.16·15·2.26/512>.29.
- 1.1≤p≤1.3: on the local hull |w|≤1.26p, Im w≥−.13,
  the third derivative model error is <20/R (use normalized
  T3 deviation <8.0/R, exponential modulus <1.144 and
  its deviation <1.55/R, normalized S <4.55/R).
  Now sin x≥.61x and exp(−y)≥.87. The same bracket lower bound
  with .108 in place of .106 is positive. So the mean-zero
  error gives tilted curvature >.21Mp by
  .8·.87·.61·.75−1.16·20·2.26/512>.21.
- 1.3≤p≤1.5: use sin x≥.5x, exp(−y)≥.85. With .11 in place
  of .106 the bracket lower bound is >.009p.
  The absolute Hessian model error 35/R gives
  tilted curvature >.20Mp, because
  .8·.85·.5·.75+.84·.009−1.16·35/(1.3·512)>.20.
In applying the first-bracket formulas, sin x / x decreases
on these real intervals, and the polynomial lower bound
after division by p is increasing on each respective subrange.
The exponential slope bounds follow by convexity and the
right endpoint on each p interval.

For the tails, use w in [1.5R,1.51R], du/dx≥.999 for
x≤1.9 and −wχ'>.20u up to u=1.9.
The latter follows as before from the sinc derivative
and exp(X−R)>.996, with adverse correction <.001u.
Hence the real loss is >.0215M(u²−u_p²)².
This gives >.004Mp⁴ at both horizontal endpoints
x=.75p and 1.25p, since
.0215·.999⁴·(.25·1.75)²>.004.
Starting at those endpoints, on the real near exterior pieces
[p/2,.75p] and [1.25p,1.9], the real loss increases outward
at slope >.018Mp³. For the left piece use
  |χ(u)−χ(u_p)|≥.20·.999²·(.4375p²)/(2·1.51R)
and u≥.999p/2, w≥1.5R, du/dx≥.999. On the right piece
use the larger corresponding endpoint difference.
On x≤p/2, the loss is >.011Mp⁴ by the same quadratic in u.
On the rest of the real first arc x≥1.9, the loss >.021M,
using the comparison at x=1.9 to p≤1.5.

For p≤1.1, stronger real loss is available at endpoints
and on their outgoing real pieces: replace −wχ'>.20u
by >.268u through u≤1.375, since sinc contributes
(1/3−1.375²/30)u and the adverse corrections are <.001u
and exp(X−R)>.998. Use w ratio 1.5/1.51 as already.
The integrated endpoint loss coefficient .033 in place of
.0215 gives >.0062Mp⁴, and the slope from those endpoints
is >.028Mp³ (use the same difference estimate with .268).
This slope need not use .268 beyond u=1.375: monotonicity
keeps the endpoint χ gap thereafter. For x≤p/2 use the
improved >.018Mp⁴ real loss.

Writing A for the endpoint exponent coefficient (.0062 or .004),
B for the outward slope coefficient (.028 or .018) and
C for the small-x exponent coefficient (.018 or .011),
the near exterior relative integral is
.94 exp(−A M p⁴)/(B sqrt(M) p^(5/2)).
The verticals total ≤.095 sqrt(v) exp(−A M p⁴) by their
combined .20p length, and x≤p/2 gives
.235 sqrt(v) exp(−C M p⁴).
The remaining first arc has error <.001 using length <4
and exp(−.021M); remote error <.01.
The near/vertical/left small-x bounds decrease from each
respective lower endpoint. Along with the local (Q) error
and directly integrated missing Gaussian at h=.25p,
the exact substitutions give totals for these five
contributions <.282, .229 and .129 respectively.
Adding .011 leaves strict positivity relative to |G|/sqrt(2).
This proves every medium-angle marker on R≥512.
