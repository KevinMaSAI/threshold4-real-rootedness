# 阈值 4 实根性：夜间研究检查点

**目前严格证明**：
- 0≤n≤3071：精确整数递推、Graeffe 比值与分离证书；
- 5173≤n≤3520607：对连续鞍点参数作的一致符号证明；
- n≥67,500,000：对整段无限尾部统一成立的证明。

在上述范围，非常数多项式的全部根均为互异负实根。尚无全阶
证明或原题反例。剩余两段为 [3072,5172] 与 [3520608,67499999]。

主要新结构：Airy 参考中的四次项可精确积分，并且与 Airy 主项
同号；在部分倾斜路径上，四次项还加强真实衰减。因此可以把
合并驻点附近的误差与参考相位精确对齐。它和改进的倾斜高斯
界把无限尾部下界从 350 亿降到 6750 万。对中段，新的实际
鞍点几何一直延伸到 R=10，再接紧半径区间和小半径解析桥，
把下界从 16376 降到 5173。另已严格证明 R≥192 的低角符号，
使剩余连续区间中的待证角度明显减少。这些判号不依靠浮点数
求根，也没逐阶检查数百万个 n。

主证明入口：
- full_tail_67_5m.md；
- phase_mid_band_192_lower10_joint.md；
- phase_R192_low.md（低角延伸，用于正在推进的中段）。

本检查点的关键复验命令：
    python3 finite_exception_range.py 1025 2048
    python3 finite_exception_large.py 2049 2559
    python3 finite_exception_large.py 2560 3071
    python3 bulk_cutoff_mixed_interval.py angular_certificate.json 10 1/4
    python3 phase_wide_R10_certificate.py --radius 10 12 --angle 49/20 14/5 --grid 12 24 --boxes 192 --max-depth 9
    python3 phase_wide_R12_certificate.py --radius 16 20 --angle 19/10 49/20 --grid 12 22 --boxes 144 --max-depth 9
    python3 margin_R10_check.py
    python3 middle_splice_R16_check.py
    python3 airy_quartic_R512_check.py
    python3 margin_R512_check.py
    python3 airy_quartic_R192_check.py
    python3 margin_R192_low_check.py

较长的实际命令耗时：有限三段分别 10m06.850s、8m25.231s、
16m14.902s；紧半径 R≤10 为 22.300s，新两段宽角为
44.852s 和 31.101s。一维 R192 精确求积为 2.153s。
多项操作并行，不能相加成为总研究耗时；没有总 token 或计费量凭据。
原题、文献来源和已有方法、先前证明与失败尝试见包内旧读我及研究稿。
没有联系原作者、公开发布、投稿或支付费用。
