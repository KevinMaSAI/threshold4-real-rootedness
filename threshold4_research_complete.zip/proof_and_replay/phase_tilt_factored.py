"""Directed half-integral with the two outgoing pieces estimated analytically.

Domain: 192 <= R <= 512 and .49 <= u <= 1.3 (or slightly wider
where the same analytic tail constants are independently proved).
"""
from argparse import ArgumentParser
from fractions import Fraction as F
from math import factorial, isqrt
from phase_wide_cell import (Q, ONE, ZERO, rat, quo, add, sub, mul, sq, neg, scale, exp, trig,
    geometry, cadd, csub, cmul, cscale, cdiv, pow_three_eighths, root)
from phase_rect_certificate import outer, grid, split
cs=[rat(1,factorial(j)) for j in range(25)]
err=[None]+[rat(2*j**(i+1),factorial(i+1))[1] for i,j in [(16,1),(18,2),(20,3),(24,4)]]
def K(z,small):
    # K(z) = (exp(z)-1-z)/z², continued by K(0)=1/2.
    size=sum(max(abs(t) for t in v) for v in z)
    assert size<=4*Q
    if small:
        assert size<=Q//4
        cap=11
        tail=rat(2,4**10*factorial(12))[1]
    else:
        k=(size+Q-1)//Q
        cap=16 if k<=1 else 18 if k<=2 else 20 if k<=3 else 24
        k=max(k,1)
        tail=rat(2*k**(cap-1),factorial(cap+1))[1]
    c=(ZERO,ZERO)
    for j in range(cap,1,-1):
        c=cadd(cmul(z,c),(cs[j],ZERO))
    return tuple((t[0]-tail,t[1]+tail) for t in c)

def normalized(C):
    R,z,p,a1,M,aE=C
    u=z[1]
    inv=quo(ONE,R); U=mul(inv,u)
    V=root(sub(ONE,sq(U))),U
    zi=(mul(inv,V[0]),neg(mul(inv,U)))
    cu,su=trig(u)
    f=add(quo(su,u),mul(cu,quo(inv,V[0])))
    wR=add(scale(inv,2),quo(add(rat(3,2),mul(sub(ONE,scale(sq(u),2)),sq(inv))),V[0]))
    F=cscale((cu,su),quo(wR,f))
    a1R=mul(a1,R)
    return inv,V,zi,F,a1R

def exponent(C,x,N=None,y=None):
    inv,V,zi,F,a1R=normalized(C) if N is None else N
    slope=rat(9,20)
    ih=(neg(mul(slope,x) if y is None else y),x)
    q=cscale(ih,inv)
    def qK(z):
        return K(z,sum(max(abs(t) for t in v) for v in z)<=Q//4)
    K1=qK(q)
    K2=qK(cscale(q,rat(2)))
    K3=qK(cscale(q,rat(3)))
    B=cadd((ONE,ZERO),cmul(q,K1))
    ihV=cmul(ih,V)
    zd=cmul(ihV,B)
    BBK=cmul(cmul(B,B),K(zd,False))
    a=cmul(zi,K1)
    small=cadd(cscale(a,inv),cadd(cscale(K2,scale(inv,2)),cscale(cmul(V,K3),rat(3,2))))
    big=cmul(F,cadd(BBK,a))
    return cscale(cmul(cmul(ihV,ihV),csub(small,big)),a1R)

def cover(C,n):
    R,z,p,a1,M,aE=C
    diff=(rat(3,5),p)
    slope=rat(9,20)
    N=normalized(C)
    def value(x):
        phase=exponent(C,x,N)
        c,s=trig(phase[1])
        return mul(exp(phase[0]),sub(c,mul(slope,s)))
    total=ZERO
    for j in range(n):
        t=rat(j,n)[0],rat(j+1,n)[1]
        total=add(total,add(mul(mul(p,rat(1,n)),value(mul(sub(t,ONE),p))),
                     mul(rat(3,5*n),value(mul(t,rat(3,5))))))
    near_loss=mul(rat(22,1000),M)[0]
    ub=exp((-min(80*Q,near_loss),)*2)[1]
    arc=add(rat(27,100),quo(ONE,mul(rat(99,1000),M)))
    near=mul((0,ub),arc)[1]
    far_loss=add(mul(R,rat(2,5)),quo(M,mul(rat(5),R)))[0]
    far=mul(scale(R,4),pow_three_eighths(far_loss//Q))[1]
    return total[0]-near-far

def main():
    p=ArgumentParser()
    p.add_argument('--radius',nargs=2,required=True)
    p.add_argument('--angle',nargs=2,default=['49/100','13/10'])
    p.add_argument('--grid',nargs=2,type=int,default=[32,60])
    p.add_argument('--boxes',type=int,default=100)
    p.add_argument('--max-depth',type=int,default=12)
    a=p.parse_args()
    A,U=outer(*a.radius),outer(*a.angle)
    assert 192*Q<=A[0]<A[1]<=512*Q
    assert rat(49,100)[0]<=U[0]<U[1]<=rat(13,10)[1]
    todo=[(R,V,0) for R in grid(A,a.grid[0]) for V in grid(U,a.grid[1])]
    total=0;least=None
    while todo:
        R,V,d=todo.pop()
        try: lo=cover(geometry(R,V),a.boxes)
        except AssertionError: lo=0
        if lo>0:
            total+=1;least=lo if least is None else min(least,lo)
            if total%512==0:
                print('accepted',total,'pending',len(todo),flush=True)
        elif d<a.max_depth:
            if F(R[1]-R[0],R[0])>=F(V[1]-V[0],2*Q):
                todo.extend((r,V,d+1) for r in split(R))
            else:
                todo.extend((R,u,d+1) for u in split(V))
        else:
            print('INCONCLUSIVE',R,V,d,lo,flush=True)
            raise ArithmeticError('refine remaining cell')
    print('VERIFIED factored tilted rectangle',a.radius,a.angle,'accepted',total,'least lower',least,'/',Q,flush=True)
if __name__=='__main__':main()
