# Outer saddle and usable large-angle signs for 14≤R≤20

Keep the notation and identities of outer_saddle_R20.md and
big_blocks4_effective_bulk.md. This proof extends their outer
geometry below R=20. It does not need low-angle sign estimates on
this additional strip: for n≥8921 such configurations are absent.

## Angular geometry and monotone radial value

For 0≤u≤π+.1, X≥.972R and exp(X−R)>.67; use u<3.25
and 1−v+v²/2−v³/6 at v=(3.25)²/(1.972·14).
The formula for w and its derivative gives
1.5R≤w≤1.65R and −3u/R≤w'≤0, using R≥14.
For u≤π, the adverse corrections to −(sinc u)' in
−w exp(R−X)χ' are bounded by u/X³+u/X²+
3(1+1/X)u/(1.5R²)<.017u, since the X' term is favorable
except when f is negative and then |f|≤1/X.
Thus −χ'>u/(32R) there from −(sinc u)'≥u/π²>.1u.
For π≤u≤π+.1 the leading sinc contribution is >.295
and the offending terms total less than .0375
(from .1/X+u/X³+(u/X+3u/(1.5R²))(.1/π+1/X)).
With .67(.295−.0375)/(1.65·3.25)>1/32 this proves the
same derivative lower bound. The derivative identity for U
then gives unique upper maxima and real loss at least
M(u²−u_p²)²/200 on the first expanded arc.

On the far arc the loss in Re S relative to u=π is >.45R.
When θ≤π/6 this follows by integrating u w from π to
π+.1. When θ≥π/6, split the half circle at π/2,
2π/3, 17π/24, 3π/4, and 5π/6. On the first and last segments
cos(3θ)≤0. On [π/2,2π/3], cos(2θ)≤−.5.
On [2π/3,17π/24], cos(2θ)≤cos(17π/12)<−.25.
On [17π/24,3π/4], cos(2θ)≤0 and cos(3θ)≤cos(17π/8)<.93.
On [3π/4,5π/6], cos(2θ)≤.5 and cos(3θ)≤√2/2<.71.
These bounds make the drop from θ=0 at least .625R².
The drop at u=π from θ=0 is <8.25R: exactly this drop is
R−X+u²+(R³−X³+3Xu²)/6. Use
(R³−X³)/u²=(R²+RX+X²)/(R+X)=R+X²/(R+X)≤(3/2)R
and X≤R. Its upper bound is 10/(1.972R)+10+7.5R<8.25R.
This leaves .625R²−8.25R>.45R. The exponential term has loss
at least M/(5R) relative to u=π, by the monotone envelope
and its drop between u=π and π+.1, greater than
(.67·π·.1/R)M>M/(5R). Thus total remote loss also exceeds
.45R+M/(5R). This establishes global first saddle isolation.

For the radial monotonicity, Y=X+R²−2u²+X(R²−4u²)/2
gives |Y'|≤4.81Ru (sum the three derivative bounds).
If d=u+arcsin(u/R)≤π/2, use ud'≥d and
d−sin d cos d≥8d³/(3π²), plus d³/sin²d≥d≥u. Then
−J'>.259Ru; |w'J|≤3u. Their ratio with w≥1.5R
shows strict increase of Y−wJ. If d≥π/2,
−J'>.95Ru/sin²d and |w'J|≤3πu/sin²d by the same formulas,
again dominating |Y'|. Hence N_R(a) increases strictly from
N(R) to infinity on the positive saddle branch.
The exact N(R) formula increases at R≥14: for the previously
defined E, 4E+R|E'|<1 follows from the separate monotonicity
of R^j exp(−R) for j≤3 and exp(14)>2^14.
The cusp for n≥8921 exceeds 20 and the saddle branch
continues to R=14, varying a strictly as before.

## Excluding small angles on the added strip

For u≤2.5 on this strip, f>.239−.81/(.972·14)>.179.
The bound uses decreasing sinc on [0,π] and cos(2.5)>−.81.
The positive saddle condition gives a/(1+a)<14 R exp(−R),
so a<.001. Subtract the rotated exponential in DF using
M exp(X−R)=(1+a)w/f directly. Bounding its absolute
radial contribution yields
n≤1.001(R+R²+R³/2+(1.65/.179)R²)<8921, evaluated
at R=20. Thus all relevant markers on the new strip have
u>2.5.

## Analytic high-angle signs

For p≥2.9, one has u_p≥.99p≥2.871. The inequality
f≤(π−u)/u−.95/R <.095−.95/R gives
M>1.5R²/(.095R−.95)≥600/.95>630, since that function
decreases up to R=20. The first expanded arc has x≤3.28
(check using the cubic lower sine at R=14). Because
π−u_p>arg z_p≥u_p/R, p+.2 is in the expanded arc.
For all x≥2.4 on the arc, the exponential angle
u+arg z+arg(z+1) is within .766 of π
(use u≥.99x, x≤3.28, R≥14). For |x−p|≤.2 it is within .57.
The S contribution to −Re Ω'' is nonnegative (3arg z<π/2).
Since exp(X−R)>.67 and |z²+z|/R²≥13/14,
these comparisons give real curvature >.43M on x≥2.4
and >.51M on the local segment. Globally for real x the
upper derivative moduli are 3M in order two and 2M in
orders three and four: use (1+a)/M≤1/R and the explicit
Touchard and S polynomials at R≥14.

Use the real segment h=.2 and formula (Q) with τ=.51M;
the relative local error is
sqrt(3/.51)[2/(8·.51²)+20/(24·.51³)]/M <.03.
The Gaussian and actual near tails, by directly integrating
their Gaussian bounds, are respectively
≤14 exp(−.0102M)/sqrt M <.002 and
≤17 exp(−.0086M)/sqrt M <.004.
At x≤2.4, the real loss is ≥.43(.5)²M/2,
so its tail relative to Gaussian is at most
1.7 sqrt M exp(−.05375M)<.001.
The remote arc relative error is at most
2.8 R exp(−.45R) sqrt M exp(−M/(5R))<.01:
bound R exp(−.45R) by its value at 14 and use that
sqrt M exp(−M/100) decreases for M≥630.
The total is below 1/sqrt(2), so signs hold on this sector.

## Exact wide-angle rectangle and its tail

It remains only 2.5≤u≤2.9. Use phase_wide_R14_certificate.py;
the new arcsin Taylor expansion sums 16 terms, with remaining
tail less than (1/4)^33/(1−1/16)<2^−58.
In otherwise unchanged integration, on u≥2.8 one has
−wχ'>.14: the leading −sinc derivative there exceeds .276
(using cos u<−.94, sin u≥−.1) and the other adverse
terms are in total <.042 (the possible negative X' term
only when f<0, |f|<.11; the w' term uses |f|<.199).
The factor exp(X−R)>.67 gives .14. Hence the integrated
real loss on u≥u_p≥2.8 is at least
(.14·1.5·2.8/(2·1.65))M(u−u_p)² > .178 M(u−u_p)².
Since du/dx≥.972 this is greater than .16M(x−p)².
These bounds justify the changed near-tail coefficient
and the far comparison at u=π. The older, weaker
tail bound applies without alteration when u_p≤2.8.
