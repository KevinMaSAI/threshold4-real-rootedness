# Complete remaining low-angle markers for R≥65536

This closes p∈[1/8,1/2] at unbounded R, complementing
airymarker_small_p.md and phase_R32768_tilt.md. Use the notation
of those proofs, with exact marker H=−kπ, Ω'(±p)=0.
Take b=1/2, d=1+ib, h=.35p, x0=.72. On the positive half use
the full slope-b line from x=0 to x=x0; then drop vertically
and return to the real arc. Its reflection gives the entire
contour, with no change to the coefficient integral.

## Local Gaussian estimate

On the relevant rectangle (within 0≤Re w≤1.8, |Im w|≤.12
for the *local* x=p±h), the model and derivative bounds of
phase_R32768_tilt.md apply, including
σ/M=sinc p−e^(iw)+error with |error|<30/R.
In the local subsegment x∈[.65p,1.35p], |y|≤.175p,
its tilted real Hessian is
.75(sinc p−e^(−y) cos x)+e^(−y) sin x, up to error 37.5/R.
Here e^(−y)≥.9125 and sin x≥.92x for x≤.675.
Also e^(−y)≤1+.184p by monotonicity of (e^v−1)/v
and evaluation at v=.0875; cos(.65p)>0 and
cos(.65p)≤1−.21125p²+.00744p⁴. Combining with
sinc p≥1−p²/6 gives the first bracket ≥−.184p.
Thus the true local curvature exceeds .4Mp:
.9125·.92·.65−.75·.184−(37.5/65536)/(1/8)>.4.
The transformed Hessian at p has modulus <1.4 Mp
by |sinc p−e^(ip)|≤p+p²/6 and |d²|=1.25.
Both transformed third and fourth derivative moduli
are <1.72M: here e^(−Im w)≤e^.0875 and the same
derivative approximation of the previous proof bounds
the error by 30/R, so \(|d|^4(e^{.0875}+30/R)<1.72\).
As before, the reference Gaussian G with line element d
equals sqrt(2π/σ(p)), since Re σ(p)>0 and Im σ(p)<0,
and its real part is ≥|G|/√2.

Use (Q) on the local subsegment with τ=.4 Mp and
S₂*=1.4Mp. The relative local error is <3/(Mp²)+19/(Mp³).
The missing Gaussian tail has relative bound
sqrt(7) exp(−.01225Mp³).

## Steep descent on the exterior of the tilted line

The exact factor \(\Omega'(w)=iM(w^2-p^2)L(w)\) is as in
airymarker_small_p.md. The simplex formula and approximation (4)
give \(L=L_0+O(25/R)\), where \(L_0\) is the simplex integral
of \(\exp(i(s w+t p-v p))\), \(s+t+v=1\), simplex volume 1/2.
The model comparison (4) is valid here by the same
50/R elementary estimate for |w|≤1.05;
all points on the vertical or oblique line portions
and their convex hull with ±p lie in that disc.
Symmetry between t and v replaces \(\exp(i(t-v)p)\)
by the positive \(\cos((t-v)p)\). In particular we can
bound |\Im L_0| by \(\exp(\max(0,-y))x/6\) there, since
\(\int s\,ds\,dt=1/6\) and \(|\sin(sx)|\le s x\),

For x≥p, 0≤y≤b(x-p), Re L>.26 from
.5 e^(−.36) cos(.72)−25/R>.26 and |\Im L|<.121
from x≤.72. Therefore the real loss along that vertical
segment is at least
\[
 M b(x-p)(x^2-p^2)\,[.26(1-b^2/3)-.121 b]
 >.085 M(x-p)^2(x+p)
\]
at its top. Indeed, integrate the real part of
\((x^2-p^2-y^2+2ixy)L\), using \(xy\le b(x^2-p^2)\)
at its endpoint, and average the quadratic \(y^2\) and
linear \(y\) terms. At any intermediate y≥0 it also
never exceeds the real-circle point by the same argument
with slope no greater than b. For x<p, y∈[b(x-p),0],
Re L>.43 from cos(.5)/2−25/R>.43 and
|\Im L|<.108 from \(e^{.25}.5/6+25/R<.108\).
Integrate in the reversed direction; the \(-y^2\) term
helps, so the loss is at least
\(M b(p-x)(p^2-x^2)(.43-.108b)>.18M(x-p)^2(x+p)\).
These are additional to the nonnegative real-circle
loss of the maximal saddle.

For x outside the local interval on the full tilted
line, use x+p≥p to its left and x+p≥2p to its right.
Together these give exterior loss at least
\(.17 M p (x-p)^2\), and the relative integral of that exterior
is < \(8 \exp(-.020825Mp^3)/\sqrt{Mp^3}\)
by the Gaussian tail estimate and
\(|d|\sqrt{|\sigma(p)|/(2\pi)}<.47\sqrt{Mp}\).
At x=x0 the entire vertical return has loss at least the
real-circle loss there, which exceeds .0003 M by the
old angular bound (2) and \(u(x_0)>.99(.72), u_p≤.5\).
The remaining first arc has that loss by monotonicity,
and together with the vertical has length <5.
The remote arc uses loss >.4R+M/(5R), exactly as in
the other high-radius proof.

## Final margins

For R≥65536, w≥1.5R and f≤1+1/(.99R) give M≥1.4R,
hence Mp³≥179.2. The local Q error above is <.12
(3/(Mp²)≤1.5/(Mp³)), the omitted Gaussian tail is
<.31, and the full tilted exterior error is <.016.
Vertical return and first-circle tail are
at most \(5\sqrt M e^{-.0003M}<.01\), the remote
bound is also <.01 using optimization in M at fixed R.
All these bounds follow by monotonicity and lower
endpoint substitution. Their sum is <.47<1/√2.
Thus at H=−kπ the exact sign is (−1)^k. This proof
uses no finite sampling of k, p, R, or n.
