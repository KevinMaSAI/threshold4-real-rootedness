"""One-dimensional directed rational bounds for the eight low phase indices."""
from angular_certificate import Q, ONE, ZERO, add, sub, mul, sq, scale, exp, point
from phase_k_certificate import PI, rat, quo, root

def coarse_exp_negative(x):
    # Valid upper bound for exp(-x), including x outside exp's Taylor domain.
    return exp(point(-min(x,80*Q)))[1]

ps=[190,240,274,302,325,346,364,380]
M=mul(rat(149,100),point(1024*Q))
c=mul(rat(451,1000),M)
for k, pp in enumerate(ps,1):
    p=rat(pp,1000)
    v=mul(PI,rat(3*k,2))
    assert mul(c,mul(p,sq(p)))[0]>v[1]
    integral=0
    Y=0
    for j in range(6*512):
        X=rat(j,512)[0],rat(j+1,512)[1]
        Y=mul(sq(sub(X,ONE)),add(X,ONE))
        Z=mul(Y,add(X,ONE))
        main=mul(rat(198,1000),mul(v,mul(p,Z)))
        rem=mul(rat(40,1000),mul(v,mul(sq(p),mul(add(mul(rat(23,20),X),rat(91,20)),Z))))
        bound=add(rem,mul(rat(1,2),sq(main)))[1]
        loss=mul(rat(26,100),mul(v,Y))[0]
        integral+=mul(rat(1,512),mul((0,bound),(0,coarse_exp_negative(loss))))[1]
    # For x>=6, Y>=25 x^3/36, Z<=2 x^4 and 23x/20+91/20<=2x.
    # Using v<38 and p<=.38, prefactor <100 x^8. Loss > .84 x^3.
    # x^8 exp(-.42 x^3) <= 6/(.42^3*x)<14; then integrate
    # exp(-.42*x^3) <= exp(-.42*36*x): tail < 10^-6.
    integral+=rat(1,1000000)[1]
    relative=mul(quo(mul(rat(23,10),root(v)),mul(PI,rat(2,3))),(0,integral))[1]
    assert 4*relative<3*Q
    print('VERIFIED k',k,'p <',pp,'/1000; relative error <',relative,'/',Q)
