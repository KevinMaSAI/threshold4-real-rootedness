# Extending the middle band to 5173≤n≤3520607

The higher-radius portion is the same as in
phase_mid_band_192_lower12_joint.md, down through R=20.
For every n≥5173 the cusp still lies above R=20.
The capped derivative and radial-continuation proofs on
[12,20] remain valid, but their older exclusion of
u≤2.45 is not sufficient for the lower cutoff.
Use this extra angular region instead:

For R≤16 and u≤2.45 the general bound in outer_saddle_R12.md
gives n≤1.001(16+16²+16³/2+(1.68/.192)16²)<5173.
For any R∈[12,20] and u≤1.9, one has
f>.498−.33/(.962·12)>.469, θ<.16
(use sin .16>1.9/12), and −cos(u+θ)<.472.
Since the old a<.001 still applies for u≤2.45,
the exact radial formula bounds
n≤1.001(20+20²+20³/2+(1.68·.472/.469)20²)<5173.
So it suffices to cover the extra continuous region
16≤R≤20, 1.9≤u≤2.45. The exact code and proof are
the same as in the R12 widened-angle certificate.

The interval 10≤R≤12 is covered by outer_saddle_R10.md
and the exact 288-cell wide-angle certificate.
The remaining compact interval [1/4,10] has cut-off
n≥5173, by 333 validated cells of
bulk_cutoff_mixed_interval.py with angular_certificate.json.
For smaller radii the previous quarter bridge and left
anchor give all signs unchanged. The joins agree by the
actual unique global upper maxima and radial monotonicity.
The same exact successive markers and far-left bracket
exhaust the degree and imply simple negative roots.

The extra R16–20 rectangle is certified in
phase_wide_R16_extra_results.txt: 264 cells and exact
normalized lower integral at least 36882264148432119/2^58.
This completes the splice without using the older, larger
cutoff in the smaller-angle exclusion.
