# Tilted marker signs for R≥32768, .5≤p≤1.5

This is an analytic result on an unbounded radius set, a complement
to the results for p≤1/8 and p≥1.5. Use the notation of the original
two-saddle proof, in particular \(\sigma(w)=-\Omega''(w)\).
Take \(b=2/5\), \(d=1+ib\), \(h=p/5\). Replace just
\([p-h,p+h]\) on the positive real half by \(p+d[-h,h]\) with
vertical connections at its two ends, and reflect the contour.
This is legal for the entire integrand.

## Hessian and derivative sizes

On the rectangular neighborhood \(0\le\Re w\le 1.8\),
\(|\Im w|\le.12\) we have
\[
 \left|\frac{\sigma(w)}M-\big(\operatorname{sinc}p-e^{iw}\big)\right|
   <30/R <.0015,\qquad
 \max(|\Omega'''(w)|,|\Omega''''(w)|)<1.14M.
\]
For a check, write \(v=z/R=e^{iw/R}\).
Here \(|w|<1.82,\ |v-1|<1.9/R,\ |z-R-iw|<1.7/R\), and
\(|e^{z-R}-e^{iw}|<2/R\).
The normalized \(T_j(z)/R^j\) differ from 1 by less than
\(5/R,9/R,14/R\) for \(j=2,3,4\) respectively, by their explicit
polynomials. Also \(|D^2S/R^2-(3/2)R|<11\), using
\(D^2S/R^2=(3/2)R e^{3iw/R}+2 e^{2iw/R}+R^{-1}e^{iw/R}\).
At the original saddle, \(\chi=(1+a)/M\le1/R\), and
\((3/2)R\chi=e^{X_p-R} f(u_p)(1.5R/w(u_p))\) differs from
\(\operatorname{sinc}p\) by \(<4/R\): both factors other than f
differ from 1 by at most 1.2/R and 1.4/R, and f differs from
sinc p by <1.2/R using \(|\operatorname{sinc}'|\le1/2\).
Thus the S error plus exponential error is <30/R.
The third/fourth bounds follow from \(|e^{iw}|\le e^{.12}\),
the same T estimates, and the explicit S derivative sizes
(each normalized S term is <5/R for this purpose).

At the tilted contour \(w=x+iy=p+d v\), \(|v|\le h\), the
real Hessian of the model, multiplied by \(d^2\), is
\[
.84(\operatorname{sinc}p-e^{-y}\cos x)+.8 e^{-y}\sin x.
\]
Here \(x\in[.8p,1.2p]\), \(|y|\le.08p\), \(e^{-y}\ge.88\),
\(\sin x\ge.54x\) (sinc decreases up to 1.8 and
\(\sin(1.8)>.972\)), \(e^{-y}\le1+.086p\).
Using \(\operatorname{sinc}p\ge1-p^2/6\) and
\(\cos(.8p)\le1-.32p^2+.0171p^4\), the first difference is at
least \(.1533p^2-.0171p^4-.086p\), since \(\cos(.8p)>0\).
This is greater than \(-.029p\) on .5≤p≤1.5. Therefore,
even after the model error, \(\Re[\sigma(w)d^2]>.27 Mp\).
At the saddle \(|\sigma(p)d^2|<1.5Mp\), since
\(|\operatorname{sinc}p-e^{ip}|\le p+p^2/6\).
Also \(\Re\sigma(p)>0\) (strict geometric real maximum)
and \(\Im\sigma(p)<0\) by the model. The cut tilted
derivatives of order 3 and 4 have moduli <1.55 M
after the powers of \(d\) are included. The entire Gaussian
integral with the line element \(d\) is \(G=\sqrt{2\pi/\sigma(p)}\):
the principal square root may be continued from slope 0,
because \(\Re[\sigma(p)(1+i\beta)^2]>0\)
for \(0\le\beta\le b\). Its real part is at least
\(|G|/\sqrt2\).

## Tails of the deformed integral

On either vertical connection at real \(x=p\pm h\),
\[
 \Im \Omega'(x+iy)/M
  =\int_p^x [-\Im(\sigma(t)/M)]\,dt
    -\int_0^y \Re(\sigma(x+iv)/M)\,dv.
\]
If \(p\le.8\), the main integrand \(\sin t\) is >.38
between \(p\) and either endpoint, and the real Hessian
on the vertical segments is bounded above by .51
(\(x\le.96,\ \cos x>.57,\ e^{-v}\ge.88\)).
If \(p\ge.8\), the main integrand is >.59
(\(.64\le t\le1.8\)) and the real Hessian is bounded above
by 1.28. These upper bounds, multiplied by \(b=.4\), are
strictly smaller than the respective sine bounds minus
.0015. Hence the sign of \(\Im\Omega'\) is the sign
of \(x-p\) on the corresponding vertical connection:
its real value never exceeds the value at its real end.

For \(u=R\sin(x/R)\le1.8\), the sinc derivative and small
\(1/R\) corrections give \(-w\chi'(u)>.21u\), using
\(-(\mathrm{sinc}\,u)'\ge(1/3-u^2/30)u\),
adverse remaining terms \(<.001u\), and \(e^{X-R}>.99\).
Integrating as in the real-angle proof, with
\(w(u)/w(v)\ge1.4/1.6\), yields real loss
\(\ge .022M(u^2-u_p^2)^2\). In particular on
\(p/2\le x\le1.8\) the loss is at least
\(.047Mp^2(x-p)^2\), because \(du/dx\ge.99\) and
\(u+u_p\ge.99(x+p)\). Both vertical pieces can use the
real loss at \(|x-p|=h\), namely \(.00188Mp^4\).
For \(x<p/2\), the loss at \(p/2\) and monotonicity give
at least \(.01 M p^4\); from \(x=1.8\) to end of the first arc,
at least \(.021M\), since \((.99\cdot1.8)^2-p_u^2 \ge .925\)
and using the sharper \(u(1.8)\ge .999\cdot1.8\)
from \(R\ge32768\) gives difference \(>.98\).
The first-arc total length is <4. On the remote arc
use the loss \(>.4R+M/(5R)\) relative to \(u=\pi\),
hence also to \(p\); its length is <4R.

For ratios to \(|G|\) use
\(|\sigma(p)|<1.3Mp\), so its reciprocal modulus is
\(<.46\sqrt{Mp}\). The first-arc exterior near piece
is ≤\(49e^{-.00188Mp^4}/(\sqrt M p^{5/2})\) by integrating
a Gaussian tail. The two vertical pieces have relative
sum ≤\(.075\sqrt{Mp^3} e^{-.00188Mp^4}\)
by their combined length \(.16p\).
The other first-arc parts are bounded by
\(8\sqrt M [e^{-.01Mp^4}+e^{-.021M}]\).
The remote bound is <.01 using
\(\sqrt{M}e^{-M/(5R)}\le\sqrt{5R/2}\) and \(R\ge32768\).

## Gaussian comparison

Use the symmetric estimate (Q) with \(\tau=.27Mp\),
\(S_2^*=1.5Mp\), \(M_3=M_4=1.55M\). Relative error
is \(<7/(Mp^2)+61/(Mp^3)\). The missing reference tail
has relative bound \(\sqrt{3/.27}\,e^{-.0027Mp^3}\).
At \(M\ge R\ge32768,\ p\ge.5\), all listed bounds decrease
in M and p when a p appears, except harmless factors already
bounded by monotonicity of \(\sqrt v e^{-v}\) above \(v=1/2\).
The local error is <.02, reference tail <.001,
first-arc near tail <.04, vertical pieces <.12, the other
first-arc pieces <.01, and remote <.01; these follow by
substitution of the lower endpoints (and \(e>8/3\) or a
short positive Taylor sum). Their sum is <.21<1/\sqrt2.
Thus at every exact marker \(H=-k\pi\) the normalized real
half integral is positive, proving the requisite sign.
