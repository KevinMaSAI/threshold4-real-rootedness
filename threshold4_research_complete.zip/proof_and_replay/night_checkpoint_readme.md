# 阈值 4 实根性：睡前研究存档

原题：P_n(t) 计数 [n] 的全部集合划分，仅大小至少 4 的块乘 t，
1、2、3 元块仍可出现、权重均为 1。原始来源：
https://mathoverflow.net/questions/462360/set-partitions-with-big-blocks-real-rooted-polynomials
https://www.symmetricfunctions.com/realRootedOpenProblems.htm#set-partitions-and-trees
https://github.com/PerAlexandersson/RealRooted/issues/1773
https://github.com/1337isnot1337/solved-conjectures/issues/158

本存档新增：
- homotopy_critical_edge.md 与配套两份误差稿：某个插值极端窗口无根碰撞；
  这个结果不覆盖原题的全部根或全部 n。
- phase_high_angle_gaussian.md：移动鞍点法在所有 R≥32、p≥2.5
  的相位标记点给出交替符号，不再额外要求 M≥10⁶。
- phase_wide_*_results.txt：精确算术验证连续矩形 [32,128]×[1.3,2.9]
  上、指定归一化的半积分严格为正；于精确相位点推出原积分符号。
- left_anchor_800.md：原题最大模端只需每阶控制一个根。m=floor(n/4)
  从 800 起证明该根与相位的严格衔接；旧四根版本需 m≥8192。
- outer_saddle_R20.md：将外部驻点的几何证明从半径 32 降到 20；
  未证明单凭它就覆盖中等阶数。
- phase_mid_band_candidate.md：条件性拼接，明确不视为已完成区间。
- downward_derivative_obstruction.md：指出不能仅对大阶多项式取导数
  就推断原题低阶实根性；并非原题反例。
- fast_initial_ratios.py 和 graeffe_fast.py：精确 Graeffe 初比值加速，
  用于今后实际可达的有限区间；没有用扩大有限搜索替代统一论证。

复验示例（Python 3，纯整数/Fraction，不用浮点定符号）：
    python3 phase_small_threshold.py
    python3 phase_k_certificate.py --phase 9 --lo 32 --hi 128 --pieces 384 --boxes 96
    python3 phase_wide_certificate.py --radius 32 36 --grid 8 80 --boxes 96
    python3 bulk_cutoff_window.py angular_certificate.json 20
    python3 left_first_cutoff_800.py
    python3 fast_initial_ratios.py

算时：k=9…12 的独立连续证书约每项 47–48 秒（并行运行），
连续大角带的 5 段分别约 40 秒、2 分 44 秒、3 分 39 秒、
7 分 41 秒、7 分 36 秒（分段并行，勿相加作总历时）。
本轮从北京时间约 22:58 到 23:26，含证明推导、反向检查、并行计算。
具体命令的时间保存在各结果文件；工具未返回总 token/计费量。
未联系作者、发帖、投稿或支付费用。目前没有原题全解或反例。
