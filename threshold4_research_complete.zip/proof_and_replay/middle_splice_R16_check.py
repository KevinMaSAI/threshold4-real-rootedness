"""Check the angle exclusions that permit the lower n cutoff 5173."""
from fractions import Fraction as F
from phase_k_certificate import rat,quo
from angular_certificate import trig
def b(s):
    z=F(s)
    return rat(z.numerator,z.denominator)
assert quo(trig(b('1.9'))[1],b('1.9'))[0]>b('.498')[1]
assert trig(b('1.9'))[0][0]>b('-.33')[1]
assert F('.498')-F('.33')/(F('.962')*12)>F('.469')
assert trig(b('.16'))[1][0]>b(F('1.9')/12)[1]
assert trig(b('2.06'))[0][0]>b('-.472')[1]
assert F('1.001')*(20+20**2+F(20**3,2)+F('1.68')*F('.472')/F('.469')*20**2)<5173
assert F('1.001')*(16+16**2+F(16**3,2)+F('1.68')/F('.192')*16**2)<5173
print('VERIFIED R16–20 joining angle exclusions n≥5173')
