# Low-angle sector: every k≥8 marker already works for R≥4096

For \(R\ge4096,\quad 1/8\le p\le 1/2,\quad H=-k\pi,\quad k\ge8\),
the exact necessary alternating sign holds. This removes all large-k
markers in this region even below the all-angle threshold R=24576.
The residual bounded-k markers are not covered by this result.

The core improvement is to compare the *actual* Hessian with its
model using zero mean between the two stationary points. On the
convex hull of the tilted path from phase_R65536_lowtilt.md and ±p
we have |w|≤.81 and |Im w|≤.36. The model derivative estimates from
(4) can be sharpened here to
\[
 |\Omega'''/(iM)-e^{iw}|,\quad
 |\Omega''''/M+e^{iw}| < 15/R .
\]
Indeed \(|z/R-1|<.82/R\), \(|z-R-iw|<.34/R\).
The normalized T3 and T4 differ by <5.5/R and <9.4/R,
and \(|e^{z-R}|<1.435\), \(|e^{z-R}-e^{iw}|<.49/R\).
The corresponding S terms divided by M are <4.52/R and <14/R².
This gives the claimed two estimates via the triangle inequality.

Let \(E(w)=\sigma(w)/M-\operatorname{sinc}(p)+e^{iw}\).
Then |E'|<15/R. Exactly ∫_(−p)^p E(x) dx=0, since Ω'(±p)=0
and sinc(p) is the mean of exp(ix) on this interval.
Consequently
\[
 |E(w)| \le (15/R)(|w|+p).
\]
For the local tilted interval |w|≤1.4p the error is
<36p/R, so when multiplied by d² its error is ≤45p/R.
This is much sharper at small p than the original absolute
Hessian approximation. With all the same estimates from
phase_R24576_improvement.md (especially sin x≥.925x and the
first bracket ≥−.1787p), the tilted real curvature still
exceeds .4 Mp: .9125·.925·.65−.75·.1787−45/4096>.4.
Also |σ(p)d²|<1.4Mp and the derivatives after tilting
are still <1.72M (including the |d|^4 factor).

For the exterior on the tilted line, the new error in L
relative to its simplex model is at most 7.5/R.
This allows Re L>.26 (right), Re L>.43 (left),
and upper |Im L| of .122 and .109 respectively, just as in
the improvement note: substitute the worst R=4096 into
.5 exp(−.36) cos(.72)−7.5/R,
cos(.5)/2−7.5/R, .72/6+7.5/R, exp(.25)·.5/6+7.5/R.
So the bound for the tilted exterior is as before.
For the vertical return and the first real arc, the sinc
estimate \(-w\chi'>.30u\) holds up to u=.72 at R≥4096,
as in the preceding small-angle proofs. At cutoff u>.99·.72
and u_p≤.5, integrate twice with w ratio ≥1.4/1.6 to get
loss greater than
\((.30\cdot1.4/(8\cdot1.6))M[((.99\cdot.72)^2-.5^2)]^2>.0021M\).
The entire vertical return is below its real end, and real
loss does not diminish on the rest of the first arc. Relative
tail from this part is therefore <5√M exp(−.0021M) <.01,
since M≥1.49R>6100. The remote part is <.01 as before.

Finally the exact c/M phase relation used in the Airy proof
and the bound \(|L|\le1/2+7.5/R\) on the real [-p,p]
show c/M<.502. As cp³=(3π/2)k, this gives
\(M p^3\ge(3\pi/2)k/.502>72\) for k≥8.
All three other relative errors in phase_R24576_improvement.md
are functions of v=Mp³, bounded by
\(20.5/v,\ 6.8 e^{-.0245v}/\sqrt v,\ 8 e^{-.020825v}/\sqrt v\);
their sum plus these two .01 tails is <.66 (check at v=72).
This is below the normalized real Gaussian amplitude bound
1/√2. Hence the sign follows at every such exact marker.
