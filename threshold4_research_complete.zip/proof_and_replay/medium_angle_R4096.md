# Medium-angle sign coverage down to R=4096

We prove all exact marker signs when R≥4096 and .5≤p≤1.5.
Use the definitions and already-verified contour and Gaussian
lemmas from phase_R32768_tilt.md, phase_R65536_lowtilt.md and
low_angle_R4096_complete.md. The real-angle geometry is unchanged.
Throughout M≥1.49R>6100.

## .5≤p≤.9

Take the focused slope b=.5, d=1+ib, h=.35p, and follow
the full tilted line to x0=1.3, then return vertically.
The entire hull with ±p lies in |w|≤1.4, with Im w≥−.45.
The elementary model estimates used for (4) here are
\[
 |\Omega'''/(iM)-e^{iw}|,\ |\Omega''''/M+e^{iw}|<50/R.
\]
For verification, |z/R−1|<1.401/R, |z−R−iw|<.981/R,
the normalized T3 and T4 differ from 1 by <7.22/R,11.63/R,
the exponential has modulus <1.57 there and its error
from e^(iw) is <1.55/R, and the normalized S contribution
is at most 4.52/R in order three and 14/R² in order four.
These bounds follow by expanding the explicit polynomials
using R≥4096; even their termwise triangle sum is <50/R.
As in the preceding low-angle proof, the stationary mean
identity implies |σ/M−sinc p+e^(iw)|≤(50/R)(|w|+p).

In the local interval x∈[.65p,1.35p], |y|≤.175p,
we have e^(−y)≥.8425, e^(−y)≤1+.191p, and sin x≥.77x
because x≤1.215. As in the earlier proof,
sinc(p)−e^(−y)cos x ≥ (.21125−1/6)p²−.00744p⁴−.191p
>−.172p. Thus the model tilted Hessian exceeds
(.8425·.77·.65−.75·.172)Mp, and the error after tilting
is ≤150 M p/R since |w|≤1.4p. Actual local real
curvature is >.25Mp. The stationary tilted Hessian
has modulus <1.5Mp (use p+p²/6 and the improved mean
error at w=p). The norms of the tilted third and fourth
derivatives are <1.9M, since
1.5625(e^.1575+50/4096)<1.9.
The argument of σ at p lies in the correct right half
with negative imaginary part (true real curvature and
the negative model imaginary sine), so the full
tilted Gaussian real part is ≥|G|/√2 exactly as before.

For the exterior of the line use the improved L moment
bounds from low_angle_R4096_complete.md, but with simplex
model error 25/R. For x≥p, x≤1.3 and y≤.4, these give
Re L>.32 and |Im L|<.223 by
.5−.4/6−(1.3²+.9²)/24−25/R>.32
and 1.3/6+25/R<.223. The right attenuation factor is
.5[.32(11/12)−.223/2]>.09, and therefore right exterior
loss ≥.18Mp(x−p)². On the left, y≥−.45, x≤p≤.9, the
same estimates give Re L>.426 and |Im L|<.243.
Including x/(x+p)≤.5 as before gives attenuation
.5(.426−.243/4)>.18. Thus the same lower Gaussian
loss applies to both exterior portions. These
vertical estimates also show the final vertical return
never exceeds the real level at x0. Beyond x0 the real
circle gap from the old /200 bound is >.0035M, since
u(x0)>.99(1.3) and u_p≤.9. The first arc remains
decreasing afterwards. The remote arc uses the common
improved loss >.4R+M/(5R).

At v=Mp³>6100/8=762.5 the local Q error is at most
(10p+120)/v (<.17). Indeed use τ=.25Mp, S₂*=1.5Mp and
M₃,M₄≤1.9M in (Q). The missing reference Gaussian tail
has directly integrated bound
12 exp(−.0153125v)/sqrt(v)<.01.
The actual tilted exterior has bound
8 exp(−.02205v)/sqrt(v)<.01,
using its just-proved Gaussian loss, total tail length
integration and |d|√(|σ(p)|/(2π))<.5√(Mp).
The true return and exterior first arc, with length <5,
give <5√M exp(−.0035M)<.01. The remote contribution
gives <.01 by optimizing sqrt(M) exp(−M/(5R))
as before. All monotone estimates at the lower endpoints
supply total error <.21, far below 1/√2.

## .9≤p≤1.5

Use directly the centered truncated slope .4 of
phase_R32768_tilt.md with no change to its contour.
The Hessian and derivative model bounds there at
R≥4096 still give Hessian error <30/R<.0074 and
derivative moduli <1.14M. This follows verbatim from
the elementary v=z/R bounds there, with the worst R
now 4096. On .9≤p≤1.5 its model lower term
.1533p²−.0171p⁴−.086p is nonnegative (the expression
after dividing by p is increasing in this interval).
So the real tilted curvature bound .27Mp still
holds after the model error |d²|·.0074: use the sine
contribution .8·.88·.54·.8p and p≥.9.
The upper Hessian <1.5Mp and tilted derivatives <1.55M
likewise follow with this model error (check the same
constants). Its vertical-end monotonicity still holds,
since the relevant sine lower bound is .59 and the
Hessian upper bound 1.28 remains valid; subtracting .0074
from .59 still leaves more than .4·1.28.
The real-circle-angle calculations used there remain
valid at R≥4096: .21u decay of −wχ' on u≤1.8,
and u(1.8)>.999(1.8). The actual relative error
formulas from that proof hold unchanged. Substitute
M≥6100 and p≥.9 in place of 32768 and .5. Then
the local error <.02, reference tail <.001,
first-arc near tail <.01, vertical pieces <.01,
the other first-arc pieces <.01, and remote <.01.
All are decreasing from these endpoints.
Total error <.061. Thus all exact signs follow here too.

Together these sectors close .5≤p≤1.5 at R≥4096.
