# Gaussian marker signs for all R≥1024 in the remaining sectors

Retain the exact geometry and normalization of
phase_R2048_gaussian.md. Throughout M≥1.49R. The analysis uses
the symmetric local error formula (Q), stated in the earlier proof,
and compares each error to the Gaussian modulus. The Gaussian real
part is always at least modulus/sqrt(2), by the same argument.

## 1/8≤p≤.5, k≥9

Use the existing low-angle central slope b=.5 with h=.35p,
but extend the end of the tilted line from .72 to x0=.82.
On the central domain the same 15/R derivative and mean-zero
Hessian estimates hold at R≥1024; check the same polynomial
bounds as in phase_R1024_quartic.md. The actual local curvature
is >.37 Mp because .9125·.925·.65−.75·.1787−45/1024>.37.
The saddle tilted Hessian remains <1.4Mp, and after multiplying
by the tilt factors the third/fourth derivatives are <1.74M.
Use 1.25(1+.5/6+30/1024)<1.4 and
1.25²(exp(.0875)+15/1024)<1.74.

The complete larger slope hull has |w|<.92 and |Im w|≤.41.
For the third derivative, the same direct polynomial estimate
gives model error <18/R and L simplex error 9/R:
|z/R−1|<.922/R, |z−R−iw|<.425/R, T3/R³ deviates by
<5.8/R, |exp(z−R)|<1.51, and the exponential difference
is <.65/R, while the S part is <4.52/R.
The simplex moment bounds now give Re L>.384 and |Im L|<.146
on the right, and Re L>.470 and |Im L|<.116 on the left.
Use x≤.82, y≤.41 on the right and x≤.5, −y≤.25 on the left.
Hence the right attenuation coefficient is
.5(.384·11/12−.146/2)>.139 and the left is
.5(.470−.116/4)>.22. Doubling the first for x+p≥2p
gives common loss .22Mp(x−p)² on the tilted exterior.

Since −wχ'>.30u up to .82, the real loss at the cutoff is
>.0054M by (.30·1.4/(8·1.6))[(.99·.82)²−.5²]²>.0054.
The same derivative argument as in R2048 now gives
a vertical loss slope >.059M (use
[(1−.25)·.384−.146](.82²−.5²)>.059)
and a real loss slope >.04M from cutoff to end of the first arc
(use u>.81, du/dx>.99, w≥1.4R).
Combined outgoing contribution
2(1/.059+1/.04) exp(−.0054M)/sqrt(M) is <.001.
The remote arc still contributes <.01.

On the real saddle segment c/M<.508 from the 15/R model.
Thus v=Mp³≥(3π/2)9/.508>83.4; local Q and the two Gaussian
tails give respectively <.310, <.122, <.072, using the tail
formulas of phase_R2048_gaussian.md with the above constants.
All errors sum to less than .515<1/sqrt(2).

## .5≤p≤.9, all markers

Retain the full slope .5 to x0=1.3. The moderate-region
derivative error <50/R for Ω''' in medium_angle_R4096.md
follows by the same termwise check at R≥1024:
use |z/R−1|<1.401/R, |z−R−iw|<.983/R, T3 and T4
deviation bounds 7.3/R and 11.7/R, exponential modulus
<1.58 and difference <1.57/R and the same S terms.
Use this coarse estimate for the full contour only.

On the local hull |w|≤1.4p≤1.26, |Im w|≤.1575, the
derivative errors for Ω''', Ω'''' are <20/R:
|z/R−1|<1.262/R, |z−R−iw|<.796/R,
|exp(z−R)|<1.172, and deviation from exp(iw) <.933/R;
T3 and T4 deviations <6.85/R and 11.1/R suffice
with S terms <4.53/R and 14/R². For Ω''' and its use in
the mean-zero Hessian identity one uses precisely that
local hull with ±p included (convex). For .5≤p≤.65
one can use error <15/R for Ω''' on |w|≤.91,
|Im w|≤.114: the normalized T3 deviation <5.75/R,
the exponential modulus <1.122 and its deviation <.467/R,
and the S contribution is <4.53/R.
For all .5≤p≤.9 the tilted stationary Hessian is <1.5Mp
by 1.25(1+.9/6+40/1024)<1.5; both higher tilted
derivatives still have bound 1.9M.

For .5≤p≤.65, on the local line sin x≥.87x and
exp(−y)≥.88625 because |y|≤.175p.
Since exp(.175p)≤1+.186p throughout this interval,
the first model bracket sinc p−exp(−y)cos x is bounded
below by (.21125−1/6)p²−.00744p⁴−.186p>−.166p.
The same mean-zero estimate gives real curvature >.33Mp:
.88625·.87·.65−.75·.166−45/1024>.33.
For .65≤p≤.9 use the old sine/bracket bounds and the
new local Hessian error 60/R to obtain real curvature
>.23Mp by .8425·.77·.65−.75·.172−60/1024>.23.

On the full tilted line the 25/R simplex error gives
Re L>.304, |Im L|<.242 on the right (x≤1.3, y≤.4)
and Re L>.408, |Im L|<.261 on the left (x≤p≤.9, −y≤.45).
The standard attenuation calculation yields .15Mp(x−p)²,
since .304·11/12−.242/2>.15, and .5(.408−.261/4)>.15.
It also ensures the endpoint vertical does not exceed
the real-circle endpoint. The improved real loss there is
>.02M: −wχ'>.27u up to 1.3, from the sinc derivative
≥(1/3−u²/30)u, corrections <.001u and exp(X−R)>.99
(use its sharper immediate bound >.999 at R≥1024).
Then (.27·1.4/(8·1.6))[(.99·1.3)²−.9²]²>.02.
The vertical plus first arc has relative error <.001,
and remote arc <.01. Use v≥1.49·1024·.5³ and .65³
respectively, with the two different local curvatures.
The sum of the local, reference and actual tilted exterior
errors is <.286 in the first case and <.407 in the second,
plenty below 1/sqrt(2) after the two remote terms.

## .9≤p≤1.5, all markers

Use the centered truncated slope .4, h=.2p and Hessian
model of phase_R32768_tilt.md. Its same elementary
30/R estimate is valid at R≥1024, and its quantitative
third/fourth bound increases only to 1.15M, since
exp(.12)+(14 exp(.12)+7)/1024<1.15. Multiplication by
the tilt leaves the derivative cap 1.55M (1.16²·1.15<1.55).
The positive bracket from the R4096 note for p≥.9
and .8·.88·.54·.8−1.16·(30/1024)/.9>.26 give
real curvature >.26Mp. The tilted stationary Hessian
stays <1.5Mp, and |σ|<1.3Mp, by
1.16(1+1.5/6+30/(.9·1024))<1.5.
The two vertical signs still follow from .59−30/1024>.4·1.28.

Improve the exterior estimates as follows. The undistorted
real loss for u≤1.8 is at least .022M(u²−u_p²)², from
−wχ'>.21u as before (the inverse-radius corrections
are <.001u on this range). The two horizontal endpoints
x=.8p and 1.2p therefore have loss >.0028 M p⁴,
because du/dx≥.999 and
.022·.999⁴·(.2·1.8)²>.0028.
For p/2≤x≤.8p, the absolute outward real-loss slope
exceeds .016Mp³: |χ(u)−χ(u_p)| is at least
.21·(.999)²(.36p²)/(3.2R), and we still have
u≥.999 p/2, w≥1.4R, and du/dx≥.999.
The right part 1.2p≤x≤1.8 gives the same .016Mp³
lower bound with larger factors. Therefore the two near
exterior tails together have relative bound
[2 sqrt(1.3/(2π))/(.016 sqrt(M) p^(5/2))]
  exp(−.0028Mp⁴).
Use the new endpoint loss for the vertical bound
.075 sqrt(Mp³) exp(−.0028Mp⁴), with the old .16p length.
The rest of the first arc retains
8 sqrt(M) [exp(−.01Mp⁴)+exp(−.021M)].
The remote arc <.01 is unchanged.

Using (Q) and the directly integrated reference tail with
τ=.26Mp, at M≥1.49·1024, p≥.9, the local, reference,
near exterior, vertical and other first-arc errors are
respectively <.073, .002, .116, .153 and .015,
all decreasing from those bounds (for the local formula
bound its p numerator by 1.5 and v=Mp³ below at .9).
The sum including the remote error <.369<1/sqrt(2).
All medium angles on R≥1024 are now covered.
