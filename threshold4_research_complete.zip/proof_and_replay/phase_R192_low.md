# All small-angle signs p≤1/2 already work at R≥192

Use the R512 small-angle proof and the same contour identities.
The k=0 cusp and p≤1/8 are covered previously. For 1/8≤p≤.5,
the main improvement is a cosine moment bound that raises c/M
above .448, and integrated decay on the actual outgoing contour.

The 15/R model estimate still holds on the same small hull
(with |w|≤.81 and |Im w|≤.36) at R≥192: use .813/R (from exp(.81/R)−1) and
.34/R for the scaled z and exponential argument errors, enlarge T4
deviation to 9.45/R and the exponential modulus to 1.436,
with exponential difference <.49/R. The T3 cap is 5.5/R,
and the S terms are <4.55/R,14/R². All termwise sums remain <15/R.
In particular the L simplex model error is at most 7.5/R there.
For real 0≤t≤1 the cosine moment bound gives
Re L(pt)≥1/2−p²(t²+1)/24−7.5/R.
Since c/M=(3/2)∫_0^1(1−t²)Re L(pt) dt and the weighted
mean of t² is 1/5, this yields
    .448 < 1/2−p²/20−7.5/R ≤ c/M ≤ 1/2+7.5/R < .54.
This is stronger than bounding the minimum cosine on the simplex.

## The bounded indices k≤19

Keep b=.55 and set x0=1.05. The central hull has |w|<1.17,
−.275≤Im w≤.51. At R≥192, direct expansion gives
|z/R−1|<1.174/R, |z−R−iw|<.69/R.
Normalize the Touchard polynomials T3,T4,T5 by R^3,R^4,R^5:
their deviations are respectively <6.6/R,11/R,16.6/R.
The exponential modulus is <exp(.275+.69/R) and the
exponential difference from exp(iw) is <.92/R. The S terms
are <4.57/R, 14/R², 42/R³; hence in order three the
model derivative error is <24/R on the full hull, and
|Ω''''|,|Ω'''''| are less than 1.45M by
(1+16.6/192)exp(.275+.69/192)+42/192³<1.45.
Also −1.032M<Ω''''(0)<0 by its exact real formula.

With Airy definitions from phase_R512_low.md, use c/M>.448
to bound |Δ|≤.229 v p Z and
|Δ−E|≤.046 v p²(1.15u+4.55)Z; u=x/p, v=cp³, and
Y=(u−1)²(u+1), Z=(u+1)Y. The nonpositive sign of Re E for
x/p≤3 and the same capped geometry with 1.05,1.17 in place
of .98,1.09 give a strict damping bound d>.13 everywhere.
The exact integration code airy_quartic_R192_check.py
bounds the central residual by .94 times the signed cubic
lower amplitude for all k=1,...,19 (its actual upper bound
is less than .842). The Airy correction term itself stays
same-sign, by the R2048 integration-by-parts result.

The true real-circle loss at the new cutoff exceeds .021M:
up to u≤1.05 the sinc estimate gives −wχ'>.29u, since
the adverse terms are <.001u and e^(X−R)>.997.
Thus
(.29·1.4/(8·1.6))[(.99·1.05)²−.5²]²>.021.
The real-circle loss then increases outward to end of the
first expanded arc with slope >.10M, by the usual χ-gap
calculation from the cutoff (same method as R512).
For the vertical at x0, use Re L>.295 and |Im L|<.238
for 0≤y≤b(x0−p); these follow from the simplex moment
formulas with error 12/R, x=1.05, p≤.5, y≤.51.
Integrate the vertical derivative from 0 to any y:
the real loss is at least
    y M(x0²−p²)[(1−b²/3)·.295−b·.238] > .11My.
Indeed ∫y² gives factor b²/3 relative to x0²−p²,
and the mixed term gives at most b times the imaginary
bound after integration. This argument does not
assume pointwise monotonicity along the vertical.
The two outgoing pieces contribute relatively at most
2(1/.11+1/.10) exp(−.021M)/sqrt(M)<.006,
using 1/|Airy lower amplitude|<sqrt(M).
The remote contributions in both halves are <.001
from loss >.4R+M/(5R) and
sqrt(M) exp(−M/(5R))≤sqrt(5R/2); the fact R≥192 suffices.

Beyond x0 on the reference path x−p≥(.55/1.05)x,
so the cubic loss exceeds .132c x³. Also |E|≤.17 c x⁴.
Since c>.448·1.49·192, the inequality exp(t)≥t²/2
gives c x⁴ exp(−.066c x³)≤2/(.066² c x²)<3.3.
Integrating x³≥x0²x bounds the reference+correction
tail by
2.3·1.561·sqrt(c/.448) exp(−.066c x0³)/(.066c x0²)
<.002, which decreases above its lower endpoint.
Thus the total error is <.949 and the correct sign holds.

## The unbounded indices k≥20

On the usual slope b=.5 to x0=1.05 take h=.25p.
The local hull has |w|≤1.26p, with the 15/R derivative
model. For |y|≤.125p and x∈[.75p,1.25p],
sin x≥.935x, exp(−y)≥.9375, exp(.125p)≤1+.13p.
The model bracket sinc p−exp(−y)cos x is therefore
at least (.28125−1/6)p²−.01319p⁴−.13p>−.116p.
The mean zero Hessian estimate gives real curvature
>.345Mp by .9375·.935·.75−.75·.116−1.25·15·2.26/192>.345.
The tilted stationary modulus is <1.55Mp and both
tilted derivatives <1.79M, by 1.25(1+.5/6+30/192)<1.55
and 1.25²(exp(.0625)+15/192)<1.79.

On the extended full contour the third derivative model
error is <24/R by the same polynomial check (|w|<1.175,
y≥−.25), so use the L simplex error 12/R.
On the right x≤1.05,y≤.525 one gets Re L>.293, |Im L|<.238.
On the left use Re L>.416 and |Im L|<.170.
These imply the usual exterior coefficient .165Mp:
the right vertical attenuation .5(.293·11/12−.238/2)
is multiplied by x+p≥2.25p outside the local interval,
and the left attenuation .5(.416−.170/4)>.165.
The two outgoing real and vertical pieces again have
relative error <.006 by the first half of this proof:
with b=.5 the vertical bound is stronger than .11My
(use .293, .238 and (1−b²/3)).
The far real ends contribute <.001 by the same remote loss.

Since c/M<.54, v=Mp³≥(3π/2)20/.54>174.5.
The local (Q) error and the two Gaussian tail bounds
from phase_R2048_gaussian.md now give a sum <.58 at
h=.25p and the stated curvatures; details in
margin_R192_low_check.py. Adding the other tails still
gives <1/sqrt(2), which proves the sign uniformly.
