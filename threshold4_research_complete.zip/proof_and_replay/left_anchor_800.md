# A single far-left real root and phase anchor for m≥800

The counting argument only needs to decide whether the root phase pushes
past the matching integer index; four anchors are not necessary. Write
n=4m+r, 0≤r≤3, and use the first rational samples in the former proof:
v_L=2.75, 3.53, 4.32, 5.11 respectively. Let u=(1+i)v_L,
a_L=(24/625) m^5/(4v_L^4). For all m≥800 we prove one real root
t<−a_L and the strict absolute phase H_n(a_L)<−(m−1)π.

## Smaller small-radius bridge

The small-R proof in big_blocks4_effective_bulk.md §2 applies under the
weaker conditions 0<R≤1/20, n≥2900, nR≥75. Use μ≥700 rather than
1024 in all its inequalities: the degree estimates, the saddle
competition and the implicit derivative bounds there already hold
for μ≥700. Indeed N_R(700)≤4.1·700+.1<2900; at the actual saddle,
μR≥(nR−.1R)/4.1>18. Its error budget becomes <1/700 from the
central comparison, <4exp(−14·700/1024) from its main real and reference
tails, <√(17/14)exp(−18/10) from the second saddle, and
<2√(17·700)exp(−700/50) from the remaining angle. The same monotonic
bounds as before justify using the smallest μ, and the sum is less
than 1/2 (e.g. the secondary contribution is <.19).
Thus the exact sign at each phase marker in this smaller-radius
bridge is proved unchanged.

## Sign beyond the final phase marker

Use (L1)–(L2) of the original proof and bound k≥25 at z_*=128/m.
Here |u|<7.25<8, so the term factor per degree is
|u|(5/m)/z_*<5/16. On z_*≤.16, H(z_*)≤exp(z_*/5+z_*²/25)
as in left_anchor_2304.md. The bound
m z_*/5+m z_*²/25+S(z_*)<27 gives tail ≤2·3^27(5/16)^100.
The exact directed inequalities in left_first_cutoff_800.py apply
for every real reciprocal parameter in [0,1/800], and show the
first sample has negative sign after removing v^r in each row.
The limit as v→0 of the normalized reverse polynomial is positive,
so at least one distinct real root lies to the left of −a_L.

## Absolute phase at the anchor

Follow left_anchor_2304.md with new constants; here |u|<7.25.
Put z=5up/m, δ=p−1, z0=5u/m. On |δ|=4/m,
|p^4|<1.021, |z|<37/m<.05, and |p^4−1|>15/m.
Using T=6DB/z⁴=1+z/4+E, |E|≤.06|z|²,
the exact saddle equation p⁴T(z)=1+(r−DS(z))/(4m)
perturbs p⁴−1 by <11/m. Rouché gives exactly one such solution.
It has R=|z|<1/20, μ/m=|p|⁴>.98, n≥3200 and
nR≥20√2·2.75(1−4/m)>75. The angular uniqueness in the
bridge and arg z=π/4+Im log p identify the correct branch.

For δ0=(r−5u)/(16m), the same expansions give
|δ−δ0|<100/m². The error in the linearized saddle equation,
after removing its dominant terms 4δ+5u/(4m)−r/(4m),
is bounded by
[6.1·16+21·36.25/4+1.021·.06·37²+39/4]/m²<400/m².
Use |p⁵−1|<21/m and |DS(z)|≤39/m. Dividing by four gives
the stated error. As in the prior proof,
H_n(a_L)+nπ/4 is the imaginary part of
S(z)+m(p⁴H(z)−1−4log p)−r log p. The quadratic cancellation
leaves
    u + [5u+(5/96)u²+(5r/16)u−r²/32]/m,
with total error ≤4000/m²+8·100²/m³.
For the 4000 constant, the termwise numerator bounds as in
left_anchor_2304.md are
6·4³, 7.25·11·4², (5/6)·7.25²·25, 1.021·37³/200,
36.25·4+37²/2+37³/(6·800), 3·4²/(2(1−4/800)).
Here |p⁶−1|<25/m. The leading correction has modulus <47/m.
Thus |H_n(a_L)+nπ/4−v_L|<.067. Each v_L is within .01
of (1+r/4−1/8)π, giving
    −H_n(a_L)>(m−1+1/8)π−.077>(m−1)π.
If the intermediate marker signs can be supplied, the same
degree count now needs only m−1 intervening sign brackets.
This improves the endpoint anchor and small-radius conditions,
not the intermediate compact or outer-angle coverage.
