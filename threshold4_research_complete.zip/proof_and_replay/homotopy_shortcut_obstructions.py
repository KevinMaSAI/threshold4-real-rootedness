"""Exact checks of two auxiliary obstructions, not counterexamples to P_n."""
import sympy as s
from math import comb
U,T,w,v,y,z=s.symbols('U T w v y z')
p=[s.Integer(1)]
for n in range(1,10):
    p.append(s.expand(sum(comb(n-1,k-1)*p[n-k]*(1 if k<=2 else U if k==3 else T)
                          for k in range(1,n+1))))
f=s.Poly(p[9].subs({U:20+w,T:21+11*w}),w)
assert f.all_coeffs()==[280,107709,1484048,5318175]
assert f.discriminant()==-467037175402531462316
j5=p[5].subs({U:y,T:(1+v)*y-v})
j8=p[8].subs({U:y,T:(1+v)*y-v})
B=s.Poly(s.cancel((j8*j5.subs(y,z)-j8.subs(y,z)*j5)/(y-z)),v,y,z)
C=s.Matrix([[B.coeff_monomial(v**2*y**i*z**j) for j in range(2)] for i in range(2)])
assert C==s.Matrix([[-294,-1526],[-1526,3346]])
assert C.det()==-3312400
print('exact witnesses: negative cubic discriminant, indefinite matrix coefficient')
