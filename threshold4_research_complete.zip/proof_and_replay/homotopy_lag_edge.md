# Three-rank lag: strict edge interlacing and root motion

Notation: F_n(s,t) is the actual threshold 3→4 interpolation.
Writing n=4m+r, s=1−c/m² and t=m⁵w, use the normalization R_m and
limit R(w;c) from homotopy_critical_edge.md. Let 0≤c≤C and
0<δ≤|w|≤L, with C,δ,L fixed. The following are *local* edge facts
for sufficiently large m; they do not assert global interlacing.

1. Every root of either F_n or F_(n−3) in this common scaled annulus
   is negative and simple. Within the annulus their real roots strictly
   alternate, in the sense that between any consecutive pair of roots
   of either row in the annulus there is exactly one of the other row.
2. If x is a root of F_n in that annulus, its local derivative with
   respect to s is strictly negative. Equivalently
   F_(n−3)(s,x)/∂_t F_n(s,x)>0. This is uniform over c∈[0,C]
   for sufficiently large m. At s=1 use the finite simple branch.

For the lag row let m' be floor((n−3)/4). Its remainder is
r'=(r+1) mod 4 and (m'/m)→1. Its natural parameters are
c'=c(m'/m)² and w'=w(m/m')⁵; their convergence to c,w on compact
sets is uniform. Thus, after its own nonvanishing normalization
with m', its limit in the common variables is R(w;c) with remainder
r'. The old compact convergence proof via Cauchy estimates also
works for complex c in bounded disks: only absolute values of c
enter the expansion. This provides locally uniform convergence of
both w- and c-derivatives by the Cauchy integral formula.

On the negative axis write w=−24a⁴, a>0, and
U=(4ca+1/(5a))/√2, W=(4ca−1/(5a))/√2. Then W is strictly
increasing in a, and U>0. With A(U)=arctan(tanh U)∈(0,π/4),
the zeros for r=0,1,2,3 have respectively the exact real phase
description

    W=kπ+π/2;  W=kπ+A(U);  W=kπ;  W=kπ−A(U).

Existence and uniqueness per such phase strip whenever contained in
the image of W follow because W∓A(U) is strictly increasing in a:
W_a≥|U_a| and 0<A'(U)<1. For c>0 the image is all of R; for c=0
it is (−∞,0), and the patterns simply restrict to that interval.
In one complete period the order is r2 at kπ, followed by r1,
r0, r3, and then r2 at (k+1)π. Thus each cyclic neighboring pair
(r,r+1 mod 4) strictly alternates. Distinct colors never share a
root at any finite negative w. The same conclusion for the
finite normalized rows in a fixed compact annulus follows from
compactness and Rouché about the simple real roots of each limit:
along any counterexample sequence c_j→c*, roots can only converge
to the corresponding limit roots. They cannot coalesce with
another root of the same color (unique Rouché root in a small
disk) or of different color (the limit rows share none). The
strictly intermediate limit root of the other color transfers to
the finite row by its own disk, which remains strictly between
the two endpoints. Likewise, two intermediate roots would
contradict the alternating order of the limits. This argument is
valid even when a root at a limiting endpoint of the annulus
moves across that endpoint; all disks may be chosen in a slightly
larger annulus.

For root motion, the even remainder phase equation has c derivative
W_c=4a/√2>0 at fixed a, and a derivative W_a>0 at fixed c.
For odd remainders the equations are W∓A(U)=kπ. Since U_c=W_c and
0<A'(U)<1, their c derivative is strictly positive too, as is the a
derivative already checked. Therefore each local a(c) has derivative
strictly negative, and w(c)=−24a(c)^4 has derivative strictly positive.
Transfer this strict derivative sign to the finite rows: if a sequence
of finite simple roots violates it, take a compact-convergent
subsequence of roots and c. The limit root is simple and the derivatives
of normalized analytic functions converge locally uniformly at these
points. Thus the finite signed derivatives −R_(m,c)/R_(m,w) converge
to the strictly positive limiting derivative, a contradiction.

At a finite root the scaling change gives dx/ds=−m⁷ dw/dc<0.
The exact interpolation identity ∂_s F_n=binom(n,3)(1−t)F_(n−3)
then gives the stated strict lag sign because x<0. This gives no
control of the central roots, roots in windows w→0 or ∞, or cases
c→∞. In particular it does not prove the global lag conjecture
and does not settle the all-n threshold-four problem.
