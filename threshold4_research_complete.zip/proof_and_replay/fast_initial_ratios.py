"""Certified dyadic ratio initialization using leading bits only.

This is a speeding-up step for the exact finite-exception backend, not
a replacement for finding a practical all-n cutoff.
"""
from random import Random

def top_interval(x, bits):
    """Enclose x by [lo,hi] times 2**shift, with exact integer endpoints."""
    if x <= 0:
        raise ValueError("requires strictly positive integer")
    shift = max(x.bit_length() - bits, 0)
    lo = x >> shift
    return lo, lo + (shift != 0), shift

def ratio_enclosures(row, precision):
    """q_i = a_(i-1)a_(i+1)/a_i², returns integers scaled by 2**precision."""
    tops = [top_interval(a, precision+12) for a in row]
    result = []
    for i in range(1, len(row)-1):
        l0,h0,s0 = tops[i-1]
        l1,h1,s1 = tops[i]
        l2,h2,s2 = tops[i+1]
        e = s0 + s2 - 2*s1 + precision
        # Represent 2**e in numerator if e>=0 and denominator if e<0.
        lo_num, hi_num = l0*l2, h0*h2
        lo_den, hi_den = l1*l1, h1*h1
        if e >= 0:
            lo_num <<= e
            hi_num <<= e
        else:
            lo_den <<= -e
            hi_den <<= -e
        result.append((lo_num//hi_den, -(-hi_num//lo_den)))
    return result

def check():
    """Exact regression against full products; proof is by interval containment."""
    rand = Random(874008)
    for bits in (32,64,128,256,512):
        for _ in range(250):
            scale = rand.randrange(1,30000)
            row = [(1 << (a:=rand.randrange(max(1,scale-20),scale+20))) +
                   rand.getrandbits(a) for j in range(12)]
            bounds = ratio_enclosures(row,bits)
            for k, (lo,hi) in enumerate(bounds,1):
                q = row[k-1]*row[k+1] << bits
                den = row[k]**2
                assert lo*den <= q <= hi*den
    print("12,500 full-product containment checks pass")

if __name__ == '__main__':
    check()
