"""Exact tilted half-integral with a midpoint second-derivative remainder.

For a complex line w(t)=p+delta0+t*d, its real integrand is
g(t)=Re(d exp(Omega(w(t))-Omega(p))).
Then g''=Re(d**3 exp(Omega(w(t))-Omega(p))*(Omega''+Omega'**2)).
Taylor's theorem gives a rigorous lower integral
h*g(mid)+h**3/24*min(g'') on each real t interval.
"""
from phase_wide_cell import (Q, ONE, ZERO, F, rat, root, quo, E2, cadd, csub,
    cscale, cmul, cdiv, add, mul, sq, neg, sub, scale, exp, trig, exponent_diff,
    geometry, tail_bound)
from phase_rect_certificate import grid, outer, split
from argparse import ArgumentParser
def ce(z):
    c,s=trig(z[1]);return cscale((c,s),exp(z[0]))
def e1(z):
    n=sum(max(abs(k) for k in x) for x in z)
    if n<=4*Q: return cadd(z,E2(z,n<=Q//4))
    return csub(ce(z),(ONE,ZERO))
def derivatives(C,h,P):
    R,z,p,a1,M,aE=C
    q=neg(quo(h[1],R)),quo(h[0],R)
    q1,q2,q3=e1(q),e1(cscale(q,rat(2))),e1(cscale(q,rat(3)))
    z2=cmul(z,z); z3=cmul(z,z2)
    delta=cmul(z,q1)
    znew=cadd(z,delta)
    znew2=cmul(znew,znew)
    znew3=cmul(znew,znew2)
    small1=cadd(cmul(z,q1),cadd(cmul(z2,q2),cdiv(cmul(z3,q3),2)))
    big1=cmul(cmul(aE,z),e1(cadd(q,delta)))
    raw1=csub(cscale(small1,a1),big1)
    d1=neg(quo(raw1[1],R)),quo(raw1[0],R)
    small2=cadd(znew,cadd(cscale(znew2,rat(2)),cscale(znew3,rat(3,2))))
    big2=cmul(cmul(aE,ce(delta)),cadd(znew2,znew))
    raw2=csub(big2,cscale(small2,a1))
    R2=sq(R)
    d2=quo(raw2[0],R2),quo(raw2[1],R2)
    return cmul(P,cadd(d2,cmul(d1,d1)))

def integrate(C,dimension):
    R,z,p,a1,M,aE=C
    tilt=rat(9,20);stop=rat(3,5);drop=mul(stop,tilt)
    after=sub(sub(rat(81,25),p),stop)
    assert after[0]>0
    seg=[((neg(p),neg(mul(tilt,p))),(p,mul(tilt,p))),
         ((ZERO,ZERO),(stop,drop)),
         ((stop,drop),(ZERO,neg(drop))),
         ((stop,ZERO),(after,ZERO))]
    total=ZERO
    step=rat(1,dimension)
    weight=rat(1,24*dimension**3)
    for start,d in seg:
        d3=cmul(d,cmul(d,d))
        for j in range(dimension):
            T=(rat(j,dimension)[0],rat(j+1,dimension)[1])
            mid=rat(2*j+1,2*dimension)
            h=cadd(start,cscale(d,mid))
            PM=ce(exponent_diff(C,*h))
            val=cmul(d,PM)[0]
            h=cadd(start,cscale(d,T))
            P=ce(exponent_diff(C,*h))
            curv=cmul(d3,derivatives(C,h,P))[0]
            total=add(total,add(mul(step,val),mul(weight,curv)))
    return total[0]-tail_bound(C,F(81,25))[1]

def main():
    p=ArgumentParser()
    p.add_argument('--radius',nargs=2,required=True)
    p.add_argument('--angle',nargs=2,required=True)
    p.add_argument('--grid',nargs=2,type=int,default=[6,16])
    p.add_argument('--boxes',type=int,default=40)
    p.add_argument('--max-depth',type=int,default=8)
    a=p.parse_args()
    A,U=outer(*a.radius),outer(*a.angle)
    assert A[0]>=20*Q and 0<U[0]<U[1]<=F(13,10)*Q+1
    todo=[(R,V,0) for R in grid(A,a.grid[0]) for V in grid(U,a.grid[1])]
    least=None
    n=0
    while todo:
        R,U,d=todo.pop()
        try: lo=integrate(geometry(R,U),a.boxes)
        except AssertionError: lo=0
        if lo>0:
            n+=1
            least=lo if least is None else min(least,lo)
            continue
        if d==a.max_depth:
            print('INCONCLUSIVE',R,U,'lower',lo,'denominator',Q,flush=True)
            raise ArithmeticError('increase precision or refine quadrature')
        if F(R[1]-R[0],R[0])>=F(U[1]-U[0],2*Q):
            todo.extend((V,U,d+1) for V in split(R))
        else:
            todo.extend((R,V,d+1) for V in split(U))
    print('VERIFIED Taylor rectangle',a.radius,a.angle,'accepted',n,'least lower',least,'/',Q)
if __name__=='__main__':
    main()
