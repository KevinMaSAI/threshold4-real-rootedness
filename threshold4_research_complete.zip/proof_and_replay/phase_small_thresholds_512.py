"""Exact small-angle exclusion tests for continuous radial strips."""
from fractions import Fraction as F
from phase_small_threshold import Q, outer, grid, PI, add, phase, rat
def main():
    for R,u in [(160,F(13,40)),(192,F(31,100)),(256,F(7,25)),(384,F(1,4)),(512,F(9,40))]:
        U=rat(u.numerator,u.denominator)
        lo=min(add(phase(A,U)[0],PI)[0] for A in grid(outer(32,R),(R-32)*8))
        assert lo>0
        print('VERIFIED R in [32,',R,'] H_R(u=',u,')+pi >',lo,'/',Q)
if __name__=='__main__':
    main()
