#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
exe=$(mktemp /tmp/bigblocks4-check.XXXXXXXX)
g++ -O3 -UNDEBUG -std=c++17 finite_exception_gmp.cpp -lgmpxx -lgmp -o "$exe"
for span in '3072 3200' '3201 3583' '3584 3712' '3713 4095' '4096 4224' '4225 4639' '4640 4736' '4737 5172'; do
    read -r a b <<<"$span"
    "$exe" "$a" "$b"
done
