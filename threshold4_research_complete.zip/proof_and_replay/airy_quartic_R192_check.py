"""One-dimensional directed proof of the quartic residual at R>=192."""
from math import isqrt
from angular_certificate import Q, ONE, add, sub, mul, sq, exp, point
from phase_k_certificate import PI, rat, quo, root
from fractions import Fraction as F
def coarse_exp_negative(x):
    return exp(point(-min(x,80*Q)))[1]
b=rat(11,20)
beta=mul(b,sub(ONE,mul(sq(b),rat(1,3))))
def capped(X,B):
    return min(X[0],B[0]),min(X[1],B[1])
M=mul(rat(149,100),point(192*Q))
c=mul(rat(448,1000),M)
for k in range(1,20):
    v=mul(PI,rat(3*k,2))
    for pp in range(200,501):
        p=rat(pp,1000)
        if pp==500 or mul(c,mul(p,sq(p)))[0]>v[1]:
            break # last cap .5 follows from the domain itself
    integral=0
    for j in range(6*512):
        X=(rat(j,512)[0],rat(j+1,512)[1])
        Y=mul(sq(sub(X,ONE)),add(X,ONE))
        Z=mul(Y,add(X,ONE))
        p_sum=mul(p,add(X,ONE))
        p_aff=mul(p,add(mul(rat(23,20),X),rat(91,20)))
        main=mul(rat(229,1000),mul(v,mul(p,Z)))
        rem=mul(rat(46,1000),mul(v,mul(p,mul(p_aff,Z))))
        bound=add(rem,mul(rat(1,2),sq(main)))[1]
        s0=add(rat(105,100),p)
        if j<3*512:
            # E has *nonpositive real part* in this subinterval.
            penalty=mul(rat(46,1000),mul(capped(p_sum,s0),
                       capped(p_aff,add(rat(117,100),mul(rat(4),p)))))
        else:
            penalty=mul(rat(229,1000),s0)
        d=sub(beta,penalty)
        assert d[0]>rat(13,100)[1]
        loss=mul(d,mul(v,Y))[0]
        integral+=mul(rat(1,512),mul((0,bound),(0,coarse_exp_negative(loss))))[1]
    # For x>=6, Y>=25 x^3/36 and Z<=2 x^4, relative integrand
    # dominated by 300 x^8 exp(-.42 x^3) since v<90,p<=.5,
    # d>.13 and v>4.712. Use exp(.21 x³)≥(.21 x³)^3/6,
    # then integrate the remaining exp(-.21*36*x). Tail <10^-6.
    integral+=rat(1,1000000)[1]
    relative=mul(quo(mul(rat(23,10),root(v)),mul(PI,rat(2,3))),(0,integral))[1]
    print('k',k,'p cap',pp,'/1000; relative error <',relative,'/',Q,flush=True)
    assert 100*relative<94*Q
