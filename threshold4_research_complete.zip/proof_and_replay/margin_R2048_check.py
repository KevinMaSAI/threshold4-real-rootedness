"""Directed/rational replay for the R>=2048 angular improvements."""
from fractions import Fraction as F
from angular_certificate import Q, ONE, add, sub, mul, sq, exp, trig, point, neg, scale
from phase_k_certificate import PI, rat, quo, root
def b(s):
    x=F(str(s)); return rat(x.numerator,x.denominator)
def m(*args):
    out=ONE
    for a in args:out=mul(out,a)
    return out
def upper(x,s):
    assert x[1]<b(s)[0],(x[1]/Q,s)
def lower(x,s):
    assert x[0]>b(s)[1],(x[0]/Q,s)
def inv(x):return quo(ONE,x)
def damp(x):return exp(neg(x))
def power(x,k):return m(*[x]*k)
M=m(b('1.49'),b(2048))
sqrtM=root(M)
R=b(2048)
r0=b('.35')
upper(add(exp(b('.12')),quo(add(m(b(14),exp(b('.12'))),b(7)),R)), '1.14')
lower(sub(m(b('.5'),trig(b('.5'))[0]),quo(b('7.5'),R)), '.435')
lower(sub(m(b('.5'),trig(b('.28'))[0]),quo(b('7.5'),R)), '.476')
assert m(b('.435'),M,power(b('.28'),3))[0]>scale(PI,9)[1]
upper(add(m(b('1.006'),exp(add(b('.1485'),quo(b('.34'),R)))),quo(b(42),power(R,3))),'1.17')
upper(add(exp(b('.1485')),quo(b(15),R)),'1.18')
upper(add(ONE,add(quo(b(6),R),add(quo(b(7),sq(R)),inv(power(R,3))))),'1.004')

def qerror(t,S,U,p,v):
    return m(inv(v),root(quo(S,t)),add(quo(m(U,p),m(b(8),sq(t))),
                                 quo(m(b(5),sq(U)),m(b(24),power(t,3)))))
def tailG(a,S,v):
    return m(quo(m(b(2),root(quo(S,scale(PI,2)))),m(a,r0,root(v))),
             damp(m(b('.5'),a,sq(r0),v)))
def tailE(a,S,v):
    return m(quo(root(quo(S,scale(PI,2))),m(a,r0,root(v))),
             damp(m(a,sq(r0),v)))
v=b('65.4')
assert quo(m(PI,b('10.5')),b('.504'))[0]>v[1]
t,S,U=b('.39'),b('1.4'),b('1.72')
upper(qerror(t,S,U,b('.5'),v),'.323')
upper(tailG(t,S,v),'.181')
upper(tailE(b('.22'),S,v),'.132')
upper(m(b(2),add(inv(b('.044')),inv(b('.023'))),inv(sqrtM),damp(m(b('.0021'),M))),'.005')
v=m(b('.125'),M)
t,S,U=b('.215'),b('1.5'),b('1.9')
upper(qerror(t,S,U,b('.9'),v),'.557')
upper(tailG(t,S,v),'.005')
upper(tailE(b('.17'),S,v),'.005')
upper(m(b(5),sqrtM,damp(m(b('.0035'),M))),'.007')

p=b('.9');v=m(M,power(p,3)); e=damp(m(b('.00188'),v,p))
upper(quo(add(m(b(7),p),b(61)),v),'.031')
upper(m(root(quo(b(3),b('.27'))),damp(m(b('.0027'),v))),'.009')
upper(m(quo(b(49),m(sqrtM,sq(p),root(p))),e),'.027')
upper(m(b('.075'),root(v),e),'.083')
upper(m(b(8),sqrtM,add(damp(m(b('.01'),v,p)),damp(m(b('.021'),M)))),'.001')
r=2048
assert F('1.001')*(r+r*r+F(r**3,2))+12*r*r<4_400_000_000
print('VERIFIED rational margins for the R2048 Airy and Gaussian improvements')
