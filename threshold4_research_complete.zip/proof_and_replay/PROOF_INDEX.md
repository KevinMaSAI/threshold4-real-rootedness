# Index of the actual proof dependencies

The older progress headings are historical; they do not override the final theorem.

- Statement, all-n partition, overview: README_先读_阈值4全阶证明.md
- Independent coefficient models: check.py and big_blocks4_report.md
- Last finite degree: finite_certificate_proof.md, finite_prefix_exact.py,
  graeffe_certificate.py, graeffe_fast.py, finite_exception_range.py,
  graeffe_fast_adaptive.py, finite_exception_large.py, finite_exception_gmp.cpp
- Actual saddle path and count: saddle_all_n_ge_5173.md
  - Original analytic geometry and cubic cusp: big_blocks4_explicit_tail_18.md,
    big_blocks4_effective_bulk.md, outer_saddle_R20.md
  - R=20..192 and phase exclusions: phase_mid_band_160_joint.md,
    phase_mid_band_192_joint.md, phase_R20_cusp.py, phase_small_threshold.py,
    phase_small_thresholds.py and the cited rectangle logs
  - R=192..512: phase_tilt_factored_proof.md, phase_tilt_factored.py,
    phase_R192_low.md, phase_R256_midangle.md, phase_high_angle_gaussian.md,
    and the two cited wide-angle rectangles
  - R≥512: full_tail_67_5m.md, phase_R512_low.md, phase_R512_medium.md;
    the tail n cutoff in that earlier file is superseded by the independent
    continuous certificate on 192..512
  - R=10..20: outer_saddle_R10.md, outer_saddle_R12.md,
    phase_mid_band_192_lower10_joint.md and the listed exact integrations
  - R=1/4..10: bulk_cutoff_mixed_joint_proof.md,
    bulk_cutoff_paired_proof.md, bulk_cutoff_mixed_interval.py,
    angular_certificate.py and angular_certificate.json
  - R≤1/4 and final anchor: small_radius_quarter.md, left_anchor_800.md,
    left_anchor_2304.md, big_blocks4_effective_bulk.md §4,
    left_first_cutoff_800.py
- Reverse proof check: proof_audit_2026_11_25.md
- Recorded coverage consistency: audit_coverage_manifest.py
- Research and references: research_log_zh.md, literature_recheck_2026-11-25.md
