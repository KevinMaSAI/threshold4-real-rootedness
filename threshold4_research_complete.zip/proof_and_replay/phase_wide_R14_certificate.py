"""Adaptively certify continuous parameter rectangles with exact bounds."""
from argparse import ArgumentParser
from fractions import Fraction as F
from phase_rect_certificate import grid, outer, split, Q
from phase_wide_R14_cell import geometry, lower


def main():
    p=ArgumentParser()
    p.add_argument('--radius',nargs=2,default=['32','36'])
    p.add_argument('--angle',nargs=2,default=['13/10','29/10'])
    p.add_argument('--grid',nargs=2,type=int,default=[8,80])
    p.add_argument('--boxes',type=int,default=96)
    p.add_argument('--max-depth',type=int,default=7)
    a=p.parse_args()
    A,U=outer(*a.radius),outer(*a.angle)
    assert A[0]>=14*Q and 0<U[0]<U[1]<=F(309,100)*Q
    integrator=lower
    todo=[(R,V,0) for R in grid(A,a.grid[0]) for V in grid(U,a.grid[1])]
    least=None
    n=0
    while todo:
        R,V,d=todo.pop()
        try:
            lo=integrator(geometry(R,V),a.boxes)
        except AssertionError:
            lo=0
        if lo>0:
            n+=1
            least=lo if least is None else min(least,lo)
            continue
        if d==a.max_depth:
            print("INCONCLUSIVE dyadic cell",R,V,"lower",lo,"precision denom",Q,flush=True)
            raise ArithmeticError("could not verify requested rectangle")
        if F(R[1]-R[0],R[0]) >= F(V[1]-V[0],F(16,5)*Q-V[0]):
            todo.extend((RR,V,d+1) for RR in split(R))
        else:
            todo.extend((R,VV,d+1) for VV in split(V))
    print('VERIFIED geometry rectangle',a.radius,a.angle,'accepted',n,'minimum',least,'/',Q,flush=True)

if __name__=='__main__':
    main()
