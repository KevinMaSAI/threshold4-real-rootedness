"""Check recorded completion extents; does not replace replaying the proofs."""
from fractions import Fraction as F
from pathlib import Path
from re import search, MULTILINE
from ast import literal_eval

def content(f):
    return Path(f).read_text(encoding='utf-8')

finite=[
    ('finite_prefix_exact_results.txt',r'^CERTIFIED contiguous original-integer prefix (\d+) \.\. (\d+)'),
]
blocks=[(1025,2048),(2049,2559),(2560,3071)]
for a,b in blocks:
    finite.append((f'finite_exception_{a}_{b}_results.txt',r'^CERTIFIED original distinct negative roots on n in (\d+) (\d+)'))
for a,b in [(3072,3200),(3201,3583),(3584,3712),(3713,4095),(4096,4224),(4225,4639),(4640,4736),(4737,5172)]:
    finite.append((f'finite_gmp_{a}_{b}_results.txt',r'^CERTIFIED exact original n in (\d+) (\d+)'))
cursor=0
for name,patt in finite:
    m=search(patt,content(name),flags=MULTILINE)
    assert m is not None,(name,'not completed')
    a,b=map(int,m.groups())
    assert a==cursor and a<=b,(name,a,b,cursor)
    cursor=b+1
assert cursor==5173

def geo(name,r,u):
    m=search(r'^VERIFIED geometry rectangle (\[.*?\]) (\[.*?\]) accepted (\d+) minimum (\d+) / (\d+)',content(name),MULTILINE)
    assert m,name
    assert tuple(map(F,literal_eval(m[1])))==tuple(map(F,r)),name
    assert tuple(map(F,literal_eval(m[2])))==tuple(map(F,u)),name
    assert int(m[3])>0 and int(m[4])>0 and int(m[5])==2**58,name
for a,b in [(20,26),(26,32),(32,48),(48,64),(64,96),(96,128)]:
    geo(f'phase_tilt_{a}_{b}_results.txt',(a,b),('7/20','13/10'))
for a,b,u in [(128,160,'13/40'),(160,192,'31/100')]:
    geo(f'phase_tilt_{a}_{b}_results.txt',(a,b),(u,'13/10'))
for a,b in [(20,24),(24,28),(28,32)]:
    geo(f'phase_R20_{a}_{b}_results.txt',(a,b),('13/10','29/10'))
for a,b in [(32,36),(36,48),(48,64),(64,96),(96,128)]:
    geo(f'phase_wide_{a}_{b}_results.txt',(a,b),('13/10','29/10'))
for a,b in [(128,160),(160,192),(192,256)]:
    geo(f'phase_wide_{a}_{b}_results.txt',(a,b),('13/10','5/2'))
geo('phase_wide_256_512_results.txt',(256,512),('13/10','3/2'))
geo('phase_wide_R10_results.txt',(10,12),('49/20','14/5'))
geo('phase_wide_R12_final_results.txt',(12,20),('49/20','14/5'))
geo('phase_wide_R16_extra_results.txt',(16,20),('19/10','49/20'))
assert "['192', '512'] ['49/100', '13/10'] accepted 1024 least lower 7784261617311366 / 288230376151711744" in content('phase_tilt_factored_full_results.txt')
assert 'CERTIFIED N_compact = 5173' in content('bulk_mixed_quarter_10_results.txt')
assert 'VERIFIED cusp' in content('phase_R20_cusp_results.txt')
assert 'CERTIFIED all four first-sample signs' in content('left_first_cutoff_800_results.txt')
print('Manifest confirmed: 0..5172 exact finite coverage, with completed continuous sign prerequisites for n≥5173.')
