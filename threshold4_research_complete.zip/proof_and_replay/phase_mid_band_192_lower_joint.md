# Strict negative roots for 8921≤n≤3520607

The middle band upper proof is phase_mid_band_192_joint.md;
below R=20 replace the compact saddle segment by:
1. 14≤R≤20: outer_saddle_R14.md and the finished exact proof
   phase_wide_R14_results.txt cover every actual marker
   (u≤2.5 excluded by n≥8921, u=2.5..2.9 exact, and u>2.9
   by the high-angle theorem since p≥u).
2. 1/20≤R≤14: same compact domain certificate and
   direct mixed joint bounds as before, now at cutoff 14.
   Execute bulk_cutoff_mixed_joint.py angular_certificate.json 14.
   The 401 certified cells give n≥8921, as recorded in
   bulk_mixed_joint_14_results.txt.
3. R≤1/20: unchanged small-radius sign bridge and the
   left anchor. n≥8921 gives m≥2230>800 and satisfies the
   small-radius bound n≥2900 for the whole relevant branch.

The outer continuation through R=14 follows the strict radial
monotonicity in outer_saddle_R14.md. The two descriptions give
the same saddle at R=14: for the same a their angular maxima
are unique on the upper half circle, and the radial value n
then fixes a on the strictly increasing outer branch.
The cusp radius is in (20,192) for all the n stated here, so
the exact positive cusp signs still apply. As in the larger
cutoff proof, the lifted phase moves from 0 to below −(m−1)π
at the anchor. First successive marker brackets plus the
far-left root exhaust the degree, and all roots are simple.
