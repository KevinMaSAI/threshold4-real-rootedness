# Remaining markers at R≥2048: improved Gaussian bounds

This covers k≥7 at 1/8≤p≤.5 and every marker at .5≤p≤1.5.
Notation and the normalization of (Q) are unchanged from
low_angle_R4096_complete.md, medium_angle_R4096.md, and
phase_R32768_tilt.md. The circular geometry gives M≥1.49R.
All quoted error margins are relative to the Gaussian modulus;
its real part is at least that modulus divided by sqrt(2).

## Low-angle markers at k≥7

The 15/R derivative model bounds on the same hull now hold at
R≥2048 as in phase_R2048_quartic.md. Retain slope b=.5, x0=.72
and local half-width h=.35p. The improved mean-zero Hessian
estimate of low_angle_large_k.md gives tilted real curvature
>.39Mp, since .9125·.925·.65−.75·.1787−45/2048>.39.
The stationary tilted Hessian stays below 1.4Mp and both
tilted derivatives of orders three and four below 1.72M:
these follow from 1.25(1+.5/6+30/2048)<1.4 and
1.25²(exp(.0875)+15/2048)<1.72.
On the right of the saddle the simplex moment estimates give
Re L>.403 and |Im L|<.124 for x≤.72, y≤.36; on the left
they give Re L>.475 and |Im L|<.111 for x≤p≤.5.
The same exterior attenuation calculation gives right
coefficient .5(.403·11/12−.124/2)>.15 against
M(x−p)²(x+p); on the left the coefficient is
.5(.475−.111/4)>.22. Using x+p≥2p on the right and
x+p≥p on the left yields the common .22Mp(x−p)² lower loss.

The real loss at cutoff still exceeds .0021M as in the
R4096 note (sinc corrections remain <.001u), but rather than
charging the maximum over the whole length, integrate loss
along each of the two outgoing pieces. On the endpoint vertical
x=.72, 0≤y≤.5(x−p), Re[((x+iy)²−p²)L]>.044:
use [(1−.25)·.403−.124](.72²−.5²)>.044.
The real loss thus increases up the vertical with slope >.044M.
On the real arc to the end of its first expanded sector,
−U'_x exceeds .023M. In fact the χ difference from the saddle
at x=.72 is at least .30[(.99·.72)²−.5²]/(3.2R);
it only increases thereafter, while w≥1.4R, u>.71, du/dx>.99.
This proves the claimed slope there. Because |G|^(-1)<sqrt(M),
the two pieces together are relatively bounded by
2(1/.044+1/.023) exp(−.0021M)/sqrt(M) < .005.
Use the unchanged remote estimate <.01.

Finally c/M<.504 by the simplex modulus bound, so
v=Mp³≥(3π/2)7/.504>65.4. Formula (Q), the directly
integrated Gaussian tail with τ=.39Mp, and the exterior at
τ=2·.22Mp give relative errors respectively <.323, <.181,
and <.132. The explicit directed-rational substitutions are
in margin_R2048_check.py. Their sum including the two
additional bounds is <.651<1/sqrt(2).

## Medium angles

For .5≤p≤.9 retain the full slope .5 with cutoff x0=1.3
from medium_angle_R4096.md. All model bounds 50/R there
remain true by the same polynomial estimates at R≥2048.
Use .215Mp as the local real curvature, since
.8425·.77·.65−.75·.172−150/2048>.215.
The tilted stationary Hessian bound is still 1.5Mp, since
1.25(1+.9/6+100/2048)<1.5, and derivative bounds still
1.9M, since 1.25²(exp(.1575)+50/2048)<1.9.
For the outer slope, the L moment bounds become
Re L>.316, |Im L|<.230 on the right and
Re L>.420, |Im L|<.248 on the left. Integrating the
vertical decay as in that note yields single lower loss
.17Mp(x−p)², since 2·.5(.316·11/12−.230/2)>.17
and .5(.420−.248/4)>.17.
That argument ensures the return never exceeds the
real-circle end. The real-circle loss remains >.0035M,
and far-arc bound is unchanged. For v=Mp³≥1.49·2048/8,
the five errors (local Q, missing Gaussian, actual tilted
exterior, vertical with first arc, remote) are bounded
respectively by .557, .005, .005, .007, .01.
Use the Gaussian exterior prefactor <9/sqrt(v) at exponent
−.17·.35²v; the local and reference constants are listed in
margin_R2048_check.py. Sum <.584.

For .9≤p≤1.5 use slope .4 on the centered truncated contour
of phase_R32768_tilt.md, and follow case .9≤p≤1.5 of
medium_angle_R4096.md. The model Hessian error is <.01465;
the derivative bounds <1.14M are unchanged, by the
termwise estimate exp(.12)+(14 exp(.12)+2+5)/2048<1.14.
The local tilted curvature >.27Mp remains valid because
.8·.88·.54·.8−1.16·.01465/.9>.27. The stationary tilted
Hessian modulus and the two tilted derivative bounds stay
below 1.5Mp and 1.55M as before. The vertical-end argument
still applies because .59−.01465>.4·1.28, and the
real-circle estimates hold verbatim at R≥2048.
Use the five explicit error bounds in phase_R32768_tilt.md
now at M=1.49·2048 and p=.9: local Q <.031 (in the bound
use 7/(Mp²)+61/(Mp³)), reference <.009, near exterior <.027,
vertical <.083, other first-arc <.001. Plus remote <.01,
the total is below .161. These expressions are decreasing
in M and p in the stated region, including sqrt(v)
paired with exp(−.00188 v p) as v≥2224.
This proves both medium-angle cases.
