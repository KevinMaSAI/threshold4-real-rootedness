# A normalized, factored certificate for the entire remaining angular rectangle

Use the exact saddle geometry above R=192, and write u=Im z_p,
p=R arg z_p, V=z_p/R, M=a exp R. On the rectangle
192≤R≤512, .49≤u≤1.3, we have .4899≤p≤1.301,
by monotonicity of arcsin and its elementary upper bound
arcsin(s)≤s/sqrt(1−s²). The code takes dyadic outer covers,
so allow the tiny outer rounding in these weaker p bounds.
We verify positivity of the real upper half contour integral
after division by exp Ω(p). At each exact phase marker
H=Im Ω(p)=−kπ the omitted phase contributes (−1)^k, giving
the sign of the original real coefficient.

## Contour, analytic tails, and normalization

On the upper half deform the real x-axis to
w=x+i b(x−p) for 0≤x≤x0=p+.6, with b=.45.
At x0 return vertically downward from Im w=.27,
then continue on the real axis to πR. On the other
half take the reflected conjugate path. These halves
meet at −i b p, and the full endpoints remain −πR
and πR, so equality of the integrals follows from
the integrand being entire. The upper integrand on
the straight pieces has real ordinate
  e^(Re(Ω(w)−Ω(p))) [cos Im(Ω(w)−Ω(p))−b sin Im(Ω(w)−Ω(p))].
This is integration in real x, including the line element.

Here is a uniform tail proof. In terms of u on the first
expanded real arc, use
 U'_u=M u w(u) [χ(u)−χ(u_p)],
where the geometric scalar w(u) (distinct from the
complex angular variable above) is in [1.5R,1.52R].
Up to u=1.901, the sinc derivative gives
−w(u)χ'(u)>.20u, since (1/3−1.901²/30)u is its first
part, the adverse corrections are <.001u, and
exp(X−R)>.99. For the correction check, use
u/X³+u/X²+3(1+1/X)u/(1.5R²) with X≥.99R.
Set u0=R sin(x0/R). Then du/dx≥.999 through the
real cutoff, and integration gives
 loss(x0) ≥ [.20*1.5/(8*1.52)] M (u0²−u_p²)²
          ≥ [.20*1.5/(8*1.52)] M (.999²*.6*(2p+.6))²
          > .022 M.
From x0 to end of the first expanded arc, the loss slope
is >.099 M: use the now fixed χ gap at least
 .20(.999²*.6*(2p+.6))/(2*1.52R),
then u≥.999(p+.6), w(u)≥1.5R and du/dx>.99.

The vertical return stays below the real-circle endpoint.
Indeed Ω'(w)=i M(w²−p²)L(w) with the divided-difference
simplex L (see low_angle_R4096_complete.md).
On the hull of the endpoint vertical and the nodes ±p,
all imaginary parts are nonnegative and |w|<1.921.
Writing z=R exp(iw/R), we have |z/R−1|≤1.921/R,
|z−R−iw|≤1.846/R, and both exponentials exp(z−R)
and exp(iw) have modulus ≤1. Thus their difference
is at most 1.846/R. The T3/R³ deviation from 1 is
<8.78/R, using |z/R|≤1 and its explicit Touchard
polynomial. The S contribution to Ω'''/(iM)
is <4.53/R (using (1+a)/M≤1/R).
This gives |Ω'''/(iM)−exp(iw)|<16/R, hence a
simplex model error 8/R. By the real and imaginary
moment bounds, for x=x0 and 0≤y≤.27,
Re L>.191 and |Im L|<.359:
use .5−.27/6−(1.901²+1.301²)/24−8/192 for the first
and 1.901/6+8/192 for the second.
Integrating the vertical derivative from 0 to y as in
phase_R192_low.md, the loss is at least
 M y(x0²−p²) [(1−b²/3)*.191 − b*.70*.359] > 0,
because x0/(x0+p)<.70. Thus the absolute magnitude
of the vertical integral is at most .27 exp(−.022M),
and the remaining first arc contributes at most
exp(−.022M)/(.099 M).
The rest has loss >.4R+M/(5R) by
phase_high_angle_gaussian.md §3, relative to u=π
and hence to p. Its absolute bound is
4R exp(−.4R−M/(5R)). These are the exact three tail
terms subtracted in the code (which rounds conservatively).

## Factored exponent on the two straight pieces

The rapid verified enclosure is obtained by factoring the
common square of angular deviation before interval arithmetic.
Write h=w−p, q=ih/R, K(s)=(exp(s)−1−s)/s² with
its removable value 1/2 at zero, and B_q=1+qK(q).
Then Δz=ih V B_q. With f as in the stationary formula,
let D=(w(u)/(R f(u))) exp(iu).
Writing Ω as (1+a)S(z)−a exp(z)+a−inw/R,
the exact stationary subtraction cancels all terms linear in q.
The exact identity for the residual exponent is
    Ω(p+h)−Ω(p) = (ih V)² R(1+a) [
          K(q)/(R z_p) + (2/R)K(2q) + (3/2)V K(3q)
          − D (B_q² K(Δz)+K(q)/z_p) ].
For verification, start with
 (1+a) sum_(j=1)^3 z_p^j (j q)^2 K(j q)/j!
   − a exp(z_p) [Δz² K(Δz)+ z_p q² K(q)]
and substitute q² z_p²=(ih V)² and
a exp(z_p)/(R(1+a))=D from stationarity.
The normalizations V=sqrt(1−(u/R)²)+i u/R,
1/z_p=conj(V)/R and
w(u)/R=2/R+[1.5+(1−2u²)/R²]/Re V
keep the R dependence correlated. Notice f=sin(u)/u+
cos(u)/(R Re V), not cos(u) Re V/R. The code was
independently checked against the original exponent formula
on 100 exact parameter points before the continuum run
(those comparisons serve only as debugging checks).

For each straight piece let its horizontal parameter t
run in [0,1]; the left piece h=(1+ib)p(t−1), and
the right piece h=(1+ib)(.6)t. Multiply the respective
real ordinate by p and .6. Each exact rational t box is
covered by outward rounded dyadics. The lower interval
bound of its real integrand times the exact rational box
length is a lower integral bound. The method then
subtracts the rigorously bounded magnitude of the tails.
This verifies continuum rectangles, not n or point samples.

K(s) is evaluated by summing terms s^(j−2)/j! for j=2...
cap, in Horner form. If |s|≤1/4 and cap=11 the omitted
absolute tail is ≤2*4^(-10)/12!; otherwise an integer
k≥|s| and cap∈{16,18,20,24} give
2 k^(cap−1)/(cap+1)! because all successive absolute
ratios are <1/2. Every product, square root, trigonometric
and exponential enclosure is the same directed
dyadic arithmetic as the earlier certificates.
