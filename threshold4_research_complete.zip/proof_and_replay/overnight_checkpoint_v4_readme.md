# 阈值 4 实根性：夜间阶段性证明

目前已严格覆盖原题的三个区间：
- 0≤n≤1024：精确有限验证。
- 16376≤n≤2035279：一致的鞍点符号证明，使用对连续参数矩形的精确证书。
- n≥35,000,000,000：一致的解析尾部证明（旧有效尾界是 10^18）。

所有非常数多项式在这些区间的根均为互异负实根。原题仍未全阶解决；
没有找到反例。缺口为 1025≤n≤16375，以及
2035280≤n≤34,999,999,999。

读 proof phase_mid_band_160_joint.md（中间区间）和
full_tail_35b.md（无限尾部）。前者用新的紧半径联合误差缩短低端，
后者用真实曲率、符合相位的 Airy 近似与不同角度的倾斜高斯积分，覆盖
R≥4096 的所有角度。原题定义、已有文献来源和早期成果保留在
night_checkpoint_readme.md。

复验命令（纯整数和有理数，显示小数不参与判断）：
    python3 advanced_margin_checks.py
    python3 bulk_cutoff_mixed_joint.py angular_certificate.json 20
    python3 phase_R20_cusp.py
    python3 phase_small_thresholds.py
    python3 phase_wide_certificate.py --tilted --radius 20 26 --angle 7/20 13/10 --grid 30 50 --boxes 112
    python3 phase_wide_certificate.py --tilted --radius 26 32 --angle 7/20 13/10 --grid 24 50 --boxes 112
    python3 phase_wide_certificate.py --tilted --radius 128 160 --angle 13/40 13/10 --grid 48 90 --boxes 160
    python3 phase_wide_certificate.py --radius 128 160 --angle 13/10 5/2 --grid 32 60 --boxes 112
    python3 left_first_cutoff_800.py

关键命令记录：联合紧半径 37.852 秒，R20–32 合并点 28.822 秒，
R20–26 与 R26–32 低角段分别 6m12.488s 和 5m48.510s；
R128–160 宽、低角分别 2m38.452s 和 27m35.869s。部分过程并行，
其时间不能相加当作整体历时。工具未提供总 token 数或计费量。
未联系作者、发帖、投稿或支付费用。
