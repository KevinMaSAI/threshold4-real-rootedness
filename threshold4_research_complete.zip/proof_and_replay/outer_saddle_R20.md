# The outer saddle geometry extends down to R=20

Use the notation of big_blocks4_effective_bulk.md §7 and
big_blocks4_explicit_tail_18.md §1. The following proof modifies
the angular, radial and continuation constants, not the definition
of the polynomials. New finite oracle runs, when available, are
needed for the marker signs not accounted for by the large-angle
estimate below.

For R≥20 and 0≤u≤π+.1<3.25, X=√(R²−u²)≥.98R,
exp(X−R)>.75 (apply 1−v+v²/2−v³/6 to
v=u²/(R+X)≤3.25²/(1.98·20)). The exact
w=2+(1+3R²/2−2u²)/X has 1.5R≤w≤1.61R, |w'|≤3u/R:
the lower bound uses X≤R and 2−(2·3.25²−1)/R>0;
w' = u(1−(5/2)R²+2u²)/X³ ≤0, giving both the derivative
and the maximum w(0)=[2+1/R+1.5R].

For 0≤u≤π, the sinc formula in the reference gives
−(sinc u)'≥u/π²>.1u. In
−w exp(R−X) χ'=−f'−X'f+f w'/w, the term sin u/X
coming from −f' is nonnegative and remaining possible
negative terms are ≤u/X³, u/X², and
(1+1/X)·3u/(1.5R²); their sum <.009u.
Hence −χ'>u/(30R). For π≤u≤π+.1, use
−(sinc u)'≥.995/3.25−.1/π²>.295,
−sin u/X≤.1/X, |f|≤.1/π+1/X, and the same
w' formula; the corrections now sum <.021, giving the
same derivative lower bound. All inequalities extend at u=0
by the corresponding smooth limit. At u=0 the stationary
condition gives a valid positive a_c; the strict decrease to negative
χ(π) gives a unique saddle angle for each a≥a_c with
(a/(1+a)) e^R χ(u)=1 (the endpoint a_c gives u=0).

Inside the expanded first arc the sign of the real derivative
U'=Mu w(u)(χ(u)−χ(u_p)) chooses its sole maximum (at u=0
when merging); integrating gives real drop ≥
M(u²−u_p²)²/160, in particular ≥ the old /200 bound.
On the far arc the loss relative to u=π is at least
.45 R+M/(5R). To see this, up to angle π/6
the loss in Re S after u=π+.1 is at least
.1·π·1.5R>.45R, by its derivative −u w.
At other angles the loss relative to θ=0 is at least
min(R²/2,R³/24) as in the old proof. The loss at u=π
relative to θ=0 is <8R for R≥20:
in terms of X the loss is R−X+π²+(R³−X³+3Xπ²)/6;
bound R−X≤π²/(1.98R), R³−X³≤3R²(R−X),
and 3Xπ²≤3Rπ². At R=20 and onward the claimed inequality
follows (use π²<10); both R²/2−8R and R³/24−8R
exceed .45R. The exponential term loses at least M/(5R)
beyond the expanded arc, since using its absolute envelope
e^(X−R) there drops by at least .75·π/(10R) from u=π.
The interval beyond θ=π/6 is farther in angular coordinate than
the expanded arc, so the envelope bound still holds there.

The radial value N_R(a) along the positive saddle is strictly
increasing in a. Here are constants for the identical derivative
reasoning of §7 of the reference: |Y'|≤4.73Ru, w≥1.5R,
|w'|≤3u/R, 0<d=u+arcsin(u/R)<π; its lower bound
−J'≥.26Ru applies when d≤π/2, by the sinc integral from §7
with X≥.98R and π²<10. The error |w'J|≤3u in that case,
so w(−J') exceeds |Y'|+|w'J|. When d≥π/2,
−J'>.97Ru/sin² d by the second estimate of §7, and
|w'J|≤3π u/sin² d. Again w(−J') dominates both
errors. The positive factor 1+a is increasing and the radial
expression starts at the positive value N(R); at the endpoint
a→∞ the factor diverges and the positive expression stays
positive. Consequently N_R(a) increases to infinity.
The critical value formula N(R)=R⁴/[2(R+1−E(R))] with
E=e^(−R)(1+2R+3R²/2) has N'>0 also for R≥20:
E<1 and 4E+R|E'|<1 follow by decreasing each R^j e^(−R),
j≤3, and e^20>2^20. The actual saddle curve at fixed n>4000
therefore extends continuously from its cusp down to R=20.
Strict change of a with R follows from the same radial derivative
argument (differentiate through the maximum angle:
∂N_R/∂log R=−U_θθ−U_θ,logR²/U_θθ>0 on the positive branch,
by harmonicity after log R). Local uniqueness identifies it
with adjacent compact ranges in any overlap.

## High angles R between 20 and 32

For 20≤R≤32 and p≥2.9, all exact phase marker signs hold
by a direct modification of phase_high_angle_gaussian.md §3.
Here u_p≥.99p and f≤(π−u_p)/u_p as before;
using w≥1.5R and π<22/7 gives M>315.
In addition positivity of f at the stationary point implies
π−u_p>arg z_p≥u_p/R (compare tan(π−u_p)>u_p/X),
so angular x=p+.15 lies inside the expanded first arc:
its imaginary coordinate is at most u_p+.15<π+.1.
On |x−p|≤.15, x≥2.75 ⇒ u≥2.7225, and everywhere on
this extended first arc the upper phase lies ≤π+.1+2·3.27/20,
so the angle in the exponential curvature term lies within .43
of π. Here x_end≤3.27: verify with sin x≥x−x³/6 and
u_end=π+.1<3.242. Thus −Re Ω''>.64M throughout this
local interval, by .75(1−.43²/2)(19/20)>.64.
The same reasoning for x≥2.4 on the first arc gives
−Re Ω''>.50M using distance from π at most .766.
On x≤2.4 the monotonicity and loss at 2.4 yield real loss
≥.0625M. The global real derivative upper bounds
|Ω''|≤3M and |Ω'''|≤2M still hold, using
(1+a)/M≤1/R on this range and the same explicit derivative
polynomials.

With h=.15 and τ=.64M the local relative error is
<2.3/sqrt(M); the two reference tails are bounded by
15 exp(−.0072M)/sqrt(M). The actual tails for x≥2.4 have
relative bound 19 exp(−.005625M)/sqrt(M), and for x<2.4
the bound is 1.7 sqrt(M) exp(−.0625M).
The remote bound is (14/5)√(5/2) R^(3/2) exp(−.45R)
by the improved angular gap and optimization in M as before.
At M≥315, R≥20 the five terms are respectively below
.14, .10, .20, .001, .07, and decreasing.
The total is below 1/√2, as required.

Finally for R∈[20,32], any actual saddle with n≥27004 has
u>1.3. Otherwise f≥1−1.3²/6−1/(.98·20)>.66, so
M/(1+a)=w/(e^(X−R)f)<3.3R and a<.001
(use maximum 3.3 R e^(−R) ≤66 e^(−20) <1/1001).
The rotated exponential term in DF has positive real part,
since u+arg z ≤1.3+arcsin(1.3/20)<π/2.
Therefore n=Re DF≤(1+a)DS(R)<17500, contradiction.
Only the wide angular band 1.3≤u≤2.9 remains to be certified
for this R range and these n; small-angle and merging cases
are absent here if n≥27004.

The directed rectangle code supports R≥20 by bounding arcsin x
on 0≤x≤1/6; the nonnegative degree ≥25 tail is bounded by
(1/6)^25/(1−1/36)<2^(−58). For its sharper tail at u≥2.8, the
proof in phase_rect_certificate.md changes to −f' > .266,
|X'f|<.03 and |fw'/w|<.003, using X≥.98R, |w'|≤3u/R,
and |f|≤.35/2.8+1/(.98·20)<.177. Hence −wχ'>.17, and
the factor in the integrated quadratic loss is at least
(1.5/1.61)·(2.8/2)·.17 > .2. Since du/dx≥.98,
the implementation's angular Gaussian coefficient .19M is still
valid. The cutoff x=81/25 is within the extended first arc, and
u(x)≥.99x follows directly from sin x≥x−x³/6, not a .99 lower
bound for the derivative. The prior unsharpened tail bound also
holds by the /200 inequality above.

## A sharper exclusion of u≤1.3 with n≥17196

In the last proof, retain the positive lower contribution of the
exponential being subtracted from DF. For R∈[20,32] and u≤1.3,
the stationary condition still gives a<.001, and w≥1.5R,
f≤1+1/(.98·20), so M≥1.42R. Also e^(X−R)>.95 because
R−X≤1.3²/(1.98·20). From θ≤arcsin(1.3/20)<.066 follows
cos(u+θ)>.20 (bound the cosine by its Taylor lower estimate
through degree six at 1.366). Therefore
    n ≤ 1.001(R+R²+R³/2) − (1.42)(.95)(.20) R².
The right side increases with R≥20 and is <17196 at R=32.
This proves that all actual stationary configurations with n≥17196
still have u>1.3 for R∈[20,32]. No assumptions about the cusp
for lesser n are made by this exclusion.
