#!/usr/bin/env bash
# Replays the final joins and major final checks. Earlier angular logs/replay
# commands and all analytic lemmas accompany the package.
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 check.py --limit 12
python3 margin_R10_check.py
python3 middle_splice_R16_check.py
python3 margin_R12_check.py
python3 bulk_cutoff_mixed_interval.py angular_certificate.json 10 1/4
python3 phase_wide_R10_certificate.py --radius 10 12 --angle 49/20 14/5 --grid 12 24 --boxes 192 --max-depth 9
python3 phase_wide_R12_certificate.py --radius 12 20 --angle 49/20 14/5 --grid 16 24 --boxes 192 --max-depth 9
python3 phase_wide_R12_certificate.py --radius 16 20 --angle 19/10 49/20 --grid 12 22 --boxes 144 --max-depth 9
python3 phase_R20_cusp.py
python3 phase_small_threshold.py
python3 phase_small_thresholds.py
python3 airy_quartic_R192_check.py
python3 margin_R192_low_check.py
python3 phase_tilt_factored_margin_check.py
python3 phase_tilt_factored.py --radius 192 512 --angle 49/100 13/10 --grid 32 32 --boxes 80
python3 airy_quartic_R512_check.py
python3 margin_R512_check.py
python3 left_first_cutoff_800.py
python3 audit_coverage_manifest.py
