"""Exact arithmetic for the factored rectangle's geometric tail."""
from fractions import Fraction as F
from phase_k_certificate import rat
from angular_certificate import Q,exp
R=192
p0=F('.4899')
p1=F('1.301')
x0=p1+F('.6')
assert F('1.3')**2 < p1**2*(1-(F('1.3')/R)**2)
assert x0*x0+F('.27')**2<F('1.921')**2
assert F('1.921')**2/2<F('1.846')
assert 3*F('1.921')+3+F(1,R)<F('8.78')
assert F('4.5')+F(4,R)+F(1,R**2)<F('4.53')
assert F('8.78')+F('1.846')+F('4.53')<16
C=F('.5')-F('.27')/6-(x0*x0+p1*p1)/24-F(8,R)
D=x0/6+F(8,R)
assert C>F('.191') and D<F('.359')
b=F('.45')
assert (p0+F('.6'))/(2*p0+F('.6'))<F('.70')
assert (1-b*b/3)*F('.191')-b*F('.70')*F('.359')>0
s=F('.999')**2*F('.6')*(2*p0+F('.6'))
assert F('.20')*F('1.5')/(8*F('1.52'))*s*s>F('.022')
assert F('.20')*s/(2*F('1.52'))*F('.999')*(p0+F('.6'))*F('1.5')*F('.99')>F('.099')
print('VERIFIED exact geometric tail constants for the normalized factored rectangle')
