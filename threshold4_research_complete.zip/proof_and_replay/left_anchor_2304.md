# Four far-left roots and phase anchor uniformly from m=2304

Use notation of big_blocks4_effective_bulk.md §4:
n=4m+r, u=(1+i)v_L for the fourth rational sample in row r,
t=−a_L=α m^5/u^4 with α=24/625, and saddle z=5up/m.
This improves the earlier left-anchoring cutoff m≥8192 to m≥2304
(so n≥9216 suffices for this part alone).

## 1. Four isolated real roots before the left anchor

The exact coefficient formula (L1)–(L2) remains unchanged. For the
tail take real z_*=320/m and bound H(z_*) where H(z)=24B(z)/z⁴.
Its coefficients starting in degree 2 are 24/(j+4)!,
and the ratio of consecutive terms including z is ≤z/7 there.
Thus for 0≤z≤320/2304,
H(z)≤1+z/5+z²/[30(1−z/7)]≤exp(z/5+z²/25).
Consequently A(z_*)H(z_*)^m<3^67, since
m z_*²/25≤(320²)/(25·2304)<2 and S(z_*)<1.
With 0≤(m)_k/m^k≤1 and |(1+i)v|<22, exactly the same Cauchy
coefficient majorant as in §4 gives tail <2·3^67 (11/32)^100.
The strict sign proof now uses m≥2304 and this tail in
left_cutoff_2304.py. All 16 directed-rational inequalities passed;
this is a uniform bound in the real reciprocal parameter, not
sampling m. Signs are initially positive at v=0 after removing
the factor v^r, then alternate at the four samples, yielding
four distinct negative real roots |t|>a_L.

## 2. Exact saddle and cancellation at the phase anchor

Let δ=p−1, z0=5u/m, and T(z)=6 DB(z)/z⁴.
The exact saddle equation is p⁴ T(z)=1+(r−DS(z))/(4m).
On |δ|=9/m with m≥2304, |p|^4<1.02, |z|<111/m≤.05,
|DS(z)|<.1, and |T(z)−1−z/4|≤.06 |z|² by the factorial series.
Then |p⁴−1|>35/m while the total perturbation is <30/m.
Rouché gives one such saddle near p=1. Its absolute radius is
R=|z|≤(5·21/m)(1+9/m)<1/20, with nR>263 as in the
original anchor (v_L≥12.17). Furthermore μ/m=|p|⁴ lies within
the small-radius saddle regime (in particular .98<μ/m<1.02).
The small-radius geometric uniqueness identifies this exact
saddle with the continuation branch; the phase is lifted using
arg z=π/4+Im log p where log p is the principal logarithm.

Set δ0=(r−5u)/(16m). Then |δ−δ0|≤625/m².
Indeed, p⁴ T(z)=1+4δ+5u/(4m)+E where
|E|≤[6.1·81+46·105/4+1.02·.06·111²]/m²:
use |p⁴−1−4δ|≤6.1|δ|² and |p⁵−1|<46/m.
Adding |DS(z)|/(4m)≤117/(4m²) and dividing by four gives
the claimed bound. The derivative estimate comes from
|DS(z)|≤|z|(1+|z|+|z|²/2)<117/m.

The exact phase formula is the imaginary part of
S(z)+m(p⁴H(z)−1−4 log p)−r log p, after adding nπ/4.
Use H(z)=1+z/5+z²/30+O(z³), with absolute remainder
≤|z|³/200 in |z|≤.05. Retaining terms through 1/m gives
    u+5u/m+(5/6)u²/m+8mδ²+(5u−r)δ,
with absolute error at most 60000/m². To check the bound,
the separate errors (scaled by m²) are no more than:
- |m(p⁴−1−4 log p−8δ²)|: 6·9³.
- |u(p⁵−1−5δ)|: 21·11·9².
- |(5/6)u²(p⁶−1)/m|: (5/6)·21²·56.
- cubic and higher in H: 1.02·111³/200.
- |S(z)−5u/m|: 105·9+111²/2+111³/(6·2304).
- |r(log p−δ)|: 3·9²/[2(1−9/2304)].
The elementary binomial, Taylor, and logarithm terms give the
bounds using |u|<21 and |δ|≤9/m, and their sum is <60000.

Now 8mδ²+(5u−r)δ=−(5u−r)²/(32m)+8m(δ−δ0)² exactly.
The other terms beyond u combine to
[5u+(5/96)u²+(5r/16)u−r²/32]/m, plus the square error.
Its magnitude is <150/m, since r≤3. Therefore
    |H_n(a_L)+nπ/4 − v_L|
          <150/m + 60000/m² + 8·625²/m³ < .08.
The sample v_L differs from (4+r/4−1/8)π by <.01, so
−H_n(a_L)>(m−4+1/8)π−.09>(m−4)π.
This verifies the strict left anchor in the full real phase,
with no modulo ambiguity. It does not lower by itself the
separate compact interval bound n≥56230.
