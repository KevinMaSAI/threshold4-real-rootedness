"""Exact substitutions for the R=14 outer-geometry proof."""
from fractions import Fraction as F
from angular_certificate import Q, ONE, add, sub, mul, exp, trig, neg
from phase_k_certificate import PI, rat, quo, root
def b(x):
    f=F(str(x));return rat(f.numerator,f.denominator)
def m(*it):
    out=ONE
    for t in it:out=mul(out,t)
    return out
def lt(x,y):
    assert x[1]<y[0],(x[1]/Q,y[0]/Q)
R=F(14);X=F('.972')*R;u=F('3.25')
theta=F('.1')
pi_lo,pi_hi=F(PI[0],Q),F(PI[1],Q)
assert R*R-u*u > X*X
z=u*u/(R+X)
assert 1-z+z*z/2-z**3/6>F('.67')
assert 1/X**3+1/X**2+3*(1+1/X)/(F('1.5')*R*R)<F('.017')
assert theta/X+u/X**3+(u/X+3*u/(F('1.5')*R**2))*(theta/pi_lo+1/X)<F('.0375')
assert F('.67')*(F('.295')-F('.0375'))/(F('1.65')*u)>F(1,32)
assert F('.67')*(F('.1')-F('.017'))/F('1.65')>F(1,32)
assert 10/(F('1.972')*R)+10+F('7.5')*R<F('8.25')*R
assert F('.625')*R-F('8.25')>F('.45')
assert F('.67')*pi_lo*F('.1')>F('.2')
assert F('.239')-F('.81')/X>F('.179')
lt(b('.239'),quo(trig(b('2.5'))[1],b('2.5')))
lt(b('-.81'),trig(b('2.5'))[0])
assert F('1.001')*(20+20**2+F(20**3,2)+F('1.65')/F('.179')*20**2)<8921
assert F('3.28')-F('3.28')**3/(6*R**2)>pi_hi+F('.1')
assert (pi_hi-F('2.871'))/F('2.871')<F('.095')
assert F('.67')*(1-F('.766')**2/2)*F(13,14)>F('.43')
assert F('.67')*(1-F('.57')**2/2)*F(13,14)>F('.51')
assert F('.14')*F('1.5')*F('2.8')/(2*F('1.65'))>F('.178')
assert F('.178')*F('.972')**2>F('.16')
M=b(630);S=root(M);tau=F('.51')
L=2/(8*tau**2)+20/(24*tau**3)
lt(quo(m(root(b(F(3)/tau)),b(L)),M),b('.03'))
lt(quo(m(b(14),exp(neg(m(b('.0102'),M)))),S),b('.002'))
lt(quo(m(b(17),exp(neg(m(b('.0086'),M)))),S),b('.004'))
lt(m(b('1.7'),S,exp(neg(m(b('.05375'),M)))),b('.001'))
lt(m(b('2.8'),b(14),exp(b('-6.3')),S,exp(b('-6.3'))),b('.01'))
print('VERIFIED outward-rational R=14 proof margins')
