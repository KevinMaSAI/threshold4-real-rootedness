# Paired directed bounds reduce the compact threshold to 17196

This replaces only the compact-radius step
big_blocks4_effective_bulk.md §3. The old saved angle certificates
are reused, but the new cutoff is proved with an exact arithmetic
replay on 504 radial intervals from 1/20 to 20.

In each outer angular cell keep together the strict lower bound g
for the unperturbed B-value gap and the upper bound p≥0 for the
antagonistic perturbation of the S term. The actual loss is at
least λg−p, not λ min(g)/2. A pair (g,p) is dominated by a
pair (g0,p0) when g0≤g and p0≥p. Dropping it cannot worsen the
minimum loss, so only the ordered nondominated frontier needs
to be stored. For a candidate λ0, check each of these losses
directly through their minimum along with the local curvature
loss λ_0 c_b w²/2 on the edge of the symmetric segment.
If the minimum is ≥1/2 at λ0, then each relative tail bound
sqrt(λ) exp[−(λg−p)] decreases for all λ≥λ0, since
λ0 g≥λ0 g−p≥1/2. The dynamic local-bound tail similarly decreases.
These checks also certify the outer global maximum separation
for all λ≥λ0; no artificial λ≥2p/g condition is needed.

On an outer angle bracket with b≤.5, S has nonpositive
real angular second derivative (all cos jθ≥0), so no lower bound
8 S_2/curvature is needed there. In the other cases that bound
is kept and gives c_b≥7/8 of the pure curvature as before.
The radial monotonicity proof needs only
λ > L_1 L_2/(c_b d_2), and the new exact choice uses a factor
257/256 to guarantee strictness. The old derivative estimates
L_j based on λ≥512, the inner and outer angle margins, and
the analytic estimate (Q) are unchanged. A positive root of
the actual saddle equation exists at the prescribed real n
when n exceeds the computed upper threshold for the radial
value at λ0, because it strictly increases with λ and diverges.

For each checked Gaussian tail e^(−x) sqrt(y) ≤ 1/16 use
the integer/rational lower bound
    e^(2x) ≥ (8/3)^(2j) [1+2(x−j)+2(x−j)²], j=floor x.
This follows from e>8/3 and the nonnegative Taylor terms.
The inequality checked after squaring is 256 y no larger
than this bound. A bit-length shortcut for j huge is even
weaker and uses 2^(2j). The two real damping tails and the two
local (Q) errors sum within the old 1/2 budget. No floating
point values determine passes or failures.

Reproduce from the research directory:
    python3 bulk_cutoff_paired_sharp.py angular_certificate.json 20
Result from all 504 contiguous dyadic radial intervals:
    CERTIFIED N_compact = 17196
See bulk_paired_sharp_20_results.txt. With the original outer
geometry and correct far-left connector, this is a quantitative
improvement in the actual proven n-band, not just a partial
sign without matching endpoints.
