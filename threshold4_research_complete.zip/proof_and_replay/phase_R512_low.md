# Low-angle marker signs on R≥512

The k=0 cusp and 0<p≤1/8 are previously covered. Here assume
1/8≤p≤1/2, R≥512. Keep the exact normalized exponent and angular
geometry of phase_R1024_quartic.md and phase_R1024_gaussian.md.

## k=1..11: retain the sign in the real quartic damping

The 15/R derivative error model still holds on the small original
hull of low_angle_large_k.md: |z/R−1|<.82/R and
|z−R−iw|<.34/R, normalized T3,T4 deviations <5.5/R,9.4/R,
exponential modulus <1.435 and difference <.49/R.
The normalized S error bounds are <4.53/R and 14/R².
Thus c/M≥cos(.5)/2−7.5/R>.423 and c/M<.515.
With M≥1.49R and v=3πk/2 this certifies the k-dependent
upper caps on p in airy_quartic_R512_check.py, using .5
directly as an upper bound whenever the radius bound is weaker.

Use b=.55 and extend the tilted path to x0=.98.
Its central hull has |w|<1.09, −.275≤Im w≤.471.
There |z/R−1|<1.092/R, |z−R−iw|<.596/R,
and normalized T3,T4,T5 deviations <6.31/R,10.5/R,16/R.
The exponential modulus is ≤exp(.275+.596/R) and its
difference from exp(iw) is <.79/R. The S terms in orders
3,4,5 have bounds 4.54/R,14/R²,42/R³ respectively.
These explicit estimates give model error <24/R in order
three, and |Ω''''|,|Ω'''''|<1.37M (use the exact norms
(1+16/R) exp(.275+.596/R)+42/R³ and analogous for T4).
At w=0, −1.013M<Ω''''(0)<0 by its exact real formula.

Extract E=(Ω''''(0)/24)(w²−p²)² as in phase_R2048_quartic.md.
That lemma's Airy derivative and sign proof applies without change:
after exact integration E contributes with the sign of the cubic.
For Δ=Ω−q the same Hermite estimates now give, with u=x/p,
Y=(u−1)²(u+1), Z=(u+1)Y,
    |Δ|≤.230 v p Z,
    |Δ−E|≤.046 v p²(1.15u+4.55)Z.
This uses |w²−p²|²≤(1+b²)²(x−p)²(x+p)² and c/M>.423.

On x≤3p the real part of E is nonpositive.
Indeed writing t=b(x−p)/(x+p)∈[−b,b/2],
the real normalized squared product is
Re[(1+ib)²(1+it)²]=(1−b²)(1−t²)−4bt,
a concave quadratic positive at −b and b/2.
In this part the cubic damping coefficient β=b(1−b²/3)
need be reduced by at most
    .046 (x+p)(|w|+4p)
≤ .046 min[p(u+1),.98+p] min[p(1.15u+4.55),1.09+4p].
For x≥3p use the cruder damping loss .230(.98+p).
In each case the bound multiplies c(x−p)²(x+p).
These constants leave strictly positive damping, at least .15.
Apply the exponential residual inequality from the R2048 proof
to these pointwise damping bounds:
the integrand majorant is
    [.046 v p²(1.15u+4.55)Z+(.230 v p Z)²/2] exp(−d v Y)
where d is the just-bounded coefficient. It suffices to use
the upper p bound at each k, because it increases the
prefactor and decreases the damping bound. Multiplying
the integral by 2.3 sqrt(v)/(2π/3) gives the relative error.
The rational program verifies it is <.9 for all k≤11.
In extending the majorant past x0/p the capped coefficients
stay positive independently of x. Its u≥6 tail is less than
10^−6 by the elementary cubic exponential bound in the code.
This computation is integral verification of uniform bounds,
not a check of finitely many n or R.

At the endpoint vertical use the model simplex error 12/R,
x0=.98, y≤.471, p≤.5, to obtain Re L>.347 and |Im L|<.187.
Thus (1−b²)·.347−2b·.187>0, ensuring the real exponent
never increases above the real-circle endpoint value.
On u≤.98, −wχ'>.295u from the same sinc derivative
and adverse terms (<.001u for R≥512); exp(X−R)>.998.
The loss at real cutoff is >.015M because
(.295·1.4/(8·1.6))[(.99·.98)²−.5²]²>.015.
Thus actual outgoing pieces and remote arc each have
relative error <.01, using M≥1.49·512, M≤2R for p≤.5
and the familiar 10 sqrt(M) exp(−.015M) and
10 M^(3/2) exp(−M/20) estimates.

Beyond x0 on the reference path, x−p≥(.48/.98)x
and the loss exceeds .118 c x³. Also |E|≤.17 c x⁴.
Since c>.423·1.49·512, one has
c x⁴ exp(−.059c x³)≤2/(.059² c x²)<2 there.
Thus the reference+quartic tail is bounded by
1.34 times the integral of exp(−.059c x³) on both
straight tails with their line elements.
Use x³≥.98²x and the same reference amplitude lower
bound to get relative contribution <.01.
The total absolute error is <.93, proving the marker signs.

## k≥12: larger tilted contour and stronger outgoing decay

Use the standard slope .5 with h=.35p, extending the
whole slope line to x0=.98. On the local hull the same 15/R
derivative bound applies. The local tilted curvature is >.32Mp,
since .9125·.925·.65−.75·.1787−45/512>.32.
The stationary tilted Hessian modulus is <1.44Mp
and tilted derivatives <1.76M, from
1.25(1+.5/6+30/512)<1.44 and
1.25²(exp(.0875)+15/512)<1.76.
On the complete slope hull |w|<1.10, |Im w|≤.49,
the third derivative model error is <24/R by the
same polynomial check as above (the lower imaginary
bound here is −.25), so simplex error ≤12/R.

On the right use Re L>.344 and |Im L|<.187;
on the left use Re L>.455 and |Im L|<.131.
The attenuation factors are
.5(.344·11/12−.187/2)>.11 and
.5(.455−.131/4)>.21 respectively. Since x+p≥2p
on the right they yield common .21Mp(x−p)² loss.
The real loss at x0>.015M was already established.
The endpoint vertical has additional loss slope >.05M,
by [(.75)·.344−.187](.98²−.5²)>.05.
The remaining expanded real arc has slope >.08M
by the same χ gap calculation as in phase_R1024_gaussian.md
with .295 curvature, u>.97 and cutoff near .98.
Thus actual outgoing error is
2(1/.05+1/.08) exp(−.015M)/sqrt(M)<.001.
The remote error remains <.01.

Since c/M<.515 and k≥12, v=Mp³>109.7.
The local Q, reference Gaussian and tilted exterior
errors, in the formulas of phase_R1024_gaussian.md
at τ=.32Mp, h=.35p, are respectively <.402,.096,.038.
Including outgoing and remote, total <.547<1/sqrt(2).
Together both subproofs handle every exact marker at
1/8≤p≤1/2 on R≥512.
