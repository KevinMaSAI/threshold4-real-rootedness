# Outer saddle geometry and high-angle signs down to R=12

Use all definitions from outer_saddle_R14.md, changing the
constants on 12≤R≤20 as follows. This supports reducing the
lower n cutoff to 7254 once the indicated exact rectangle passes.

## Geometry

For 0≤u≤π+.1 one has X≥.962R, exp(X−R)>.63 by the cubic
lower exponential bound, and 1.5R≤w≤1.68R, |w'|≤3u/R.
With these constants the adverse terms in the two sinc estimates
of the R14 note are <.024u when u≤π and <.05 when u≥π.
Thus −χ'>u/(36R), using
.63(.1−.024)/1.68>1/36 and
.63(.295−.05)/(3.25·1.68)>1/36. Integration in u gives
real angular loss > M(u²−u_p²)²/200.
For u≥2.8 the same leading sinc term exceeds .276,
and the remaining adverse terms total <.052:
the adverse X' term occurs only when f<0, while the
adverse w' term occurs only when f>0. Thus the sum is
bounded by
.1/X+u/X³+max[(u/X)(.1/2.8+1/X),
(.35/2.8+1/X)3u/(1.5R²)]<.052.
So −wχ'>.63(.276−.052)>.14, yielding loss >.16M(x−p)²
for x≥p on that first arc if u_p≥2.8, since
.14·1.5·2.8·.962²/(2·1.68)>.16. The stronger bound
>.16M(u−u_p)² also holds in u.

The Re S loss relative to θ=0 is ≥.72R² for θ∈[π/6,π].
Use the R14 note's elementary segment bounds away from
[2π/3,3π/4]. In that interval put s=θ−2π/3∈[0,π/12].
The quadratic term's loss, divided by R², is ≥.75−s
by its derivative bound; the cubic term's loss is
R(1−cos 3s)/6≥.71 R s² by the cosine Taylor bound
(9/2−81(π/12)²/24)/6>.71. Thus the sum is at least
.75−1/(2.84R)>.72. At u=π the loss relative to 0
is <8.26R: using π²<9.87, the formula in R14 gives the
upper bound 9.87/(1.962R)+9.87+.75·9.87R<8.26R.
Hence the far loss in Re S relative to u=π is >.37R.
For angles from the end of the first arc to θ=π/6 the
same result follows from integrating u w as in R14.
The exponential envelope yields additional loss
>.195M/R because .63·π·.1>.195.
This verifies far-arc isolation and tail estimates.

Radial monotonicity: |Y'|≤4.86Ru by the R14 derivative
formula. At d≤π/2 the better bound
d−sin d cos d = 2∫_0^d sin² x dx ≥ (2/3−π²/30)d³
follows from sin² x≥x²−x⁴/3 there. Thus −J'>.32Ru
and |w'J|≤3u. With w≥1.5R these strictly dominate the
error even at R=12. At d≥π/2, −J'>.93Ru/sin²d
and |w'J|≤3πu/sin²d, again sufficient.
Monotonicity of the critical value N(R) also extends:
4E+R|E'|≤(4+R)E<1, since the separate monomials in that
upper bound decrease for R≥12 and its bound using e^12>2^12
is <1 at R=12. Thus the same unique radial continuation
is valid down to R=12.

## Exclusion and positive marker estimate

If u≤2.45 then f>.260−.78/(.962R)>.192 and exp(X−R)>.77.
Here sin(2.45)/2.45>.260 and cos(2.45)>−.78.
The upper bound on w now gives a/(1+a)<11.4R exp(−R), so a<.001
(use exp(12)>150000). In the radial formula as in R14,
for R≤18 bound by 1.001(18+18²+18³/2+(1.68/.192)18²)<7254.
For 18≤R≤20 we have w≤1.62R, f>.214, and θ<.137,
so −cos(u+θ)≤.86. Retaining this factor gives
1.001(20+20²+20³/2+(1.62·.86/.214)20²)<7254.
Thus no such saddle occurs when n≥7254.

For the opposite sector p≥2.9, by monotonicity of sine on the
first arc, u_p≥2.9−2.9³/(6·12²)>2.871. The exact lower
bound M>630 follows from f<.095−.95/R just as in R14,
valid for the larger strip [12,20]. The extended first
arc has x<3.29 by the sine check. Also p+.2 stays inside it.
The cosine phases in the real curvature have deviation
from π bounded by .766 at x≥2.4, and by .65 on |x−p|≤.2:
use R sin(2.4/R)≥2.4−2.4³/(6·12²) at the left boundary
and upper angle π+.1+2·3.29/12.
Hence the curvature constants .40M on x≥2.4 and .45M
on the local segment replace .43M and .51M.
The derivative caps (3,2,2)M for orders (2,3,4) still hold
by the same touchard bounds, now at R≥12.
In the R14 proof use Q with τ=.45M and h=.2, giving <.043
relative local error. Gaussian and actual near tails are
respectively <16 e^(−.009M)/sqrt M and
<18 e^(−.008M)/sqrt M, each <.006. The remaining first
arc is ≤1.7 sqrt M e^(−.05M)<.001. The far part is at most
2.8 (12 e^(−.37·12)) sqrt(630) e^(−.195·630/20)<.03 by
monotonicity. Altogether error <.086<1/sqrt(2).

It therefore suffices to certify the remaining continuous
rectangle 12≤R≤20, 2.45≤u≤2.9. The directed code
phase_wide_R12_certificate.py uses the same finite Taylor
series as the R14 version, with u at the cutoff x=3.24
bounded below by .987x, and far exponent .195M/R instead
of .20M/R. It retains the coefficient .16 in the near
Gaussian estimate, justified above. This is one continuum
certificate for all n≥7254 on this segment, not a scan.

## Avoiding very narrow integrand peaks: analytic p≥2.8

A smaller exact rectangle suffices instead of the one ending
at u=2.9. For p≥2.8, u_p≥2.8−2.8³/(6·12²)>2.774.
Then f<.133−.93/R, since (π−u_p)/u_p<.133 and cos u_p<−.93.
Thus M>1.5R²/(.133R−.93)≥6·.93/.133²>315 (minimize the
positive rational function, or use its completed square).
At the local left edge x≥2.6, the rotated phase is still
within .65 of π. The curvature and intervals in the
preceding argument remain unchanged, including p+.2 in
the expanded arc. For x≤2.4, loss is at least .032M
because p−2.4≥.4. Substitute M≥315 into the same
local and both near-tail bounds, along with the new
x≤2.4 bound. Their errors are <.086, .054, .083, and .002.
The remote factor
2.8 (12 e^(−.37·12)) sqrt(315) e^(−.195·315/20)<.327.
Sum <.552<1/sqrt(2). This proves the sign on the enlarged
analytic sector, so the exact rectangle only needs
12≤R≤20, 2.45≤u≤2.8; for u>2.8 use p≥u.
