# Strict negative roots for all n ≥ 35,000,000,000

This improves the previous explicit infinite-tail bound
of 7,500,000,000,000 for the same original sequence.
It does not bridge the finite gaps and is not an all-n proof.

The exact phase marker signs now hold for *every angle*
whenever R≥4096, by combining the results:
- k=0 cusp: original big_blocks4_explicit_tail_18.md §4.
- 0<p≤1/8: airymarker_small_p.md.
- 1/8≤p≤1/2: low_angle_R4096_complete.md,
  which separates bounded k=1..6 from k≥7 using matched
  Airy and tilted Gaussian phases, not a scan.
- 1/2≤p≤1.5: medium_angle_R4096.md.
- 1.5≤p≤2.5: phase_R256_midangle.md.
- p≥2.5: phase_high_angle_gaussian.md.

For 32≤R≤4096 the same p-exclusion from full_tail_7500b.md
forces p>2.5 at every relevant actual saddle:
if p≤2.5, the bound M/(1+a)<11R, a<.001 and M<12R
there gives
\[
  n<1.001(R+R^2+R^3/2)+12R^2
     \le 1.001(4096+4096^2+4096^3/2)+12\cdot4096^2
     <35\,000\,000\,000.
\]
So only the previously proved high-angle sector appears
on those radii when n≥35,000,000,000. Compact and small
radius signs and the final far-left anchor are unchanged.
The first successive exact-marker sign brackets exhaust
degree m=floor(n/4), with the separately anchored far-left
root, exactly as in full_tail_7500b.md. Thus all roots
are simple negative for the stated entire infinite tail.
