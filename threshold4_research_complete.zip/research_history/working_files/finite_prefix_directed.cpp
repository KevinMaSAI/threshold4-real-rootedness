// Exact finite-exception certificate, not an all-n method. g++ -O3 -UNDEBUG -std=c++17.
// Intervals only: addition, multiplication, division, and binary powers.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <vector>
using W = __uint128_t;
using U = uint64_t;
struct F { U l=0,h=0; int e=0; }; // coefficient in [l*2^e,h*2^e]
static constexpr int digits=60;
static unsigned bit(W x) {
  if(U h=x>>64) return 128-__builtin_clzll(h);
  if(U l=x) return 64-__builtin_clzll(l);
  return 0;
}
static W ceil2(W x,unsigned s) {
  if(!x) return 0;
  if(s>=128) return 1;
  if(!s) return x;
  return (x>>s)+((x<< (128-s))!=0);
}
static W floor2(W x,unsigned s) {return s>=128?0:x>>s;}
static F standardized(W l,W h,int e) {
  int s=int(bit(h))-digits;
  if(!h) return {};
  if(s<=0) return {U(l<<(-s)),U(h<<(-s)),e+s};
  return {U(floor2(l,s)),U(ceil2(h,s)),e+s};
}
static F plus(F a,F b) {
  if(!a.h) return b;
  if(!b.h) return a;
  if(a.e<b.e) std::swap(a,b);
  return standardized(a.l+floor2(b.l,a.e-b.e),a.h+ceil2(b.h,a.e-b.e),a.e);
}
static F times(F a,U b) { return standardized(W(a.l)*b,W(a.h)*b,a.e); }
struct I {U l,h;};
static constexpr unsigned B=42;
static constexpr U Q=U(1)<<B;
static I prod(I a,I b) {
  return {U(W(a.l)*b.l>>B),U(ceil2(W(a.h)*b.h,B))};
}
static U rshift(W n,W d,int shift,bool up) {
  assert(d);
  // Initial q's near or below 1 are divided at 80 product bits.
  if(shift>=0) {
    if(bit(n)+shift>127) return 2*Q;
    n<<=shift;
  } else {
    if(bit(d)-shift>127) return up && n ? 1 : 0;
    d<<=-shift;
  }
  W k=n/d+(up && n%d!=0);
  return k>2*Q?2*Q:U(k); // explicit clamp; caller must reject the upper saturation
}
static I init(F a,F b,F c) {
  constexpr int trim=40;
  const int e=a.e+c.e-2*b.e+B;
  return {rshift(floor2(W(a.l)*c.l,trim),ceil2(W(b.h)*b.h,trim),e,false),
          rshift(ceil2(W(a.h)*c.h,trim),floor2(W(b.l)*b.l,trim),e,true)};
}
struct Answer {int res,step;};
static Answer graeffe(const std::vector<F>& a) {
  const int d=int(a.size())-1;
  if(d<2) return {1,0};
  std::vector<I> qs(d+1),eta(d+1,{Q,Q});
  for(int k=1;k<d;++k) qs[k]=init(a[k-1],a[k],a[k+1]);
  for(int j=0;j<=25;++j) {
    U largest=0;
    for(int k=1;k<d;++k) largest=std::max(largest,qs[k].h);
    if(4*largest<Q) return {1,j};
    if(j==25 || largest>=Q) return {0,j};
    for(int k=1;k<d;++k) {
      int64_t lo=Q,hi=Q;
      I h{Q,Q},v{Q,Q};
      const int lim=std::min(k,d-k);
      for(int s=1;s<=lim;++s) {
        h=s==1?qs[k]:prod(prod(h,qs[k-s+1]),qs[k+s-1]);
        v=prod(v,h);
        if(s%2) {lo-=2*v.h;hi-=2*v.l;}
        else {lo+=2*v.l;hi+=2*v.h;}
        if(v.h<=1 && s<lim) {
          if(s%2) hi+=2*v.h; else lo-=2*v.h;
          break;
        }
      }
      if(hi<0) return {-1,j+1};
      if(lo<=0) return {0,j+1};
      eta[k]={U(lo),U(hi)};
    }
    for(int k=1;k<d;++k) {
      I num=prod(prod(qs[k],qs[k]),prod(eta[k-1],eta[k+1]));
      W t0=W(num.l)<<(2*B),t1=W(num.h)<<(2*B);
      W d0=W(eta[k].h)*eta[k].h,d1=W(eta[k].l)*eta[k].l;
      W lower=t0/d0,upper=t1/d1+(t1%d1!=0);
      if(upper>=Q) return {0,j+1};
      qs[k]={U(lower),U(upper)};
    }
  }
  throw std::logic_error("unreachable");
}
int main(int argc,char**argv) {
  if(argc!=3) return 4;
  const int begin=std::atoi(argv[1]),end=std::atoi(argv[2]);
  if(begin<0 || end<begin || end>100000) return 4;
  std::vector<F> rows[4]; rows[0]={standardized(1,1,0)};
  int maximum=0;
  for(int n=0;;++n) {
    if(n>=begin) {
      auto [res,step]=graeffe(rows[n%4]);
      if(res!=1) {std::cout<<"UNRESOLVED "<<n<<" code "<<res<<" step "<<step<<std::endl;return 2;}
      maximum=std::max(maximum,step);
      if(n%512==0) std::cout<<"verified up to "<<n<<std::endl;
    }
    if(n==end) break;
    std::vector<F> next((n+1)/4+1);
    U weights[4]={0,U(n),U(n)*(n-1)/2,U(n)*(n-1)*(n-2)/6};
    for(unsigned k=0;k<rows[n%4].size();++k)
      next[k]=times(rows[n%4][k],k+1);
    for(int r=1;r<=3&&r<=n;++r) {
      const auto& old=rows[(n-r)%4];
      for(unsigned k=0;k<old.size();++k)
        next[k+(r==3)]=plus(next[k+(r==3)],times(old[k],weights[r]));
    }
    rows[(n+1)%4]=std::move(next);
  }
  std::cout<<"VERIFIED all n in ["<<begin<<","<<end<<"], maximum Graeffe iterations "<<maximum<<std::endl;
}
