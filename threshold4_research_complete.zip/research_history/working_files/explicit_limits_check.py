"""Exact scalar-inequality replay for the explicit-tail paper argument.
This is not a unit test for the analytic reductions or any scan over n.
"""
from fractions import Fraction as F
from math import factorial

def positive_exp(x):
    assert 0 <= x <= 32
    s=sum(x**j/factorial(j) for j in range(129))
    t=x**129/factorial(129)
    return s,s+t/(1-x/130)

def sincos(x):
    assert 0 <= x <= 1
    S=sum((-1)**j*x**(2*j+1)/factorial(2*j+1) for j in range(7))
    C=sum((-1)**j*x**(2*j)/factorial(2*j) for j in range(7))
    return (S-x**15/factorial(15),S),(C-x**14/factorial(14),C)

def main():
    pi_lo,pi_hi=F(314159,100000),F(314160,100000)
    T=10**6
    # Geometric and exact ordinary/small-angle curvatures.
    assert F(4,5)*F(99,100)**4*(1/pi_hi**2-F(6,1000))>F(73,1000)
    assert F(96,100)*F(99,100)**4*(F(1,3)-F(3,2)**2/30-F(6,1000))>F(232,1000)
    assert F(73,1000)-F(34,1000)>F(1,26)
    assert F(232,1000)-F(105,1000)>F(1,8)
    for p,d,b,n4,n33 in [
        (F(3,4),20,8,91,2415),(F(3,2),60,26,1800,150000)
    ]:
        # The Q estimate uses sqrt(3) < 2.
        assert 4*b**5 < (8*n4)**2/4  # equivalent b^5/4<n4^2
        assert F(5,3)**2*b**7 < n33*n33
        assert F(n4,T)/p**5+F(n33,T)/p**7 < F(2,100)
        assert F(100*d,1000)/p**3 / 2**int(T*p**4/(100*d*d)) < F(4,100)
        assert 2*3*b < (F(1,100)*p * 2**int(T*p**4/(4*b*d*d)))**2
    # Signed model of L on tilt and taper.
    s0,c0=sincos(F(95,100))
    assert c0[0]/(2*positive_exp(F(38,100))[1])-F(1,10000)>F(198,1000)
    assert s0[1]/2+F(1,10000)<F(407,1000)
    assert F(198,1000)*(1-F(16,100)/3)-F(407,1000)*F(2,5)>F(24,1000)
    assert F(24,1000)*F(2,5)>F(1,110)
    assert (sincos(F(3,4))[1][0]/2-F(1,10000))>F(35,100)
    assert F(559,1000)-F(2,5)>F(1,8)
    assert 2*3**2*8**5 < (8*97)**2
    assert 2*F(5,6)**2*8**7 < 1710**2
    assert F(97,40000)+F(1710,8000)<F(22,100)
    assert positive_exp(F(8000,2750))[0]>F(50,3)
    assert F(240,1)**2*(F(3,50))**2 < (F(17,100))**2*8000
    # Matched Airy contour: .34 times the weighted moments.
    c=F(48,100)*T;p=F(1,5);b=F(3,8)
    assert F(2,5)*(F(198,1000)*(1-F(4,75))-F(407,1000)*F(2,5))>F(1,110)
    a=F(111,100)/(24*F(48,100))*F(5,4)**2
    assert F(11,24)-a*F(55,100)>b
    assert 4*F(5,4)*a*a < F(34,100)**2
    assert F(34,100)**2*9/b**3/pi_lo < F(26,10)**2
    assert F(34,100)*6/(b*b*pi_lo) < F(47,10)
    assert F(47,10)**2/(F(3,2)*pi_lo)<F(22,10)**2
    # Gamma(5/3) < 2; no special-function evaluation needed.
    d=(F(34,100)*2/pi_lo)**3/b**5
    assert d < 2**3
    assert d*(F(4,3)**3) < 2**3  # p=0 uses weaker Ai(0) bound
    assert c > 8**6 and p < F(45,100)**2
    assert F(26,10)*p+F(11,100)+2*F(45,100)/8 < F(3,4)
    assert ( (F(99,100)*F(35,100))**2-p*p )**2/200 > F(1,32000)
    assert 10**10*F(3,8)**31 < F(1,100)
    print('Verified the key rational inequality budgets for the 10^18 cutoff')

if __name__=='__main__':main()
