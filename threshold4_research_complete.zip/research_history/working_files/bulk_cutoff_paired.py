"""Effective two-saddle sign range for radii [1/20,32], not the other regions."""
from fractions import Fraction as F
import json, sys
from angular_certificate import (
    Q, ONE, PIHI, add, sub, mul, sq, scale, div, exp, trig, point, calc,
    Rconstants,
)

def ceil(x):
    return -(-x.numerator//x.denominator)

def cover(a,b,count):
    for j in range(count):
        yield a+j*(b-a)//count,a+(j+1)*(b-a)//count

def radial(C,T):
    if C[0]:
        ans=(0,0)
        for k,w in enumerate(C[2],4):
            c,_=trig(scale(T,k))
            ans=add(ans,scale(mul(w,c),-k))
        a=div(mul(C[2][-1],C[1]),23)[1]
        return ans[0]-46*a,ans[1]+46*a
    _,R,R2,R3,E=C
    c,s=trig(T); x,y=mul(R,c),mul(R,s)
    C_y,S_y=trig(y); EE=exp(sub(x,R))
    c2,_=trig(scale(T,2)); c3,_=trig(scale(T,3))
    small=add(x,add(mul(R2,c2),div(mul(R3,c3),2)))
    return sub(mul(E,small),mul(EE,sub(mul(x,C_y),mul(y,S_y))))

def sval(C,T):
    R=C[1]
    R2=sq(R); R3=mul(R,R2)
    c,_=trig(T); c2,_=trig(scale(T,2)); c3,_=trig(scale(T,3))
    return add(mul(R,c),add(div(mul(R2,c2),2),div(mul(R3,c3),6)))

def outer_gap(C,t0,L,H,goal,S):
    # For theta>=theta0 and theta0<=1/2, S decreases to pi/6.
    # Beyond pi/6 compare the sector loss bounds in the proof in section 1.2.
    r=F(C[1][0],Q)
    limit=S[2]*F(t0,Q)**2/2
    safe_right=2*t0<=Q and limit<min(r*r/2,r**3/24)
    sref=sval(C,point(t0))[0]
    pscale=F(0)
    tar=calc(C,point(t0),0)[1]
    todo=[(0,L,0),(H,PIHI,0)]
    gap=None
    pairs=[]
    while todo:
        a,b,depth=todo.pop()
        g=calc(C,(a,b),0)[0]-tar
        if g<goal and depth>=5:
            d=calc(C,(a,b),1)
            if d[0]>=0:g=max(g,calc(C,point(a),0)[0]-tar)
            if d[1]<=0:g=max(g,calc(C,point(b),0)[0]-tar)
        perturb=F(0)
        if not (a>=t0 and (safe_right or 2*b<=Q)):
            perturb=max(0,min(limit,F(sval(C,(a,b))[1]-sref,Q)))
        if g>=goal and 2*perturb*Q <= 1280*g:
            gap=g if gap is None else min(gap,g)
            pscale=max(pscale,2*perturb*Q/g)
            pairs.append((F(g,Q),perturb))
        elif depth<15:
            m=(a+b)//2
            todo.extend(((a,m,depth+1),(m,b,depth+1)))
        else:
            return None
    # Delete dominated pairs: higher g and no larger perturbation
    # cannot decrease the gap for any positive lambda.
    front=[]
    for g,p in sorted(pairs,key=lambda gp:(gp[0],-gp[1])):
        if not front or p>front[-1][1]:front.append((g,p))
    return F(gap,Q),pscale,front

def derivative_caps(C):
    r=F(C[1][1],Q)
    S=[r+2**j*r*r/2+3**j*r**3/6 for j in range(5)]
    if C[0]:
        nxt=div(mul(C[2][-1],C[1]),23)[1]
        B=[F(sum(w[1]*k**j for k,w in enumerate(C[2],4))+2*nxt*23**j,Q) for j in range(5)]
    else:
        T=[1,r,r*r+r,r**3+3*r*r+r,r**4+6*r**3+7*r*r+r]
        B=[T[j]+F(C[-1][1],Q)*(S[j]+(j==0)) for j in range(5)]
    return S,B

def capped_w(data):
    r,s,c,a,b=data
    assert 0<a<c<b and 100*b<314*Q
    C=Rconstants((r,s))
    margin=F(min(-calc(C,point(a),1)[1],calc(C,point(b),1)[0]),Q)
    curvature=F(min(calc(C,z,2)[0] for z in cover(a,b,24)),Q)
    radial_values=[radial(C,z) for z in cover(a,b,48)]
    radialmin=F(min(v[0] for v in radial_values),Q)
    radialmax=F(max(v[1] for v in radial_values),Q)
    if min(margin,curvature,radialmin)<=0:
        return None
    S,B=derivative_caps(C)
    gscale=curvature*F(min(c-a,b-c),Q)**2/6
    if C[0]:
        gscale=min(gscale,F(r,Q)/20)
    ratio=outer_gap(C,c,a,b,max(1,int(gscale*Q)), S)
    if ratio is None:return None
    out,pscale,front=ratio
    # Enforce lambda>=512 to dilute S_j in upper derivative bounds.
    LL=[B[j]+S[j]/512 for j in range(5)]
    cb=curvature if 2*b<=Q else 7*curvature/8
    L1=min(S[1],S[2]*F(b,Q))
    base=max(512, 1 if 2*b<=Q else ceil(8*S[2]/curvature), ceil(F(5,8)*pscale),
             ceil(F(5,4)*L1*LL[2]/(cb*radialmin)))
    tests=[LL[4]**2*LL[2]/cb**5, (2*LL[3]**2)**2*LL[2]/cb**7]
    R=C[1]; R2=sq(R); R3=mul(R,R2)
    def sder(T):
        angles=[trig(scale(T,j))[1] for j in range(1,4)]
        val=add(mul(R,angles[0]),add(mul(R2,angles[1]),div(mul(R3,angles[2]),2)))
        return F(-val[1],Q),F(-val[0],Q)
    def exp_bound(x, y):
        # e^-x sqrt(y) <= 1/16 iff (sufficiently) y <= 2^(2 floor x)/256.
        j=x.numerator//x.denominator
        if j<1:return False
        if j>y.numerator.bit_length()+10:return True
        z=x-j
        return y*256*3**(2*j) <= (1+2*z+2*z*z)*8**(2*j)
    def make_candidate(lam,w):
        def works(k):
            loss=min(k*cb*w*w/2,min(k*g-p for g,p in front))
            return (all(k*k>=v for v in tests) and loss>=F(1,2)
                    and exp_bound(loss,k*LL[2])
                    and exp_bound(k*cb*w*w/4,LL[2]/cb))
        hi=lam
        while not works(hi):
            hi*=2
        lo=lam-1
        while hi-lo>1:
            mid=(hi+lo)//2
            if works(mid):hi=mid
            else:lo=mid
        # The sufficient discrete power-of-two bound need not be monotone at all
        # k. Only the final checked point matters; the actual exponential tail
        # is monotone after k*tail>=1/2.
        assert works(hi)
        return hi,w
    choices=[make_candidate(max(base,ceil(2*L1/margin)),margin/(2*LL[2]))]
    for df in (F(1,4),F(1,2),F(2,3),F(3,4)):
        L=c-int(df*(c-a)); H=c+int(df*(b-c))
        lm=F(-calc(C,point(L),1)[1],Q)
        hm=F(calc(C,point(H),1)[0],Q)
        if min(lm,hm)<=0:continue
        a0=max(F(0),-sder(point(L))[0])/lm
        b0=max(F(0),sder(point(H))[1])/hm
        lam=max(base,ceil(F(5,4)*max(a0,b0)))
        choices.append(make_candidate(lam,F(min(L-a,b-H),Q)))
    lam,w=min(choices)
    return ceil(S[1]+radialmax*lam)+1, lam, base, (r,s,c,a,b), (w,curvature,out,radialmin)

def main():
    rows=json.load(open(sys.argv[1] if len(sys.argv)>1 else 'angular_certificate.json'))
    limit=int(sys.argv[2]) if len(sys.argv)>2 else 32
    rows=[(lo,min(hi,Q*limit),c,a,b) for (lo,hi,c,a,b) in rows if lo<Q*limit]
    assert rows[0][0]==Q//20 and rows[-1][1]==limit*Q
    assert all(r[0]<r[1] and r[1]==s[0] for r,s in zip(rows,rows[1:]))
    failed=[];results=[]
    todo=[]
    for row in reversed(rows):
        a,b,c,l,u=row
        if a<Q//3:
            todo.extend((((lo,hi,c,l,u),0) for lo,hi in cover(a,b,8)))
        else:
            todo.append((row,0))
    while todo:
        row,dep=todo.pop()
        res=capped_w(row)
        if res is None and dep<4:
            a,b,c,l,u=row
            m=(a+b)//2
            todo.append(((m,b,c,l,u),dep+1))
            todo.append(((a,m,c,l,u),dep+1))
        elif res is None:
            failed.append(row)
        else:
            results.append(res)
    print('success/fail',len(results),len(failed))
    if failed: print('failed radial intervals:', [(v[0]/Q,v[1]/Q) for v in failed[:30]])
    vals=sorted(results,reverse=True)
    for n,lam,ll,row,bounds in vals[:6]:
        print('n bound',n,'lambda',lam,'local',ll, 'R',row[0]/Q,row[1]/Q,'w c gap dr',*[float(x) for x in bounds])
    if not failed:
        print('CERTIFIED N_compact =',vals[0][0])
if __name__=='__main__':
    main()
