"""Exact structural tests of the threshold 3->4 homotopy, not an all-rank proof."""
from math import factorial,comb
from check import certificate
from sympy import symbols, Poly, resultant, diff

v,t=symbols('v t')

def no_triples(N):
    rows=[[1]]
    for n in range(1,N+1):
        row=[0]*(n//4+1)
        for s in range(1,n+1):
            if s==3:continue
            for k,val in enumerate(rows[n-s]):
                row[k+(s>=4)]+=comb(n-1,s-1)*val
        rows.append(row)
    return rows

def model(n,q):
    m=n//3
    return Poly(sum(
        (factorial(n)//(factorial(n-3*j)*6**j*factorial(j)))*
        (t+v)**j*(1+v)**(m-j)*sum(w*t**k for k,w in enumerate(q[n-3*j]))
        for j in range(m+1)),t,v)

def main():
    q=no_triples(28)
    for n in range(3,21):
        f=model(n,q)
        found=False
        for slope in [1,2,3,5]:
            for shift in [0,-1,1,-2,2,-3,3,-5,5,10,-10]:
                row=Poly(f.as_expr().subs(v,slope*t+shift),t)
                if row.degree()<=1:continue
                cert=certificate(list(map(int,row.all_coeffs()))[::-1])
                if cert['real']<cert['sf_degree']:
                    print('Joint stability counterexample at n=',n,'with v=',slope,'t +',shift,
                          'row descending=',row.all_coeffs(),'Sturm=', cert,flush=True)
                    found=True;break
            if found:break
        if found:break
    for n in [8,12,16,20,24]:
        f=model(n,q)
        e=f.as_expr()
        row=Poly(resultant(e,diff(e,t),t),v)
        s=1 if row.LC()>0 else -1
        print('n=',n,'resultant degree',row.degree(),'all signed coefficients positive?',
              all(s*c>0 for c in row.all_coeffs()),flush=True)
        if n==8:
            print('ascending sign-normalized disc coefficients:',
                  list(reversed(Poly(Poly(e,t).discriminant(),v).all_coeffs())),flush=True)
if __name__=='__main__':main()
