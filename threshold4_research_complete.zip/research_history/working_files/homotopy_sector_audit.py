"""Exact auxiliary tests: Hurwitz sample and a mixed complex sector counterexample."""
from math import gcd
from sympy import I,Poly,Rational,expand,re,im
from triple_homotopy_audit import no_triples,model,t,v

def routh_rhp(h):
    """Routh rows reduced by positive scalars; reject exceptional pivot cases."""
    L=len(h)
    A=h[::2];B=h[1::2]+[0]*(len(A)-len(h[1::2]))
    signs=[A[0],B[0]]
    assert B[0]!=0
    while len(signs)<L:
        assert B[0]!=0
        C=[(B[0]*aa-A[0]*bb)*(1 if B[0]>0 else -1)
            for aa,bb in zip(A[1:],B[1:])]+[0]
        d=gcd(*C)
        assert d>0 and C[0]!=0  # no zero rows or pivots
        C=[z//d for z in C]
        signs.append(C[0]);A,B=B,C
    return sum(x*y<0 for x,y in zip(signs,signs[1:]))

def main():
    q=no_triples(30)
    f=model(12,q).as_expr()
    v0=Rational(1,200)+12*I
    z0=-1527+12505*I
    p=Poly(expand(200**4*f.subs({v:v0,t:t+z0})),t)
    up=lambda z: abs(re(z))+abs(im(z))
    low=lambda z: max(abs(re(z)),abs(im(z)))
    rad=10
    s=sum(up(p.nth(j))*rad**j for j in range(p.degree()+1) if j!=1)
    T=rad*low(p.nth(1))
    assert s<T and re(z0)+rad<0 and im(z0)-rad>0
    print('n=12 mixed sector failure via Rouche: v=1/200+12i, t in disk (-1527+12505i,10).',flush=True)
    print('Bounds:',s,'<',T,flush=True)
    for n in (6,8,9,12,15,18,20,24,30):
        m=n//3
        D=Poly(Poly(model(n,q).as_expr(),t).discriminant(),v)
        U=D.exquo(Poly(v+1,v)**(m*(m-1)))
        pos=routh_rhp(list(map(int,U.all_coeffs())))
        print('n',n,'degree',U.degree(),'strict right-half-plane count',pos,flush=True)
if __name__=='__main__':main()
