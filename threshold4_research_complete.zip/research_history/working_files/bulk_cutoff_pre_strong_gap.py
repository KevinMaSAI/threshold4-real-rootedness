"""Effective two-saddle sign range for radii [1/20,32], not the other regions."""
from fractions import Fraction as F
import json, sys
from angular_certificate import (
    Q, ONE, PIHI, add, sub, mul, sq, scale, div, exp, trig, point, calc,
    Rconstants,
)

def ceil(x):
    return -(-x.numerator//x.denominator)

def cover(a,b,count):
    for j in range(count):
        yield a+j*(b-a)//count,a+(j+1)*(b-a)//count

def radial(C,T):
    if C[0]:
        ans=(0,0)
        for k,w in enumerate(C[2],4):
            c,_=trig(scale(T,k))
            ans=add(ans,scale(mul(w,c),-k))
        a=div(mul(C[2][-1],C[1]),23)[1]
        return ans[0]-46*a,ans[1]+46*a
    _,R,R2,R3,E=C
    c,s=trig(T); x,y=mul(R,c),mul(R,s)
    C_y,S_y=trig(y); EE=exp(sub(x,R))
    c2,_=trig(scale(T,2)); c3,_=trig(scale(T,3))
    small=add(x,add(mul(R2,c2),div(mul(R3,c3),2)))
    return sub(mul(E,small),mul(EE,sub(mul(x,C_y),mul(y,S_y))))

def sval(C,T):
    R=C[1]
    R2=sq(R); R3=mul(R,R2)
    c,_=trig(T); c2,_=trig(scale(T,2)); c3,_=trig(scale(T,3))
    return add(mul(R,c),add(div(mul(R2,c2),2),div(mul(R3,c3),6)))

def outer_gap(C,t0,L,H,goal,S):
    # For theta>=theta0 and theta0<=1/2, S decreases to pi/6.
    # Beyond pi/6 compare the sector loss bounds in the proof in section 1.2.
    r=F(C[1][0],Q)
    limit=S[2]*F(t0,Q)**2/2
    safe_right=2*t0<=Q and limit<min(r*r/2,r**3/24)
    sref=sval(C,point(t0))[0]
    pscale=F(0)
    tar=calc(C,point(t0),0)[1]
    todo=[(0,L,0),(H,PIHI,0)]
    gap=None
    while todo:
        a,b,depth=todo.pop()
        g=calc(C,(a,b),0)[0]-tar
        if g<goal and depth>=5:
            d=calc(C,(a,b),1)
            if d[0]>=0:g=max(g,calc(C,point(a),0)[0]-tar)
            if d[1]<=0:g=max(g,calc(C,point(b),0)[0]-tar)
        perturb=F(0)
        if not (a>=t0 and (safe_right or 2*b<=Q)):
            perturb=max(0,min(limit,F(sval(C,(a,b))[1]-sref,Q)))
        if g>=goal and 2*perturb*Q <= 4096*g:
            gap=g if gap is None else min(gap,g)
            pscale=max(pscale,2*perturb*Q/g)
        elif depth<15:
            m=(a+b)//2
            todo.extend(((a,m,depth+1),(m,b,depth+1)))
        else:
            return None
    return F(gap,Q),pscale

def derivative_caps(C):
    r=F(C[1][1],Q)
    S=[r+2**j*r*r/2+3**j*r**3/6 for j in range(5)]
    if C[0]:
        nxt=div(mul(C[2][-1],C[1]),23)[1]
        B=[F(sum(w[1]*k**j for k,w in enumerate(C[2],4))+2*nxt*23**j,Q) for j in range(5)]
    else:
        T=[1,r,r*r+r,r**3+3*r*r+r,r**4+6*r**3+7*r*r+r]
        B=[T[j]+F(C[-1][1],Q)*(S[j]+(j==0)) for j in range(5)]
    return S,B

def capped_w(data):
    r,s,c,a,b=data
    assert 0<a<c<b and 100*b<314*Q
    C=Rconstants((r,s))
    margin=F(min(-calc(C,point(a),1)[1],calc(C,point(b),1)[0]),Q)
    curvature=F(min(calc(C,z,2)[0] for z in cover(a,b,24)),Q)
    radialmin=F(min(radial(C,z)[0] for z in cover(a,b,48)),Q)
    if min(margin,curvature,radialmin)<=0:
        return None
    S,B=derivative_caps(C)
    ratio=outer_gap(C,c,a,b,max(1,int(curvature*F(min(c-a,b-c),Q)**2*Q/64)), S)
    if ratio is None:return None
    out,pscale=ratio
    # Prefer a central, narrower bracket (proved, not guessed).
    w=F(0)
    for den in [4,3,2]:
        L=c-(c-a)//den; H=c+(b-c)//den
        pm=F(min(-calc(C,point(L),1)[1],calc(C,point(H),1)[0]),Q)
        if pm>0:
            w=F(min(L-a,b-H),Q)
            margin=max(pm,F(0))
            break
    # Enforce lambda>=512 to dilute S_j in upper derivative bounds.
    LL=[B[j]+S[j]/512 for j in range(5)]
    w=w or margin/(2*LL[2])
    cb=curvature if 6*b<=3*Q else 7*curvature/8
    tail=min(out/2,cb*w*w/2)
    L1=min(S[1],S[2]*F(b,Q))
    lam=max(512,ceil(2*L1/margin),ceil(8*S[2]/curvature),
            ceil(pscale),ceil(2*L1*LL[2]/(cb*radialmin)))
    # Relative size of local cubic-cancelled error is at most
    # [(1/8) L4 sqrt(L2)/cb^(5/2) + (5/24) L3^2 sqrt(L2)/cb^(7/2)]/lambda.
    # Bound each coefficient by lambda/8, using exact squared inequalities.
    tests={
        'local_4': LL[4]**2*LL[2]/cb**5,
        'local_33': (2*LL[3]**2)**2*LL[2]/cb**7,
    }
    for name,val in tests.items():
        while lam*lam<val:lam*=2
    llocal=lam
    # Relative full real half-circle tail ≤ 2 sqrt(lambda L2) exp(-lambda tail).
    # Relative full-Gaussian missing tail ≤ 2 sqrt(L2/cb) exp(-lambda cb w^2/4).
    # Guarantee each <= 1/8 via powers of 2 (e>2).
    def exp_bound(x, y):
        # e^-x sqrt(y) <= 1/16 iff (sufficiently) y <= 2^(2 floor x)/256.
        j=x.numerator//x.denominator
        if j<1:return False
        if j>y.numerator.bit_length()+10:return True
        return y*256 <= 1<<(2*j)
    while (lam*tail<F(1,2) or not exp_bound(lam*tail,lam*LL[2])
           or not exp_bound(lam*cb*w*w/4,LL[2]/cb)):
        lam*=2
    return ceil(S[1]+B[1]*lam)+1, lam, llocal, (r,s,c,a,b), (w,curvature,out,radialmin)

def main():
    rows=json.load(open(sys.argv[1] if len(sys.argv)>1 else 'angular_certificate.json'))
    assert rows[0][0]==Q//20 and rows[-1][1]==32*Q
    assert all(r[0]<r[1] and r[1]==s[0] for r,s in zip(rows,rows[1:]))
    failed=[];results=[]
    todo=[(row,0) for row in reversed(rows)]
    while todo:
        row,dep=todo.pop()
        res=capped_w(row)
        if res is None and dep<4:
            a,b,c,l,u=row
            m=(a+b)//2
            todo.append(((m,b,c,l,u),dep+1))
            todo.append(((a,m,c,l,u),dep+1))
        elif res is None:
            failed.append(row)
        else:
            results.append(res)
    print('success/fail',len(results),len(failed))
    if failed: print('failed radial intervals:', [(v[0]/Q,v[1]/Q) for v in failed[:30]])
    vals=sorted(results,reverse=True)
    for n,lam,ll,row,bounds in vals[:6]:
        print('n bound',n,'lambda',lam,'local',ll, 'R',row[0]/Q,row[1]/Q,'w c gap dr',*[float(x) for x in bounds])
    if not failed:
        print('CERTIFIED N_compact =',vals[0][0])
if __name__=='__main__':
    main()
