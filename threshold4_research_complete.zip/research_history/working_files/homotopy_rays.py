"""Test exact weighted marked-block rays, not a proof of stability."""
from fractions import Fraction as F
from math import comb
from check import certificate
from graeffe_certificate import signs_certificate
from fractions import Fraction
from math import lcm

def rows(N,whi,w3=F(1)):
    # each size 3 contributes (1+w3*z), size>3 (1+whi*z)
    P=[[1]]
    R=[1]
    for n in range(1,N+1):
        p=[F(0)]*(1+n//3)
        for k in range(1,n+1):
            prev=P[n-k]
            a=comb(n-1,k-1)
            b=0 if k<3 else (w3 if k==3 else whi)
            for j,u in enumerate(prev):
                p[j]+=a*u
                if b and j+1<len(p): p[j+1]+=a*b*u
        P.append(p)
    return P

def check_one(p):
    while len(p)>1 and p[-1]==0:p.pop()
    d=lcm(*(x.denominator if isinstance(x,Fraction) else 1 for x in p))
    p=[int(x*d) for x in p]
    cert=signs_certificate(p,max_bits=512)
    if cert[0]=='simple_real':return True, None
    c=certificate(p)
    return c['real']==c['sf_degree'], (p,c)

if __name__=='__main__':
    for w in [F(0),F(1,100),F(1,10),F(1,2),F(2),F(5),F(10),F(100)]:
        hit=None
        for n,p in enumerate(rows(80,w)):
            ok,data=check_one(p)
            if not ok:
                hit=(n,data);break
        print('large-block weight ratio',str(w),'first precise failure in 0..80:',hit,flush=True)
