from zipfile import ZipFile,ZIP_DEFLATED
from pathlib import Path
from hashlib import sha256
src='phase_overnight_checkpoint_v9.zip'
out='threshold4_full_proof_and_replay.zip'
new=['README_先读_阈值4全阶证明.md','PROOF_INDEX.md','research_log_zh.md',
     'literature_recheck_2026-11-25.md','proof_audit_2026_11_25.md',
     'audit_coverage_manifest.py','audit_coverage_manifest_results.txt',
     'replay_finite_3072_5172.sh','replay_finite_all_gmp.sh','replay_proof_recent.sh',
     'phase_tilt_factored.py','phase_tilt_factored_legacy.py',
     'saddle_all_n_ge_5173.md','finite_exception_gmp.cpp','left_anchor_audit_replay_results.txt',
     'phase_wide_192_256_results.txt','phase_tilt_factored_128_192_results.txt','phase_tilt_factored_20_128_smallq_trial_results.txt']
new.extend(f'finite_gmp_{a}_{b}_results.txt' for a,b in [(3072,3200),(3201,3583),(3584,3712),(3713,4095),(4096,4224),(4225,4639),(4640,4736),(4737,5172)])
for p in sorted(Path('.').glob('finite_gmp_independent_*_results.txt')):
    if 'CERTIFIED exact original n' in p.read_text(): new.append(str(p))
p=Path('phase_tilt_factored_20_128_results.txt')
if 'VERIFIED factored replay' in p.read_text(): new.append(str(p))
p=Path('final_join_replay_results.txt')
if 'Manifest confirmed:' in p.read_text(): new.append(str(p))
with ZipFile(src) as a:
    entries={n:a.read(n) for n in a.namelist()}
entries.update({n:Path(n).read_bytes() for n in new})
manifest=''.join(f'{sha256(value).hexdigest()}  {name}\n' for name,value in sorted(entries.items()))
with ZipFile(out,'w',ZIP_DEFLATED) as b:
    readme=new[0]
    b.writestr(readme,entries[readme])
    b.writestr('PROOF_INDEX.md',entries['PROOF_INDEX.md'])
    for name,value in sorted(entries.items()):
        if name not in (readme,'PROOF_INDEX.md'): b.writestr(name,value)
    b.writestr('SHA256SUMS',manifest)
print('Files:',len(entries))
print('ZIP SHA256:',sha256(Path(out).read_bytes()).hexdigest())
