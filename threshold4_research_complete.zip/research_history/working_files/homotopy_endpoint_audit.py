"""Exact checks of the escaping-root structure; does not solve homotopy."""
import argparse
from math import factorial
from fractions import Fraction as F
from sympy import Poly
from triple_homotopy_audit import no_triples, model, t, v
from check import certificate

def esc(n):
    l=(n+3)//4; m=n//3
    if l>m: return []
    return [factorial(n)//(6**(4*k-n)*24**(n-3*k)*factorial(4*k-n)*factorial(n-3*k))
            for k in range(l,m+1)]

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('sizes',nargs='*',type=int,default=[6,8,9,12,15,18,21,24,30])
    a=parser.parse_args()
    Q=no_triples(max(a.sizes))
    unit=Poly(v+1,v)
    # Exact Sturm regression of the limiting rows; universal proof via multipliers is separate.
    for n in range(1,101):
        r=esc(n)
        if r:
            s=certificate(r)
            assert s['real']==s['sf_degree']==len(r)-1
    for n in a.sizes:
        m=n//3;d,r=divmod(n,4);g=m-d
        k=model(n,Q).as_expr()
        p0=Poly(k.subs(v,0),t)
        s0=certificate(list(map(int,p0.all_coeffs()))[::-1])
        assert s0['real']==s0['sf_degree']==m
        print(n,'threshold-3 initial row simple real (exact Sturm)',flush=True)
        D=Poly(Poly(k,t).discriminant(),v)
        U,rem=D.div(unit**(m*(m-1)))
        assert rem.is_zero
        expected=m*(m-1)-(2*(g-1)*(2*g-r) if g else 0)
        assert U.degree()==expected
        negs=sum(1 for x in U.all_coeffs() if x<0)
        print(n,'stripped degree=',U.degree(),'expected=',expected,
              'negative coefficients=',negs,flush=True)
        if n==9:
            cert=certificate(list(map(int,U.all_coeffs()))[::-1])
            assert cert['sf_degree']==6 and cert['real']==4
            print('n=9 residual strict real count:', cert['real'], 'of', cert['sf_degree'])
        if negs:
            vals=[(i,int(c)) for (i,),c in U.terms() if c<0]
            print('negative positions and coefficients:',vals[:8],flush=True)
if __name__=='__main__': main()
